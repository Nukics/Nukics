// Dados da loja e do usuário logado, carregados uma vez por página.
import { api } from './api.js';
import { normalizar } from './util.js';

let loja;
let sessao;

// Os dados da vitrine vêm embutidos no HTML (sem esperar outra ida ao servidor); senão, pela API.
function lojaEmbutida() {
  try {
    const el = document.getElementById('dados-loja');
    return el ? JSON.parse(el.textContent) : null;
  } catch {
    return null;
  }
}

export function carregarLoja() {
  loja ??= Promise.resolve(lojaEmbutida()).then((dados) => dados || api('/api/loja'));
  return loja;
}

export function carregarUsuario() {
  sessao ??= api('/api/eu').then((r) => r.usuario).catch(() => null);
  return sessao;
}

export function produtoPorHandle(produtos, handle) {
  return produtos.find((p) => p.handle === handle) || null;
}

/* ---------------- categorias ---------------- */
export function categoriaPorSlug(categorias, slug) {
  return categorias.find((c) => c.slug === slug) || null;
}

// Nome da categoria; subcategorias aparecem como "Principal › Sub".
export function nomeCategoria(categorias, slug, { completo = false } = {}) {
  const categoria = categoriaPorSlug(categorias, slug);
  if (!categoria) return '';
  const pai = completo && categoria.pai && categoriaPorSlug(categorias, categoria.pai);
  return pai ? `${pai.nome} › ${categoria.nome}` : categoria.nome;
}

export const categoriasPrincipais = (categorias) => categorias.filter((c) => !c.pai);
export const subcategorias = (categorias, slug) => categorias.filter((c) => c.pai === slug);

// A categoria e as subcategorias dela (para filtrar produtos).
export function comSubcategorias(categorias, slug) {
  return [slug, ...subcategorias(categorias, slug).map((c) => c.slug)];
}

/* ---------------- busca ---------------- */
// Radical simples para a busca aceitar plural e gênero: "pretas" e "preto" -> "pret".
function radical(palavra) {
  const semPlural = palavra.length > 3 ? palavra.replace(/s$/, '') : palavra;
  return semPlural.length > 3 ? semPlural.replace(/[aoe]$/, '') : semPlural;
}

// Busca por nome, categoria, cor e descrição; todas as palavras precisam aparecer.
export function buscarProdutos(produtos, termo, categorias = []) {
  const palavras = normalizar(termo).split(/\s+/).filter(Boolean).map(radical);
  if (!palavras.length) return produtos;
  return produtos.filter((p) => {
    const categoria = nomeCategoria(categorias, p.categoria, { completo: true });
    const alvo = normalizar([p.nome, categoria, p.descricao, ...p.cores.map((c) => c.nome)].join(' '));
    return palavras.every((palavra) => alvo.includes(palavra));
  });
}
