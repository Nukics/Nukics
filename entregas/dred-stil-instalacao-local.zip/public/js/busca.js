// Linha de resultado da busca rápida.
import { brl, esc, urlProduto } from './util.js';

export function cartaoProdutoBusca(produto, categoria) {
  const cor = produto.cores[0];
  return `<a class="busca__item" href="${urlProduto(produto.handle, cor.nome)}">
    <img src="${esc(cor.imagens[0])}" alt="" loading="lazy">
    <div><strong>${esc(produto.nome)}</strong><span>${esc(categoria)} · ${produto.preco ? brl(produto.preco) : 'Preço sob consulta'}</span></div>
  </a>`;
}
