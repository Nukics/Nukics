// Mensagem rápida no rodapé da tela (toast).
import { esc } from './util.js';

let atual;

export function aviso(mensagem, { erro = false, link } = {}) {
  atual?.remove();
  atual = document.createElement('div');
  atual.className = 'aviso' + (erro ? ' aviso--erro' : '');
  atual.setAttribute('role', erro ? 'alert' : 'status');
  atual.innerHTML = esc(mensagem) + (link ? ` <a href="${esc(link.href)}">${esc(link.texto)}</a>` : '');
  document.body.append(atual);
  const este = atual;
  setTimeout(() => este.remove(), link ? 6000 : 3500);
}
