// Botão "curtir" dos produtos. Curtidas ficam na conta do cliente.
import { api } from './api.js';
import { aviso } from './aviso.js';
import { carregarLoja, carregarUsuario, produtoPorHandle } from './estado.js';
import { esc, iconeCoracao } from './util.js';

// Curtidas de quem está logado (preenchidas quando a sessão é carregada).
let minhas = [];

// Marca os botões já na tela (a vitrine aparece antes de saber quem está logado).
function marcarCurtidas() {
  document.querySelectorAll('[data-curtir]').forEach((b) => b.setAttribute('aria-pressed', minhas.includes(b.dataset.curtir)));
}

export function botaoCurtir(produto, curtidasDoUsuario = minhas) {
  const curtido = curtidasDoUsuario.includes(produto.handle);
  return `<button type="button" class="curtir" data-curtir="${esc(produto.handle)}" aria-pressed="${curtido}" aria-label="Curtir ${esc(produto.nome)}">` +
    `${iconeCoracao()}<span data-total>${produto.curtidas || 0}</span></button>`;
}

async function alternar(botao) {
  const handle = botao.dataset.curtir;
  const usuario = await carregarUsuario();
  if (!usuario) {
    const voltar = encodeURIComponent(location.pathname + location.search);
    aviso('Entre na sua conta para curtir produtos.', { link: { href: `/conta?voltar=${voltar}`, texto: 'Entrar' } });
    return;
  }
  botao.disabled = true;
  try {
    const { curtido, total } = await api(`/api/curtidas/${encodeURIComponent(handle)}`, { metodo: 'POST' });
    usuario.curtidas = curtido ? [...usuario.curtidas, handle] : usuario.curtidas.filter((h) => h !== handle);
    const produto = produtoPorHandle((await carregarLoja()).produtos, handle);
    if (produto) produto.curtidas = total;
    document.querySelectorAll(`[data-curtir="${CSS.escape(handle)}"]`).forEach((b) => {
      b.setAttribute('aria-pressed', curtido);
      b.querySelector('[data-total]').textContent = total;
    });
    document.dispatchEvent(new CustomEvent('curtidas:mudou', { detail: { handle, curtido } }));
  } catch (erro) {
    aviso(erro.message, { erro: true });
  } finally {
    botao.disabled = false;
  }
}

export function iniciarCurtidas() {
  carregarUsuario().then((usuario) => {
    minhas = usuario?.curtidas || [];
    marcarCurtidas();
  });
  document.addEventListener('click', (e) => {
    const botao = e.target.closest('[data-curtir]');
    if (botao) alternar(botao);
  });
}
