// Cartão de produto usado nos destaques, no catálogo, na busca e nos favoritos.
import { botaoCurtir } from './curtidas.js';
import { brl, esc, urlProduto } from './util.js';

const exibidos = new Map(); // handle -> produto, para trocar a foto ao escolher a cor

export function htmlPreco(produto, parcelas) {
  if (!produto.preco) return '<div class="preco"><strong>Preço sob consulta</strong></div>';
  const promo = produto.precoDe > produto.preco;
  return '<div class="preco">' +
    (promo ? `<s>${brl(produto.precoDe)}</s>` : '') +
    `<strong>${brl(produto.preco)}</strong>` +
    (produto.atacado || produto.categoria === 'atacado' ? '<span class="preco__atacado">Preço de atacado · desconto por quantidade</span>' : '') +
    (parcelas > 1 ? `<span class="preco__parcelas">em até ${parcelas}x de ${brl(produto.preco / parcelas)} sem juros</span>` : '') +
    '</div>';
}

export function desconto(produto) {
  return produto.precoDe > produto.preco && produto.preco ? Math.round((1 - produto.preco / produto.precoDe) * 100) : 0;
}

function fotos(cor, nome) {
  return cor.imagens.slice(0, 2).map((src, i) => `<img ${i ? `data-foto-alternativa="${esc(src)}"` : `src="${esc(src)}"`} alt="${i ? '' : esc(`${nome} — ${cor.nome}`)}" loading="lazy" decoding="async">`).join('');
}

export function cartaoProduto(produto, { parcelas = 1, curtidas } = {}) {
  exibidos.set(produto.handle, produto);
  const cor = produto.cores[0];
  const off = desconto(produto);
  const url = urlProduto(produto.handle, cor.nome);
  const cores = produto.cores.length > 1
    ? `<div class="cartao__cores">${produto.cores.map((c, i) =>
      `<button type="button" class="cor" style="--c:${esc(c.hex)}" aria-label="Cor ${esc(c.nome)}" aria-pressed="${i === 0}" data-cor-cartao="${esc(c.nome)}"></button>`).join('')}</div>`
    : '';
  return `<article class="cartao" data-handle="${esc(produto.handle)}">
    <a class="cartao__midia" href="${url}" tabindex="-1" aria-hidden="true">${fotos(cor, produto.nome)}</a>
    ${produto.esgotado ? '<span class="cartao__selo cartao__selo--esgotado">Esgotado</span>' : off ? `<span class="cartao__selo">-${off}%</span>` : ''}
    ${botaoCurtir(produto, curtidas)}
    ${cores}
    <h3 class="cartao__nome"><a href="${url}">${esc(produto.nome)}</a></h3>
    ${htmlPreco(produto, parcelas)}
  </article>`;
}

export function iniciarCartoes() {
  // Registra também os cartões que já vieram prontos no HTML, sem reconstruí-los.
  import('./estado.js').then(({ carregarLoja }) => carregarLoja()).then(({ produtos }) => {
    for (const p of produtos) exibidos.set(p.handle, p);
  });
  const carregarAlternativa = (e) => {
    if (e.type === 'pointerover' && e.pointerType !== 'mouse') return;
    const img = e.target.closest('.cartao')?.querySelector('[data-foto-alternativa]');
    if (!img || img.getAttribute('src')) return;
    img.addEventListener('load', () => img.classList.add('is-carregada'), { once: true });
    img.loading = 'eager';
    img.src = img.dataset.fotoAlternativa;
  };
  document.addEventListener('pointerover', carregarAlternativa);
  document.addEventListener('focusin', carregarAlternativa);
  document.addEventListener('click', (e) => {
    const botao = e.target.closest('[data-cor-cartao]');
    if (!botao) return;
    const cartao = botao.closest('.cartao');
    const produto = exibidos.get(cartao.dataset.handle);
    const cor = produto?.cores.find((c) => c.nome === botao.dataset.corCartao);
    if (!cor) return;
    cartao.querySelector('.cartao__midia').innerHTML = fotos(cor, produto.nome);
    cartao.querySelectorAll('a').forEach((a) => a.setAttribute('href', urlProduto(produto.handle, cor.nome)));
    cartao.querySelectorAll('[data-cor-cartao]').forEach((b) => b.setAttribute('aria-pressed', b === botao));
  });
}
