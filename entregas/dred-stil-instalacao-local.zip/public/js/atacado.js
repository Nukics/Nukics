// A prévia é visual; o servidor repete esta regra antes de gravar qualquer pedido.
export function percentualAtacado(quantidade) {
  if (quantidade >= 13) return 30;
  return ({ 2: 6, 3: 7, 4: 8, 5: 9, 6: 10, 7: 11, 8: 12, 9: 11, 10: 12, 11: 12, 12: 12 })[quantidade] || 0;
}

export function resumoAtacado(itens) {
  const itensAtacado = itens.filter((i) => ehAtacado(i.produto));
  const quantidade = itensAtacado.reduce((total, i) => total + i.qtd, 0);
  const percentual = percentualAtacado(quantidade);
  const bruto = itensAtacado.reduce((total, i) => total + Number(i.produto.preco || 0) * i.qtd, 0);
  // Arredondar por unidade, exatamente como o preço efetivamente cobrado no servidor.
  const liquido = itensAtacado.reduce((total, i) => total + precoAtacado(i, { percentual }) * i.qtd, 0);
  const desconto = Math.round((bruto - liquido) * 100) / 100;
  return { quantidade, percentual, desconto };
}

export function precoAtacado(item, resumo) {
  if (!ehAtacado(item.produto) || !resumo.percentual) return Number(item.produto?.preco || 0);
  return Math.round(Number(item.produto.preco) * (1 - resumo.percentual / 100) * 100) / 100;
}

export const ehAtacado = (produto) => Boolean(produto && (produto.atacado || produto.categoria === 'atacado'));
