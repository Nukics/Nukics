// O loader oficial cria o iframe; nenhum dado de cartão é lido pela loja.
const HOSTS = {
  homologacao: 'https://www.pre.globalgetnet.com',
  producao: 'https://www.globalgetnet.com',
};
const carregamentos = new Map();

function carregar(host) {
  if (carregamentos.has(host)) return carregamentos.get(host);
  const promise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `${host}/digital-checkout/loader.js`;
    script.async = true;
    script.id = 'digital-checkout';
    const timeout = setTimeout(() => { script.remove(); reject(new Error('A Getnet demorou para carregar. Tente abrir novamente.')); }, 20_000);
    script.onload = () => {
      clearTimeout(timeout);
      if (typeof window.loader?.init !== 'function') return reject(new Error('O componente de pagamento não ficou disponível.'));
      resolve(window.loader);
    };
    script.onerror = () => { clearTimeout(timeout); script.remove(); reject(new Error('Não foi possível carregar o pagamento seguro.')); };
    document.body.appendChild(script);
  });
  carregamentos.set(host, promise);
  promise.catch(() => carregamentos.delete(host));
  return promise;
}

export async function abrirCheckout(container, dados) {
  const host = HOSTS[dados.ambiente];
  if (!host || !/^[0-9a-f-]{36}$/i.test(dados.paymentIntentId || '')) throw new Error('Configuração de pagamento inválida.');
  const loader = await carregar(host);
  const anteriores = new Set(document.querySelectorAll('iframe'));
  // O guia oficial orienta mover o iframe do fim da página para a seção desejada.
  // Considera somente iframes novos da Getnet, preservando mapas e outros componentes.
  await new Promise((resolve, reject) => {
    let timer;
    const limpar = () => { observer.disconnect(); clearTimeout(timer); };
    const mover = () => {
      if (!container.isConnected) { limpar(); reject(new Error('A página de pagamento foi fechada.')); return; }
      for (const frame of document.querySelectorAll('iframe')) {
        let origem;
        try { origem = new URL(frame.src).origin; } catch { continue; }
        if (anteriores.has(frame) || origem !== host) continue;
        limpar();
        frame.title = 'Pagamento seguro Getnet';
        frame.classList.add('getnet__iframe');
        container.replaceChildren(frame);
        resolve();
        return;
      }
    };
    const observer = new MutationObserver(mover);
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
    timer = setTimeout(() => {
      limpar();
      reject(new Error('O formulário seguro não abriu. Recarregue o pedido para tentar novamente.'));
    }, 20_000);
    try {
      loader.init({ paymentIntentId: dados.paymentIntentId, checkoutType: 'iframe' });
      mover();
    } catch { limpar(); reject(new Error('Não foi possível abrir o formulário de pagamento.')); }
  });
}
