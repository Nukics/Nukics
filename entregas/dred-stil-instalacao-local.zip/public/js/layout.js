// Comportamentos do layout: menu mobile, submenus, busca com sugestões e barra inferior.
import { cartaoProdutoBusca } from './busca.js';
import { buscarProdutos, carregarLoja, carregarUsuario, nomeCategoria } from './estado.js';
import { abrirPainel, fecharPainel } from './gaveta.js';
import { esc } from './util.js';

const MAX_SUGESTOES = 6;

function iniciarMenu() {
  const menu = document.getElementById('menu-mobile');
  document.querySelector('[data-abrir-menu]').addEventListener('click', () => abrirPainel(menu));
  // fecha ao seguir um link (ex.: /#perguntas na própria página inicial)
  menu.addEventListener('click', (e) => e.target.closest('a') && fecharPainel(menu));
}

// Submenus (ex.: categorias do Catálogo): no computador abrem ao passar o mouse (CSS);
// a setinha abre/fecha no celular e pelo teclado. Clicar fora fecha.
function alternarSubmenu(item, abrir) {
  item.classList.toggle('aberto', abrir);
  item.querySelector('[data-submenu]').setAttribute('aria-expanded', abrir);
}

function iniciarSubmenus() {
  document.addEventListener('click', (e) => {
    const seta = e.target.closest('[data-submenu]');
    const alvo = seta?.closest('.menu__item--sub');
    document.querySelectorAll('.menu__item--sub.aberto').forEach((item) => item !== alvo && alternarSubmenu(item, false));
    if (alvo) alternarSubmenu(alvo, !alvo.classList.contains('aberto'));
  });
}

function iniciarBusca() {
  const painel = document.getElementById('busca');
  const campo = painel.querySelector('input');
  const resultados = painel.querySelector('.busca__resultados');
  let espera;

  async function sugerir() {
    const termo = campo.value.trim();
    if (!termo) {
      resultados.innerHTML = '';
      return;
    }
    const { produtos, categorias } = await carregarLoja();
    const achados = buscarProdutos(produtos, termo, categorias);
    const verTodos = `/catalogo?q=${encodeURIComponent(termo)}`;
    resultados.innerHTML = achados.length
      ? achados.slice(0, MAX_SUGESTOES).map((p) => cartaoProdutoBusca(p, nomeCategoria(categorias, p.categoria))).join('') +
        `<a class="busca__todos" href="${verTodos}">Ver ${achados.length === 1 ? 'o resultado' : `todos os ${achados.length} resultados`}</a>`
      : `<p class="busca__nada">Nenhum produto encontrado para “${esc(termo)}”.</p>`;
  }

  campo.addEventListener('input', () => {
    clearTimeout(espera);
    espera = setTimeout(sugerir, 150);
  });
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-abrir-busca]')) abrirPainel(painel, { focar: 'input' });
    else if (e.target.closest('[data-fechar-busca]')) fecharPainel(painel);
  });
}

function iniciarGavetas() {
  document.addEventListener('click', (e) => {
    const fechar = e.target.closest('[data-fechar-gaveta]');
    if (fechar) fecharPainel(fechar.closest('.gaveta'));
  });
}

// Destaca na barra inferior a seção atual.
function marcarBarraMobile() {
  const atual = location.pathname.replace(/\/+$/, '') || '/';
  document.querySelectorAll('.barra-mobile a').forEach((a) => {
    if (a.getAttribute('href') === atual) a.setAttribute('aria-current', 'page');
  });
}

// O HTML é o mesmo para todos (fica em cache); o link do painel aparece só para o admin.
function linkAdmin() {
  carregarUsuario().then((usuario) => {
    if (usuario?.papel !== 'admin') return;
    const atual = location.pathname === '/admin' ? ' aria-current="page"' : '';
    document.querySelectorAll('[data-menu-principal], .menu-mobile__lista').forEach((lista) =>
      lista.insertAdjacentHTML('beforeend', `<li><a href="/admin"${atual}>Admin</a></li>`));
  });
}

export function iniciarLayout() {
  iniciarMenu();
  iniciarSubmenus();
  iniciarBusca();
  iniciarGavetas();
  marcarBarraMobile();
  // A consulta da sessão não bloqueia a primeira pintura da vitrine.
  const quandoLivre = window.requestIdleCallback || ((fn) => setTimeout(fn, 180));
  quandoLivre(linkAdmin);
}
