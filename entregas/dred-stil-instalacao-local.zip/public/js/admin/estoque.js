// Admin > Estoque: cada tipo de peça pode ter saldos independentes por cor.
// Produtos da mesma cor compartilham o saldo; outras cores não são afetadas.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { dataCurta, esc } from '../util.js';

const normalizar = (valor) => String(valor || '').trim().toLocaleLowerCase('pt-BR');

export async function montarEstoque(painel) {
  let estoques = [];
  let produtos = [];

  function saldoDaCor(produto, cor) {
    return estoques.find((e) => e.cor && normalizar(e.cor) === normalizar(cor)
      && e.produtos.some((p) => p.handle === produto.handle));
  }

  function saldoLegado(produto) {
    return estoques.find((e) => !e.cor && e.id === produto.estoqueId);
  }

  async function lista() {
    ({ estoques, produtos } = await api('/api/admin/estoques'));
    const grupos = new Map();
    for (const estoque of estoques) {
      const chave = normalizar(estoque.nome);
      if (!grupos.has(chave)) grupos.set(chave, { nome: estoque.nome, saldos: [] });
      grupos.get(chave).saldos.push(estoque);
    }
    const semControle = produtos.flatMap((p) => {
      if (saldoLegado(p)) return [];
      const cores = (p.cores || []).filter((c) => !saldoDaCor(p, c.nome));
      return cores.length ? [`${p.nome} (${cores.map((c) => c.nome).join(', ')})`] : [];
    });
    painel.innerHTML = `
      <div class="admin__topo">
        <h2>Estoque por cor</h2>
        <button class="botao" type="button" data-novo>Novo grupo e cor</button>
      </div>
      <p class="ajuda">Organize por tipo de peça e depois por cor: <strong>Camisa oversized → Preto → Nike, DredStil, Vans</strong>.
        Os produtos vinculados à mesma cor compartilham as peças disponíveis. Vender uma peça preta não altera o saldo da branca.
        A venda confirmada baixa o saldo e o cancelamento devolve as peças.</p>
      ${[...grupos.values()].map((grupo) => `<section class="caixa estoque-grupo">
        <div class="admin__topo">
          <h3>${esc(grupo.nome)}</h3>
          <button class="botao botao--sec botao--pequeno" type="button" data-adicionar-cor="${esc(grupo.saldos[0].id)}">Adicionar cor</button>
        </div>
        <div class="tabela-rolagem"><table class="tabela">
          <thead><tr><th>Cor</th><th>Disponíveis</th><th>Produtos desta cor</th><th><span class="so-leitor">Ações</span></th></tr></thead>
          <tbody>${grupo.saldos.map((e) => `<tr>
            <td><strong>${esc(e.cor || 'Saldo compartilhado (legado)')}</strong>${!e.cor ? '<p class="ajuda">Abrange as cores sem saldo específico.</p>' : ''}</td>
            <td><span class="etiqueta ${e.quantidade === 0 ? 'etiqueta--cancelado' : e.quantidade <= 5 ? 'etiqueta--aguardando' : 'etiqueta--ok'}">${e.quantidade} ${e.quantidade === 1 ? 'peça' : 'peças'}</span></td>
            <td>${e.produtos.length ? `<ul class="historico">${e.produtos.map((p) => `<li>${esc(p.nome)}</li>`).join('')}</ul>` : '<span class="ajuda">Nenhum produto</span>'}</td>
            <td><div class="tabela__acoes">
              <button class="botao botao--sec botao--pequeno" type="button" data-editar="${esc(e.id)}">Editar</button>
              <button class="botao botao--sec botao--pequeno" type="button" data-historico="${esc(e.id)}">Histórico</button>
              <button class="botao botao--perigo botao--pequeno" type="button" data-excluir="${esc(e.id)}" data-nome="${esc(`${e.nome}${e.cor ? ` / ${e.cor}` : ' / saldo compartilhado'}`)}">Excluir</button>
            </div></td>
          </tr><tr hidden data-historico-de="${esc(e.id)}"><td colspan="4"></td></tr>`).join('')}</tbody>
        </table></div>
      </section>`).join('') || '<p>Nenhum estoque criado ainda.</p>'}
      ${estoques.some((e) => !e.cor) ? '<p class="ajuda"><strong>Há saldos antigos compartilhados entre cores.</strong> Para separá-los, crie cada cor com a quantidade real contada. O saldo específico da cor tem prioridade sobre o compartilhado; nenhuma quantidade é copiada automaticamente.</p>' : ''}
      ${semControle.length ? `<details class="caixa"><summary><strong>Cores sem controle de estoque</strong></summary><p class="ajuda">Estas cores vendem sem limite até receberem um saldo:</p><ul class="historico">${semControle.map((nome) => `<li>${esc(nome)}</li>`).join('')}</ul></details>` : ''}`;
  }

  function formulario(estoque, nomeInicial = '') {
    const atual = estoque || { nome: nomeInicial, cor: '', quantidade: 0, produtos: [] };
    const marcados = new Set(atual.produtos.map((p) => p.handle));
    const cores = new Map();
    for (const produto of produtos) {
      for (const cor of produto.cores || []) {
        if (!cores.has(normalizar(cor.nome))) cores.set(normalizar(cor.nome), cor.nome.trim());
      }
    }
    painel.innerHTML = `
      <form class="caixa form-grade" data-form-estoque>
        <h2>${estoque ? `Editar: ${esc(estoque.nome)} / ${esc(estoque.cor || 'saldo compartilhado')}` : 'Novo saldo por cor'}</h2>
        <div class="form-grade form-grade--2">
          <label class="campo"><span>Tipo de peça / grupo</span><input name="nome" required maxlength="60" value="${esc(atual.nome)}" placeholder="ex.: Camisa oversized" list="nomes-estoque"><datalist id="nomes-estoque">${[...new Set(estoques.map((e) => e.nome))].map((nome) => `<option value="${esc(nome)}"></option>`).join('')}</datalist></label>
          <label class="campo"><span>Cor</span>${estoque
            ? `<input name="cor" value="${esc(estoque.cor || 'Todas as cores sem saldo específico')}" disabled><small>${estoque.cor ? 'A cor deste saldo é fixa. Para outra cor, crie um novo saldo.' : 'Saldo antigo compartilhado. Crie saldos por cor com as quantidades reais para separar o estoque.'}</small>`
            : `<select name="cor" required><option value="">Selecione uma cor</option>${[...cores.values()].sort((a, b) => a.localeCompare(b, 'pt-BR')).map((cor) => `<option value="${esc(cor)}">${esc(cor)}</option>`).join('')}</select><small>As cores vêm dos produtos cadastrados.</small>`}</label>
          <label class="campo"><span>Peças disponíveis${estoque?.cor ? ` em ${esc(estoque.cor)}` : ''}</span><input name="quantidade" type="number" min="0" max="100000" step="1" required value="${atual.quantidade}">
            <small>Informe o total atual desta cor. Para uma entrada, some as peças novas ao saldo atual.</small></label>
        </div>
        <fieldset class="form-grade">
          <legend><strong>Produtos que compartilham este saldo</strong></legend>
          <div class="form-grade" data-produtos-estoque></div>
        </fieldset>
        <p class="erro-form" role="alert" data-erro hidden></p>
        <div class="form-acoes">
          <button class="botao botao--sec" type="button" data-cancelar>Cancelar</button>
          <button class="botao" type="submit">Salvar estoque</button>
        </div>
      </form>`;
    const form = painel.querySelector('[data-form-estoque]');
    const corSelecionada = () => estoque ? estoque.cor || null : form.elements.cor.value;

    function renderizarProdutos() {
      const cor = corSelecionada();
      const selecionaveis = estoque && !estoque.cor ? produtos
        : produtos.filter((p) => (p.cores || []).some((c) => normalizar(c.nome) === normalizar(cor)));
      form.querySelector('[data-produtos-estoque]').innerHTML = !cor && !estoque
        ? '<p class="ajuda">Selecione a cor para ver os produtos disponíveis.</p>'
        : selecionaveis.map((p) => {
          const outro = cor ? saldoDaCor(p, cor) || saldoLegado(p) : saldoLegado(p);
          const avisoMover = outro && outro.id !== estoque?.id
            ? cor ? `Hoje em "${outro.nome}${outro.cor ? ` / ${outro.cor}` : ' / compartilhado'}". Só esta cor passará a usar este saldo.`
              : `Hoje em "${outro.nome}". O vínculo compartilhado será movido; os saldos específicos por cor serão mantidos.`
            : '';
          return `<label class="check"><input type="checkbox" name="produtos" value="${esc(p.handle)}"${marcados.has(p.handle) ? ' checked' : ''}>
            <span>${esc(p.nome)}${p.ativo ? '' : ' <span class="ajuda">(oculto)</span>'}${avisoMover ? ` <small class="ajuda">${esc(avisoMover)}</small>` : ''}</span></label>`;
        }).join('') || '<p class="ajuda">Nenhum produto possui esta cor. Adicione a cor no cadastro do produto primeiro.</p>';
    }

    form.querySelector('[data-cancelar]').addEventListener('click', () => lista().catch((erro) => aviso(erro.message, { erro: true })));
    if (!estoque) form.elements.cor.addEventListener('change', () => {
      marcados.clear();
      renderizarProdutos();
    });
    aoEnviar(form, async () => {
      const dados = {
        nome: form.elements.nome.value,
        cor: corSelecionada(),
        quantidade: Number(form.elements.quantidade.value),
        produtos: [...form.querySelectorAll('input[name="produtos"]:checked')].map((c) => c.value),
      };
      await api(estoque ? `/api/admin/estoques/${encodeURIComponent(estoque.id)}` : '/api/admin/estoques', { metodo: estoque ? 'PUT' : 'POST', dados });
      aviso('Estoque salvo.');
      await lista();
    });
    renderizarProdutos();
    (nomeInicial ? form.elements.cor : form.elements.nome).focus();
  }

  async function historico(id) {
    const linha = painel.querySelector(`[data-historico-de="${CSS.escape(id)}"]`);
    if (!linha.hidden) return (linha.hidden = true);
    const { movimentos } = await api(`/api/admin/estoques/${encodeURIComponent(id)}/movimentos`);
    linha.querySelector('td').innerHTML = movimentos.length
      ? `<ul class="historico">${movimentos.map((m) => `<li>${dataCurta(m.criadoEm)} · ${esc(m.motivo)} · <strong>${m.delta > 0 ? '+' : ''}${m.delta}</strong> → ${m.quantidadeFinal} peças</li>`).join('')}</ul>`
      : '<span class="ajuda">Sem movimentações ainda.</span>';
    linha.hidden = false;
  }

  painel.addEventListener('click', async (e) => {
    const alvo = e.target.closest('[data-novo], [data-adicionar-cor], [data-editar], [data-historico], [data-excluir]');
    if (!alvo) return;
    try {
      if (alvo.matches('[data-novo]')) formulario(null);
      else if (alvo.matches('[data-adicionar-cor]')) formulario(null, estoques.find((x) => x.id === alvo.dataset.adicionarCor)?.nome || '');
      else if (alvo.matches('[data-editar]')) formulario(estoques.find((x) => x.id === alvo.dataset.editar));
      else if (alvo.matches('[data-historico]')) await historico(alvo.dataset.historico);
      else if (confirm(`Arquivar o estoque "${alvo.dataset.nome}"? Ele deixará de controlar novas vendas. Se houver saldo compartilhado, ele voltará a valer para essa cor; sem outro saldo, ela venderá sem limite. O histórico e os vínculos de pedidos anteriores serão preservados.`)) {
        await api(`/api/admin/estoques/${encodeURIComponent(alvo.dataset.excluir)}`, { metodo: 'DELETE' });
        aviso('Estoque arquivado.');
        await lista();
      }
    } catch (erro) {
      aviso(erro.message, { erro: true });
    }
  });

  await lista();
}
