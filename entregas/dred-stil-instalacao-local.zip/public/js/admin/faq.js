// Admin > Perguntas frequentes: adicionar, editar, reordenar e remover.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { esc } from '../util.js';

export async function montarFaq(painel) {
  let { faq } = await api('/api/admin/conteudo');

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Perguntas frequentes</h2>
      <button class="botao botao--sec" type="button" data-adicionar>Adicionar pergunta</button>
    </div>
    <form class="form-grade" data-form-faq>
      <div class="form-grade" data-lista></div>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <div class="form-acoes"><button class="botao" type="submit">Salvar perguntas</button></div>
    </form>`;
  const lista = painel.querySelector('[data-lista]');

  function renderizar() {
    lista.innerHTML = faq.map((item, i) => `
      <div class="item-lista" data-item="${i}">
        <label class="campo"><span>Pergunta ${i + 1}</span><input data-campo="pergunta" required maxlength="200" value="${esc(item.pergunta)}"></label>
        <label class="campo"><span>Resposta</span><textarea data-campo="resposta" required maxlength="2000">${esc(item.resposta)}</textarea></label>
        <div class="item-lista__acoes">
          <button class="botao botao--sec botao--pequeno" type="button" data-mover="-1"${i === 0 ? ' disabled' : ''} aria-label="Subir pergunta ${i + 1}">↑</button>
          <button class="botao botao--sec botao--pequeno" type="button" data-mover="1"${i === faq.length - 1 ? ' disabled' : ''} aria-label="Descer pergunta ${i + 1}">↓</button>
          <button class="botao botao--perigo botao--pequeno" type="button" data-remover>Remover</button>
        </div>
      </div>`).join('') || '<p>Nenhuma pergunta cadastrada. A seção fica oculta no site até você adicionar uma.</p>';
  }

  lista.addEventListener('input', (e) => {
    const campo = e.target.dataset.campo;
    if (campo) faq[e.target.closest('[data-item]').dataset.item][campo] = e.target.value;
  });
  painel.addEventListener('click', (e) => {
    const i = Number(e.target.closest('[data-item]')?.dataset.item);
    const mover = e.target.closest('[data-mover]');
    if (e.target.closest('[data-adicionar]')) faq.push({ pergunta: '', resposta: '' });
    else if (e.target.closest('[data-remover]')) faq.splice(i, 1);
    else if (mover) {
      const j = i + Number(mover.dataset.mover);
      [faq[i], faq[j]] = [faq[j], faq[i]];
    } else return;
    renderizar();
  });
  aoEnviar(painel.querySelector('[data-form-faq]'), async () => {
    ({ faq } = await api('/api/admin/faq', { metodo: 'PUT', dados: faq }));
    renderizar();
    aviso('Perguntas salvas e publicadas no site.');
  });

  renderizar();
}
