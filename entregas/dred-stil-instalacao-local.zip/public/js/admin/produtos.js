// Admin > Produtos: lista, cadastro, edição e exclusão.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { brl, esc } from '../util.js';
import { enviarFotos } from './fotos.js';

const NOVO = {
  handle: '', nome: '', categoria: '', preco: 0, precoDe: 0, descricao: '', tamanhos: ['P', 'M', 'G', 'GG'], cores: [], ativo: true,
  pesoKg: 0.3, larguraCm: 20, alturaCm: 4, comprimentoCm: 28, codigoNcm: '61091000',
};

export async function montarProdutos(painel) {
  let produtos = [];
  let categorias = [];
  // "Principal › Sub" para subcategorias
  const nomeCategoria = (slug) => {
    const c = categorias.find((x) => x.slug === slug);
    const pai = c?.pai && categorias.find((x) => x.slug === c.pai);
    return c ? (pai ? `${pai.nome} › ${c.nome}` : c.nome) : slug;
  };

  async function lista() {
    [{ produtos }, { categorias }] = await Promise.all([api('/api/admin/produtos'), api('/api/admin/categorias')]);
    painel.innerHTML = `
      <div class="admin__topo">
        <h2>Produtos (${produtos.length})</h2>
        <button class="botao" type="button" data-novo>Novo produto</button>
      </div>
      ${produtos.length ? `<div class="tabela-rolagem"><table class="tabela">
        <thead><tr><th>Foto</th><th>Produto</th><th>Categoria</th><th>Preço</th><th>Situação</th><th>Curtidas</th><th><span class="so-leitor">Ações</span></th></tr></thead>
        <tbody>${produtos.map((p) => `<tr>
          <td><img src="${esc(p.cores[0]?.imagens[0] || '')}" alt=""></td>
          <td><a href="/produto/${encodeURIComponent(p.handle)}" target="_blank" rel="noopener">${esc(p.nome)}</a></td>
          <td>${esc(nomeCategoria(p.categoria))}</td>
          <td>${p.preco ? brl(p.preco) : 'Sob consulta'}</td>
          <td>${p.ativo ? '<span class="etiqueta etiqueta--ok">À venda</span>' : '<span class="etiqueta">Oculto</span>'}</td>
          <td>${p.curtidas}</td>
          <td><div class="tabela__acoes">
            <button class="botao botao--sec botao--pequeno" type="button" data-editar="${esc(p.handle)}">Editar</button>
            <button class="botao botao--perigo botao--pequeno" type="button" data-excluir="${esc(p.handle)}">Excluir</button>
          </div></td>
        </tr>`).join('')}</tbody></table></div>` : '<p>Nenhum produto cadastrado ainda.</p>'}`;
  }

  painel.addEventListener('click', async (e) => {
    if (e.target.closest('[data-novo]')) return editor(structuredClone(NOVO), null);
    const editar = e.target.closest('[data-editar]');
    if (editar) return editor(structuredClone(produtos.find((p) => p.handle === editar.dataset.editar)), editar.dataset.editar);
    const excluir = e.target.closest('[data-excluir]');
    if (excluir && confirm('Excluir este produto? Essa ação não pode ser desfeita.')) {
      try {
        await api(`/api/admin/produtos/${encodeURIComponent(excluir.dataset.excluir)}`, { metodo: 'DELETE' });
        aviso('Produto excluído.');
        lista();
      } catch (erro) {
        aviso(erro.message, { erro: true });
      }
    }
  });

  function editor(produto, handleOriginal) {
    painel.innerHTML = `
      <div class="admin__topo"><h2>${handleOriginal ? 'Editar produto' : 'Novo produto'}</h2></div>
      <form class="caixa form-grade" data-form-produto novalidate>
        <div class="form-grade form-grade--2">
          <label class="campo"><span>Nome</span><input name="nome" required maxlength="120" value="${esc(produto.nome)}"></label>
          <label class="campo"><span>Categoria</span><select name="categoria" required>
            <option value="">Escolha…</option>
            ${categorias.map((c) => `<option value="${esc(c.slug)}"${c.slug === produto.categoria ? ' selected' : ''}>${esc(nomeCategoria(c.slug))}</option>`).join('')}
            </select><small>Para criar uma categoria nova, use a aba Categorias.</small></label>
          <label class="campo"><span>Preço (R$)</span><input name="preco" type="number" min="0" step="0.01" value="${produto.preco}">
            <small>Deixe 0 para mostrar "Preço sob consulta".</small></label>
          <label class="campo"><span>Preço "de" (R$)</span><input name="precoDe" type="number" min="0" step="0.01" value="${produto.precoDe}">
            <small>Preço riscado da promoção. 0 = sem promoção.</small></label>
          <label class="campo"><span>Tamanhos</span><input name="tamanhos" required value="${esc(produto.tamanhos.join(', '))}">
            <small>Separados por vírgula. Ex.: P, M, G, GG</small></label>
          <label class="campo"><span>Endereço da página</span><input name="handle" maxlength="80" value="${esc(produto.handle)}" placeholder="gerado a partir do nome">
            <small>Fica em /produto/<em>endereço</em>.</small></label>
        </div>
        <label class="campo"><span>Descrição</span><textarea name="descricao" maxlength="2000">${esc(produto.descricao)}</textarea></label>
        <label class="campo"><span>NCM (nota fiscal)</span><input name="codigoNcm" inputmode="numeric" maxlength="10" required value="${esc(produto.codigoNcm || '61091000')}">
          <small>Código fiscal do produto, 8 números. 6109.10.00 = camiseta de malha de algodão. Confirme com o contador.</small></label>
        <fieldset class="form-grade">
          <legend><strong>Dados de cada peça para o frete</strong> <small>(informe uma camiseta dobrada; o site junta várias peças no mesmo volume quando possível)</small></legend>
          <div class="form-grade form-grade--2">
            <label class="campo"><span>Peso (kg)</span><input name="pesoKg" type="number" min="0.01" max="30" step="0.01" required value="${produto.pesoKg}"></label>
            <label class="campo"><span>Largura (cm)</span><input name="larguraCm" type="number" min="1" max="100" step="1" required value="${produto.larguraCm}"></label>
            <label class="campo"><span>Altura (cm)</span><input name="alturaCm" type="number" min="1" max="100" step="1" required value="${produto.alturaCm}"></label>
            <label class="campo"><span>Comprimento (cm)</span><input name="comprimentoCm" type="number" min="1" max="100" step="1" required value="${produto.comprimentoCm}"></label>
          </div>
        </fieldset>
        <div class="form-acoes form-acoes--inicio">
          <label class="check"><input type="checkbox" name="ativo"${produto.ativo ? ' checked' : ''}> À venda (visível na loja)</label>
        </div>
        <div class="admin__topo"><h3>Cores e fotos</h3><button class="botao botao--sec botao--pequeno" type="button" data-add-cor>Adicionar cor</button></div>
        <div class="form-grade" data-cores></div>
        <p class="erro-form" role="alert" data-erro hidden></p>
        <div class="form-acoes">
          <button class="botao botao--sec" type="button" data-cancelar>Cancelar</button>
          <button class="botao" type="submit">Salvar produto</button>
        </div>
      </form>`;

    const form = painel.querySelector('[data-form-produto]');
    const caixaCores = form.querySelector('[data-cores]');

    function renderizarCores() {
      caixaCores.innerHTML = produto.cores.map((c, i) => `
        <fieldset class="bloco-cor" data-cor="${i}">
          <legend class="so-leitor">Cor ${i + 1}</legend>
          <div class="bloco-cor__topo">
            <label class="campo"><span>Nome da cor</span><input data-campo="nome" required maxlength="40" value="${esc(c.nome)}"></label>
            <label class="campo"><span>Tom</span><input type="color" data-campo="hex" value="${esc(c.hex)}"></label>
            <button class="botao botao--perigo botao--pequeno" type="button" data-remover-cor>Remover</button>
          </div>
          <div class="fotos">
            ${c.imagens.map((src, j) => `<div class="foto"><img src="${esc(src)}" alt="Foto ${j + 1}"><button type="button" aria-label="Remover foto ${j + 1}" data-remover-foto="${j}">×</button></div>`).join('')}
            <label class="foto foto--enviar">+ Fotos<input type="file" accept="image/jpeg,image/png,image/webp" multiple data-enviar-fotos aria-label="Enviar fotos da cor"></label>
          </div>
          <small>A primeira foto é a capa. Para mudar a ordem, remova e envie de novo.</small>
        </fieldset>`).join('') || '<p>Adicione pelo menos uma cor com fotos.</p>';
    }

    caixaCores.addEventListener('input', (e) => {
      const campo = e.target.dataset.campo;
      if (campo) produto.cores[e.target.closest('[data-cor]').dataset.cor][campo] = e.target.value;
    });
    caixaCores.addEventListener('change', async (e) => {
      if (!e.target.matches('[data-enviar-fotos]')) return;
      const cor = produto.cores[e.target.closest('[data-cor]').dataset.cor];
      const rotulo = e.target.closest('label');
      rotulo.firstChild.textContent = 'Enviando…';
      try {
        cor.imagens.push(...(await enviarFotos([...e.target.files])));
      } catch (erro) {
        aviso(erro.message, { erro: true });
      }
      renderizarCores();
    });
    form.addEventListener('click', (e) => {
      const bloco = e.target.closest('[data-cor]');
      if (e.target.closest('[data-add-cor]')) produto.cores.push({ nome: '', hex: '#000000', imagens: [] });
      else if (e.target.closest('[data-remover-cor]')) produto.cores.splice(bloco.dataset.cor, 1);
      else if (e.target.closest('[data-remover-foto]')) produto.cores[bloco.dataset.cor].imagens.splice(e.target.dataset.removerFoto, 1);
      else if (e.target.closest('[data-cancelar]')) return lista();
      else return;
      renderizarCores();
    });

    aoEnviar(form, async (dados) => {
      const corpo = {
        ...dados,
        preco: Number(dados.preco),
        precoDe: Number(dados.precoDe),
        pesoKg: Number(dados.pesoKg),
        larguraCm: Number(dados.larguraCm),
        alturaCm: Number(dados.alturaCm),
        comprimentoCm: Number(dados.comprimentoCm),
        tamanhos: dados.tamanhos.split(',').map((t) => t.trim()).filter(Boolean),
        ativo: form.ativo.checked,
        cores: produto.cores,
      };
      const caminho = handleOriginal ? `/api/admin/produtos/${encodeURIComponent(handleOriginal)}` : '/api/admin/produtos';
      await api(caminho, { metodo: handleOriginal ? 'PUT' : 'POST', dados: corpo });
      aviso('Produto salvo.');
      lista();
    });

    renderizarCores();
    form.nome.focus();
  }

  lista();
}
