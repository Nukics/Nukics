// Admin > Categorias: criar, renomear, mover, ordenar, mostrar/esconder no menu e excluir.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { esc } from '../util.js';

export async function montarCategorias(painel) {
  let categorias = [];
  const principais = () => categorias.filter((c) => !c.pai);
  const filhas = (slug) => categorias.filter((c) => c.pai === slug);

  function linha(c, irmas, i) {
    const temFilhas = filhas(c.slug).length > 0;
    return `<li class="categoria${c.pai ? ' categoria--sub' : ''}" data-slug="${esc(c.slug)}">
      <label class="campo categoria__nome"><span class="so-leitor">Nome</span>
        <input value="${esc(c.nome)}" maxlength="40" data-renomear aria-label="Nome da categoria ${esc(c.nome)}"></label>
      <span class="ajuda">${c.produtos === 1 ? '1 produto' : `${c.produtos} produtos`}</span>
      <label class="campo"><span>Dentro de</span>
        <select data-pai aria-label="Categoria principal de ${esc(c.nome)}"${temFilhas ? ' disabled' : ''}>
          <option value=""${!c.pai ? ' selected' : ''}>Nenhuma (categoria principal)</option>
          ${principais().filter((p) => p.slug !== c.slug).map((p) => `<option value="${esc(p.slug)}"${p.slug === c.pai ? ' selected' : ''}>${esc(p.nome)}</option>`).join('')}
        </select>${temFilhas ? '<small>Mova as subcategorias antes de colocar esta categoria dentro de outra.</small>' : ''}</label>
      <label class="check"><input type="checkbox" data-no-menu${c.noMenu ? ' checked' : ''}> No menu</label>
      <div class="item-lista__acoes">
        <button class="botao botao--sec botao--pequeno" type="button" data-mover="-1"${i === 0 ? ' disabled' : ''} aria-label="Subir ${esc(c.nome)}">↑</button>
        <button class="botao botao--sec botao--pequeno" type="button" data-mover="1"${i === irmas.length - 1 ? ' disabled' : ''} aria-label="Descer ${esc(c.nome)}">↓</button>
        <button class="botao botao--perigo botao--pequeno" type="button" data-excluir>Excluir</button>
      </div>
    </li>`;
  }

  function renderizar() {
    const lista = principais();
    painel.querySelector('[data-lista]').innerHTML = lista.length
      ? `<ul class="categorias">${lista.map((c, i) => linha(c, lista, i) + (filhas(c.slug).length
          ? `<li><ul class="categorias categorias--sub">${filhas(c.slug).map((f, j, todas) => linha(f, todas, j)).join('')}</ul></li>` : '')).join('')}</ul>`
      : '<p>Nenhuma categoria ainda. Crie a primeira acima.</p>';
    painel.querySelector('[name="pai"]').innerHTML = `<option value="">Nenhuma (categoria principal)</option>` +
      lista.map((c) => `<option value="${esc(c.slug)}">${esc(c.nome)}</option>`).join('');
  }

  async function carregar() {
    ({ categorias } = await api('/api/admin/categorias'));
    renderizar();
  }

  painel.innerHTML = `
    <div class="admin__topo"><h2>Categorias do catálogo</h2></div>
    <form class="caixa form-grade form-grade--2" data-form-categoria>
      <label class="campo"><span>Nova categoria</span><input name="nome" required minlength="2" maxlength="40" placeholder="Ex.: Moletons"></label>
      <label class="campo"><span>Dentro de</span><select name="pai"></select>
        <small>Escolha uma categoria para criar uma subcategoria.</small></label>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <div class="form-acoes"><button class="botao" type="submit">Criar categoria</button></div>
    </form>
    <p class="ajuda">Use "Dentro de" para mover uma categoria existente ou torná-la principal. Os produtos e o endereço são mantidos. As categorias marcadas com "No menu" aparecem em <strong>Catálogo</strong> no menu do site. Para excluir uma categoria, ela não pode ter produtos nem subcategorias.</p>
    <div data-lista></div>`;

  const form = painel.querySelector('[data-form-categoria]');
  aoEnviar(form, async ({ nome, pai }) => {
    await api('/api/admin/categorias', { metodo: 'POST', dados: { nome, pai } });
    form.reset();
    aviso('Categoria criada.');
    await carregar();
  });

  const slugDe = (el) => el.closest('[data-slug]').dataset.slug;
  async function tentar(acao, mensagem) {
    try {
      await acao();
      if (mensagem) aviso(mensagem);
    } catch (erro) {
      aviso(erro.message, { erro: true });
    }
    await carregar();
  }

  painel.addEventListener('change', (e) => {
    if (e.target.matches('[data-renomear]')) {
      const nome = e.target.value.trim();
      tentar(() => api(`/api/admin/categorias/${slugDe(e.target)}`, { metodo: 'PATCH', dados: { nome } }), 'Categoria renomeada.');
    } else if (e.target.matches('[data-no-menu]')) {
      const noMenu = e.target.checked;
      tentar(() => api(`/api/admin/categorias/${slugDe(e.target)}`, { metodo: 'PATCH', dados: { noMenu } }), noMenu ? 'Agora aparece no menu.' : 'Escondida do menu.');
    } else if (e.target.matches('[data-pai]')) {
      const pai = e.target.value || null;
      tentar(() => api(`/api/admin/categorias/${slugDe(e.target)}`, { metodo: 'PATCH', dados: { pai } }), pai ? 'Categoria movida para dentro da categoria escolhida.' : 'Agora é uma categoria principal.');
    }
  });
  painel.addEventListener('click', (e) => {
    const mover = e.target.closest('[data-mover]');
    if (mover) {
      const categoria = categorias.find((c) => c.slug === slugDe(mover));
      const irmas = categorias.filter((c) => c.pai === categoria.pai).map((c) => c.slug);
      const i = irmas.indexOf(categoria.slug);
      const j = i + Number(mover.dataset.mover);
      [irmas[i], irmas[j]] = [irmas[j], irmas[i]];
      tentar(() => api('/api/admin/categorias/ordem', { metodo: 'PUT', dados: { slugs: irmas } }));
    } else if (e.target.closest('[data-excluir]')) {
      const slug = slugDe(e.target);
      if (confirm('Excluir esta categoria?')) tentar(() => api(`/api/admin/categorias/${slug}`, { metodo: 'DELETE' }), 'Categoria excluída.');
    }
  });

  carregar();
}
