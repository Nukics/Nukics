// Envio de fotos: reduz para no máximo 1600px e converte para WEBP antes de subir.
import { api } from '../api.js';

const LADO_MAXIMO = 1600;

async function reduzir(arquivo, ladoMaximo = LADO_MAXIMO) {
  const imagem = await createImageBitmap(arquivo);
  const escala = Math.min(1, ladoMaximo / Math.max(imagem.width, imagem.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(imagem.width * escala);
  canvas.height = Math.round(imagem.height * escala);
  canvas.getContext('2d').drawImage(imagem, 0, 0, canvas.width, canvas.height);
  imagem.close();
  return { dados: canvas.toDataURL('image/webp', 0.85), largura: canvas.width, altura: canvas.height };
}

// Devolve os caminhos das fotos enviadas, na mesma ordem.
export async function enviarFotos(arquivos) {
  const caminhos = [];
  for (const arquivo of arquivos) {
    if (!arquivo.type.startsWith('image/')) throw new Error(`${arquivo.name} não é uma imagem.`);
    const { dados } = await reduzir(arquivo);
    const { caminho } = await api('/api/admin/imagens', { metodo: 'POST', dados: { dados } });
    caminhos.push(caminho);
  }
  return caminhos;
}

export async function enviarBanner(arquivo) {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(arquivo?.type)) throw new Error('Envie um banner JPG, PNG ou WebP.');
  const { dados, largura, altura } = await reduzir(arquivo, 2400);
  const { caminho } = await api('/api/admin/imagens', { metodo: 'POST', dados: { dados } });
  return { imagem: caminho, largura, altura };
}
