// Admin > Vendas: faturamento (com botão para esconder os números), gráfico dos
// últimos 30 dias e produtos mais curtidos.
import { api } from '../api.js';
import { brl, esc } from '../util.js';

const CHAVE_OCULTAR = 'dredstil-admin-ocultar-valores';

function lerOcultar() {
  try {
    return localStorage.getItem(CHAVE_OCULTAR) === '1';
  } catch {
    return false;
  }
}

function gravarOcultar(valor) {
  try {
    localStorage.setItem(CHAVE_OCULTAR, valor ? '1' : '0');
  } catch {}
}

const diaCurto = (iso) => new Date(`${iso}T12:00:00`).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
const vendas = (n) => (n === 1 ? '1 venda' : `${n} vendas`);

function cartaoNumero(rotulo, { faturamento, vendas: qtd }) {
  return `<div class="numero">
    <span>${rotulo}</span>
    <strong data-valor>${brl(faturamento)}</strong>
    <span data-valor>${vendas(qtd)}</span>
  </div>`;
}

// Barras do faturamento diário (uma série: sem legenda; dica ao passar o mouse ou focar).
function grafico(porDia) {
  const maior = Math.max(...porDia.map((d) => d.faturamento), 1);
  const barras = porDia
    .map((d) => {
      const altura = d.faturamento ? Math.max(2, (d.faturamento / maior) * 100) : 0;
      const dica = `${diaCurto(d.dia)}: ${brl(d.faturamento)} · ${vendas(d.vendas)}`;
      return `<div class="grafico__coluna" tabindex="0" data-dica="${esc(dica)}" aria-label="${esc(dica)}">
        <div class="grafico__barra" style="height:${altura}%"></div></div>`;
    })
    .join('');
  return `<div class="grafico" data-valor>
    <div class="grafico__area" role="img" aria-label="Faturamento por dia nos últimos 30 dias">${barras}</div>
    <div class="grafico__eixo"><span>${diaCurto(porDia[0].dia)}</span><span>hoje</span></div>
  </div>
  <details class="grafico__tabela" data-valor>
    <summary>Ver em tabela</summary>
    <div class="tabela-rolagem"><table class="tabela">
      <thead><tr><th>Dia</th><th>Vendas</th><th>Faturamento</th></tr></thead>
      <tbody>${[...porDia].reverse().map((d) => `<tr><td>${diaCurto(d.dia)}</td><td>${d.vendas}</td><td>${brl(d.faturamento)}</td></tr>`).join('')}</tbody>
    </table></div>
  </details>`;
}

export async function montarVendas(painel) {
  const r = await api('/api/admin/vendas');
  const { resumo } = r;
  const ticketMedio = resumo.total.vendas ? resumo.total.faturamento / resumo.total.vendas : 0;

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Vendas e faturamento</h2>
      <button class="botao botao--sec botao--pequeno" type="button" aria-pressed="false" data-ocultar></button>
    </div>
    ${resumo.aguardando ? `<p class="aviso-admin">${resumo.aguardando === 1 ? '1 pedido aguardando' : `${resumo.aguardando} pedidos aguardando`} confirmação de pagamento. <a href="#pedidos" data-ir-aba="pedidos">Ver pedidos</a></p>` : ''}
    <div class="numeros numeros--4">
      ${cartaoNumero('Hoje', resumo.hoje)}
      ${cartaoNumero('Últimos 7 dias', resumo.seteDias)}
      ${cartaoNumero('Este mês', resumo.mes)}
      ${cartaoNumero('Desde o início', resumo.total)}
    </div>
    <div class="numeros numeros--4">
      <div class="numero"><span>Ticket médio</span><strong data-valor>${brl(ticketMedio)}</strong></div>
      <div class="numero"><span>Clientes cadastrados</span><strong>${r.clientes}</strong></div>
      <div class="numero"><span>Produtos à venda</span><strong>${r.produtosAtivos}</strong><span>${r.produtos} no total</span></div>
    </div>
    <div class="caixa">
      <h3>Faturamento por dia (últimos 30 dias)</h3>
      ${grafico(r.porDia)}
      <p class="ajuda">Contam como venda os pedidos marcados como Pago, Enviado ou Entregue.</p>
    </div>
    <div class="caixa">
      <h3>Mais curtidos</h3>
      ${r.maisCurtidos.length
        ? `<ol>${r.maisCurtidos.map((p) => `<li><a href="/produto/${encodeURIComponent(p.handle)}">${esc(p.nome)}</a> — ${p.curtidas}</li>`).join('')}</ol>`
        : '<p>Nenhum produto cadastrado ainda.</p>'}
    </div>`;

  const botao = painel.querySelector('[data-ocultar]');
  function aplicar(ocultar) {
    painel.classList.toggle('valores-ocultos', ocultar);
    botao.setAttribute('aria-pressed', ocultar);
    botao.textContent = ocultar ? 'Mostrar valores' : 'Esconder valores';
  }
  botao.addEventListener('click', () => {
    const ocultar = !painel.classList.contains('valores-ocultos');
    gravarOcultar(ocultar);
    aplicar(ocultar);
  });
  aplicar(lerOcultar());
}
