// Admin > Pedidos: lista filtrável e troca de situação (Pago, Enviado, Entregue...).
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { SITUACOES_PEDIDO, brl, dataCurta, esc } from '../util.js';

const opcoesSituacao = (atual) =>
  Object.entries(SITUACOES_PEDIDO).map(([valor, rotulo]) => `<option value="${valor}"${valor === atual ? ' selected' : ''}>${rotulo}</option>`).join('');

// Entrega e pagamento dos pedidos feitos pelo checkout (os do WhatsApp não têm).
function htmlEntrega(p) {
  if (!p.entrega) return '<span class="ajuda">Combinar pelo WhatsApp</span>';
  const { cliente, endereco: e } = p.entrega;
  return `${esc(p.freteNome || '')}${p.frete ? ` · ${brl(p.frete)}` : ''}<br>
    <details><summary>Endereço e dados</summary>
      ${esc(cliente.nome)} · CPF ${esc(cliente.cpf)} · ${esc(cliente.telefone)}<br>
      ${esc(e.rua)}, ${esc(e.numero)}${e.complemento ? ` - ${esc(e.complemento)}` : ''} · ${esc(e.bairro)} · ${esc(e.cidade)}/${esc(e.uf)} · CEP ${esc(e.cep)}
    </details>
    <form class="rastreio" data-rastreio="${esc(p.id)}">
      <input name="rastreio" maxlength="40" placeholder="Código de rastreio" aria-label="Código de rastreio do pedido #${p.numero}" value="${esc(p.rastreio || '')}">
      <button class="botao botao--sec botao--pequeno" type="submit">Salvar</button>
    </form>`;
}

const VENDA = ['pago', 'enviado', 'entregue'];

// Nota fiscal do pedido: emitir, acompanhar e reenviar ao cliente.
function htmlNota(p, ativa) {
  const n = p.nota;
  if (n?.status === 'autorizada') {
    return `NF nº ${esc(n.numero || '')}${n.urlDanfe ? ` · <a href="${esc(n.urlDanfe)}" target="_blank" rel="noopener noreferrer">DANFE</a>` : ''}
      ${n.urlXml ? ` · <a href="${esc(n.urlXml)}" target="_blank" rel="noopener noreferrer">XML</a>` : ''}<br>
      <span class="ajuda">${n.emailEnviadoEm ? 'Enviada ao cliente' : 'Ainda não enviada'}</span>
      <button class="botao botao--sec botao--pequeno" type="button" data-nota-email="${esc(n.id)}">Reenviar e-mail</button>`;
  }
  if (n?.status === 'processando') {
    return `<span class="etiqueta etiqueta--aguardando">Em emissão</span>
      <button class="botao botao--sec botao--pequeno" type="button" data-nota-atualizar="${esc(n.id)}">Atualizar</button>`;
  }
  if (!VENDA.includes(p.status)) return '<span class="ajuda">Após o pagamento</span>';
  if (!p.entrega) return '<span class="ajuda">Pedido do WhatsApp: emitir pelo emissor</span>';
  if (!ativa) return '<span class="ajuda">Emissor não configurado</span>';
  const erro = n?.status === 'erro' ? `<span class="erro-form">Recusada: ${esc(n.mensagem || '')}</span><br>` : '';
  return `${erro}<button class="botao botao--pequeno" type="button" data-emitir-nota="${esc(p.id)}">${erro ? 'Emitir de novo' : 'Emitir nota fiscal'}</button>`;
}

function htmlCliente(p) {
  if (!p.cliente) return '<span class="ajuda">Sem conta (combinado pelo WhatsApp)</span>';
  const whats = p.cliente.telefone.replace(/\D/g, '');
  return `${esc(p.cliente.nome)}<br><a href="mailto:${esc(p.cliente.email)}">${esc(p.cliente.email)}</a>` +
    (whats ? `<br><a href="https://wa.me/55${esc(whats)}" target="_blank" rel="noopener noreferrer">${esc(p.cliente.telefone)}</a>` : '');
}

export async function montarPedidos(painel) {
  const estado = { status: '', pagina: 1 };

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Pedidos</h2>
      <select class="catalogo__ordem" aria-label="Filtrar pedidos por situação" data-filtro>
        <option value="">Todas as situações</option>${opcoesSituacao('')}
      </select>
    </div>
    <p class="ajuda">Pagamentos online confirmados mudam para <strong>Pago</strong> automaticamente. Pedidos combinados pelo WhatsApp você atualiza aqui. <strong>Em análise</strong> = pagamento com valor diferente ou confirmado após cancelamento/expiração: confira no painel da Getnet. Só <strong>Pago</strong>, <strong>Enviado</strong> ou <strong>Entregue</strong> contam no faturamento.</p>
    <div data-lista aria-live="polite"></div>`;

  async function carregar() {
    const r = await api(`/api/admin/pedidos?${new URLSearchParams(estado)}`);
    estado.pagina = r.pagina;
    painel.querySelector('[data-lista]').innerHTML = r.pedidos.length
      ? `<p class="catalogo__total">${r.total} ${r.total === 1 ? 'pedido' : 'pedidos'}</p>
        <div class="tabela-rolagem"><table class="tabela">
          <thead><tr><th>Pedido</th><th>Data</th><th>Cliente</th><th>Itens</th><th>Entrega</th><th>Total</th><th>Situação</th><th>Nota fiscal</th></tr></thead>
          <tbody>${r.pedidos.map((p) => `<tr>
            <td><strong>#${p.numero}</strong></td>
            <td>${dataCurta(p.criadoEm)}</td>
            <td>${htmlCliente(p)}</td>
            <td>${p.itens.map((i) => `${i.qtd}x ${esc(i.nome)} <span class="ajuda">(${esc(i.cor)} / ${esc(i.tamanho)})</span>`).join('<br>')}</td>
            <td>${htmlEntrega(p)}</td>
            <td>${p.total ? brl(p.total) : 'A combinar'}${p.pagamentoMetodo === 'pix' ? '<br><span class="ajuda">Pix</span>' : ''}${p.pagamentoMetodo === 'getnet-checkout' ? `<br><span class="ajuda">Getnet · ${p.pagamentoStatus === 'reconciliar' ? 'conferir tentativa pelo ID do pedido' : esc(p.pagamentoStatus || 'pendente')}</span>` : ''}</td>
            <td><select class="catalogo__ordem" aria-label="Situação do pedido #${p.numero}" data-situacao="${esc(p.id)}">${opcoesSituacao(p.status)}</select></td>
            <td>${htmlNota(p, r.notasAtivas)}</td>
          </tr>`).join('')}</tbody>
        </table></div>
        ${r.paginas > 1 ? `<div class="paginacao">
          <button class="botao botao--sec botao--pequeno" type="button" data-ir="${r.pagina - 1}"${r.pagina === 1 ? ' disabled' : ''}>Anterior</button>
          <span>Página ${r.pagina} de ${r.paginas}</span>
          <button class="botao botao--sec botao--pequeno" type="button" data-ir="${r.pagina + 1}"${r.pagina === r.paginas ? ' disabled' : ''}>Próxima</button>
        </div>` : ''}`
      : '<p>Nenhum pedido encontrado.</p>';
  }

  painel.addEventListener('change', async (e) => {
    if (e.target.matches('[data-filtro]')) {
      Object.assign(estado, { status: e.target.value, pagina: 1 });
      return carregar();
    }
    const select = e.target.closest('[data-situacao]');
    if (!select) return;
    try {
      await api(`/api/admin/pedidos/${encodeURIComponent(select.dataset.situacao)}`, { metodo: 'PATCH', dados: { status: select.value } });
      aviso(`Situação atualizada: ${SITUACOES_PEDIDO[select.value]}.`);
    } catch (erro) {
      aviso(erro.message, { erro: true });
      carregar();
    }
  });
  painel.addEventListener('submit', async (e) => {
    const form = e.target.closest('[data-rastreio]');
    if (!form) return;
    e.preventDefault();
    try {
      await api(`/api/admin/pedidos/${encodeURIComponent(form.dataset.rastreio)}`, { metodo: 'PATCH', dados: { rastreio: form.rastreio.value.trim() } });
      aviso('Código de rastreio salvo.');
    } catch (erro) {
      aviso(erro.message, { erro: true });
    }
  });
  // Ações da nota fiscal
  painel.addEventListener('click', async (e) => {
    const botao = e.target.closest('[data-emitir-nota], [data-nota-atualizar], [data-nota-email]');
    if (!botao) return;
    botao.disabled = true;
    try {
      if (botao.dataset.emitirNota) {
        if (!confirm('Emitir a nota fiscal deste pedido? Depois de autorizada, ela é enviada ao e-mail do cliente.')) return;
        const { nota } = await api(`/api/admin/pedidos/${encodeURIComponent(botao.dataset.emitirNota)}/nota`, { metodo: 'POST' });
        aviso(nota.status === 'erro' ? `Nota recusada: ${nota.mensagem}` : 'Nota enviada para emissão. Clique em Atualizar em alguns instantes.', { erro: nota.status === 'erro' });
      } else if (botao.dataset.notaAtualizar) {
        const { nota } = await api(`/api/admin/notas/${encodeURIComponent(botao.dataset.notaAtualizar)}/atualizar`, { metodo: 'POST' });
        aviso(nota.status === 'autorizada' ? 'Nota autorizada e enviada ao cliente.' : nota.status === 'erro' ? `Nota recusada: ${nota.mensagem}` : 'Ainda em emissão. Tente de novo em instantes.');
      } else {
        await api(`/api/admin/notas/${encodeURIComponent(botao.dataset.notaEmail)}/email`, { metodo: 'POST' });
        aviso('Nota reenviada ao e-mail do cliente.');
      }
      await carregar();
    } catch (erro) {
      aviso(erro.message, { erro: true });
    } finally {
      botao.disabled = false;
    }
  });
  painel.addEventListener('click', (e) => {
    const ir = e.target.closest('[data-ir]');
    if (!ir) return;
    estado.pagina = Number(ir.dataset.ir);
    carregar();
  });

  carregar();
}
