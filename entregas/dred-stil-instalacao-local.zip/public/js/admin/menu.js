// Admin > Menu: itens do menu do site (categorias, páginas, links), ordem e visibilidade.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { esc } from '../util.js';

const TIPOS = {
  catalogo: 'Catálogo (abre as categorias)',
  categoria: 'Categoria',
  pagina: 'Página de texto',
  link: 'Link',
};

const opcoes = (lista, atual) =>
  lista.map(([valor, rotulo]) => `<option value="${esc(valor)}"${valor === atual ? ' selected' : ''}>${esc(rotulo)}</option>`).join('');

export async function montarMenu(painel) {
  const [{ menu, paginas }, { categorias }] = await Promise.all([api('/api/admin/conteudo'), api('/api/admin/categorias')]);
  let itens = menu;
  const listaCategorias = categorias.map((c) => [c.slug, c.pai ? `— ${c.nome}` : c.nome]);
  const listaPaginas = paginas.map((p) => [p.endereco, p.titulo]);

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Menu do site</h2>
      <div class="form-acoes">
        <label class="so-leitor" for="novo-item-menu">Tipo do novo item</label>
        <select class="catalogo__ordem" id="novo-item-menu" data-tipo-novo>${opcoes(Object.entries(TIPOS), 'categoria')}</select>
        <button class="botao botao--sec" type="button" data-novo-item>Adicionar item</button>
      </div>
    </div>
    <p class="ajuda">Itens de categoria mostram as subcategorias ao passar o mouse. O link "Admin" só aparece para você e não entra nesta lista.</p>
    <form class="form-grade" data-form-menu>
      <div class="form-grade" data-itens></div>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <div class="form-acoes"><button class="botao" type="submit">Salvar menu</button></div>
    </form>`;
  const caixa = painel.querySelector('[data-itens]');

  function campoDoTipo(item) {
    if (item.tipo === 'categoria') {
      return `<label class="campo"><span>Categoria</span><select data-campo="categoria">${opcoes([['', 'Escolha…'], ...listaCategorias], item.categoria || '')}</select></label>`;
    }
    if (item.tipo === 'pagina') {
      return `<label class="campo"><span>Página</span><select data-campo="pagina">${opcoes([['', 'Escolha…'], ...listaPaginas], item.pagina || '')}</select></label>`;
    }
    if (item.tipo === 'link') {
      return `<label class="campo"><span>Endereço</span><input data-campo="link" maxlength="200" placeholder="/catalogo?q=oversized" value="${esc(item.link || '')}"></label>`;
    }
    return '<p class="ajuda">Leva ao catálogo completo e mostra todas as categorias marcadas "No menu".</p>';
  }

  function renderizar() {
    caixa.innerHTML = itens.map((item, i) => `
      <fieldset class="item-lista${item.visivel ? '' : ' item-lista--oculto'}" data-item="${i}">
        <legend class="so-leitor">Item ${i + 1}</legend>
        <div class="form-grade form-grade--2">
          <label class="campo"><span>Nome no menu · ${TIPOS[item.tipo]}</span><input data-campo="rotulo" required maxlength="30" value="${esc(item.rotulo)}"></label>
          ${campoDoTipo(item)}
        </div>
        <div class="item-lista__acoes">
          <label class="check"><input type="checkbox" data-campo="visivel"${item.visivel ? ' checked' : ''}> Aparece no site</label>
          <button class="botao botao--sec botao--pequeno" type="button" data-mover="-1"${i === 0 ? ' disabled' : ''} aria-label="Subir item">↑</button>
          <button class="botao botao--sec botao--pequeno" type="button" data-mover="1"${i === itens.length - 1 ? ' disabled' : ''} aria-label="Descer item">↓</button>
          <button class="botao botao--perigo botao--pequeno" type="button" data-remover>Remover</button>
        </div>
      </fieldset>`).join('') || '<p>O menu está vazio.</p>';
  }

  const indice = (el) => Number(el.closest('[data-item]').dataset.item);

  caixa.addEventListener('input', (e) => {
    const campo = e.target.dataset.campo;
    if (!campo) return;
    itens[indice(e.target)][campo] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    if (campo === 'visivel') e.target.closest('[data-item]').classList.toggle('item-lista--oculto', !e.target.checked);
  });
  painel.addEventListener('click', (e) => {
    const alvo = e.target.closest('button');
    if (!alvo) return;
    if ('novoItem' in alvo.dataset) {
      const tipo = painel.querySelector('[data-tipo-novo]').value;
      itens.push({ tipo, rotulo: tipo === 'catalogo' ? 'Catálogo' : '', visivel: true });
    } else if (alvo.dataset.mover) {
      const i = indice(alvo);
      const j = i + Number(alvo.dataset.mover);
      [itens[i], itens[j]] = [itens[j], itens[i]];
    } else if ('remover' in alvo.dataset) itens.splice(indice(alvo), 1);
    else return;
    renderizar();
  });

  aoEnviar(painel.querySelector('[data-form-menu]'), async () => {
    ({ menu: itens } = await api('/api/admin/menu', { metodo: 'PUT', dados: itens }));
    renderizar();
    aviso('Menu salvo. Recarregue o site para ver.');
  });

  renderizar();
}
