// Admin > Destaques: abas da seção Destaques da página inicial e os produtos de cada uma.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { esc } from '../util.js';

const mover = (lista, i, passo) => {
  const j = i + passo;
  [lista[i], lista[j]] = [lista[j], lista[i]];
};

export async function montarDestaques(painel) {
  const [{ destaques }, { produtos }] = await Promise.all([api('/api/admin/conteudo'), api('/api/admin/produtos')]);
  let abas = destaques;
  const produto = (handle) => produtos.find((p) => p.handle === handle);

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Destaques da página inicial</h2>
      <button class="botao botao--sec" type="button" data-nova-aba>Nova aba</button>
    </div>
    <p class="ajuda">Cada aba aparece como um título na seção Destaques (ex.: Lançamentos, Mais vendidos). Escolha os produtos de cada aba e a ordem em que aparecem. Produtos ocultos não aparecem no site.</p>
    <form class="form-grade" data-form-destaques>
      <div class="form-grade" data-abas></div>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <div class="form-acoes"><button class="botao" type="submit">Salvar destaques</button></div>
    </form>`;
  const caixa = painel.querySelector('[data-abas]');

  function htmlAba(aba, i) {
    const disponiveis = produtos.filter((p) => !aba.produtos.includes(p.handle));
    return `<fieldset class="item-lista" data-aba="${i}">
      <legend class="so-leitor">Aba ${i + 1}</legend>
      <div class="bloco-cor__topo">
        <label class="campo"><span>Nome da aba</span><input data-nome-aba required minlength="2" maxlength="40" value="${esc(aba.nome)}"></label>
        <div class="item-lista__acoes">
          <button class="botao botao--sec botao--pequeno" type="button" data-mover-aba="-1"${i === 0 ? ' disabled' : ''} aria-label="Subir aba">↑</button>
          <button class="botao botao--sec botao--pequeno" type="button" data-mover-aba="1"${i === abas.length - 1 ? ' disabled' : ''} aria-label="Descer aba">↓</button>
          <button class="botao botao--perigo botao--pequeno" type="button" data-remover-aba>Remover aba</button>
        </div>
      </div>
      <ol class="escolhidos">${aba.produtos.map((h, j) => {
        const p = produto(h);
        return `<li class="escolhido" data-produto="${j}">
          <img src="${esc(p?.cores[0]?.imagens[0] || '')}" alt="">
          <span>${esc(p?.nome || h)}${p && !p.ativo ? ' <span class="etiqueta">Oculto</span>' : ''}</span>
          <div class="item-lista__acoes">
            <button class="botao botao--sec botao--pequeno" type="button" data-mover-produto="-1"${j === 0 ? ' disabled' : ''} aria-label="Subir produto">↑</button>
            <button class="botao botao--sec botao--pequeno" type="button" data-mover-produto="1"${j === aba.produtos.length - 1 ? ' disabled' : ''} aria-label="Descer produto">↓</button>
            <button class="botao botao--perigo botao--pequeno" type="button" data-tirar-produto aria-label="Tirar ${esc(p?.nome || h)} da aba">Tirar</button>
          </div>
        </li>`;
      }).join('') || '<li class="ajuda">Nenhum produto nesta aba ainda.</li>'}</ol>
      ${disponiveis.length ? `<label class="campo"><span>Adicionar produto</span>
        <select data-adicionar-produto><option value="">Escolha um produto…</option>
          ${disponiveis.map((p) => `<option value="${esc(p.handle)}">${esc(p.nome)}</option>`).join('')}</select></label>` : ''}
    </fieldset>`;
  }

  function renderizar() {
    caixa.innerHTML = abas.map(htmlAba).join('') || '<p>Nenhuma aba criada: a seção Destaques fica oculta no site.</p>';
  }

  const indiceAba = (el) => Number(el.closest('[data-aba]').dataset.aba);

  caixa.addEventListener('input', (e) => {
    if (e.target.matches('[data-nome-aba]')) abas[indiceAba(e.target)].nome = e.target.value;
  });
  caixa.addEventListener('change', (e) => {
    if (!e.target.matches('[data-adicionar-produto]') || !e.target.value) return;
    abas[indiceAba(e.target)].produtos.push(e.target.value);
    renderizar();
  });
  painel.addEventListener('click', (e) => {
    const alvo = e.target.closest('button');
    if (!alvo) return;
    if ('novaAba' in alvo.dataset) abas.push({ nome: '', produtos: [] });
    else if (!alvo.closest('[data-aba]')) return;
    else {
      const i = indiceAba(alvo);
      const j = Number(alvo.closest('[data-produto]')?.dataset.produto);
      if (alvo.dataset.moverAba) mover(abas, i, Number(alvo.dataset.moverAba));
      else if ('removerAba' in alvo.dataset) abas.splice(i, 1);
      else if (alvo.dataset.moverProduto) mover(abas[i].produtos, j, Number(alvo.dataset.moverProduto));
      else if ('tirarProduto' in alvo.dataset) abas[i].produtos.splice(j, 1);
      else return;
    }
    renderizar();
  });

  aoEnviar(painel.querySelector('[data-form-destaques]'), async () => {
    ({ destaques: abas } = await api('/api/admin/destaques', { metodo: 'PUT', dados: abas }));
    renderizar();
    aviso('Destaques salvos e publicados na página inicial.');
  });

  renderizar();
}
