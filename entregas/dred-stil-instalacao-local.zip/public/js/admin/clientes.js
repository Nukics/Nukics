// Admin > Clientes: busca, compras, selo de bom cliente e link de nova senha para quem esqueceu.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { carregarUsuario } from '../estado.js';
import { dataCurta, esc, seloBomCliente } from '../util.js';

export async function montarClientes(painel) {
  const eu = await carregarUsuario();
  const estado = { busca: '', pagina: 1 };

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Clientes</h2>
      <form class="catalogo__busca" role="search" data-busca>
        <input type="search" name="busca" placeholder="Buscar por nome ou e-mail" aria-label="Buscar clientes" maxlength="80">
        <button class="botao" type="submit">Buscar</button>
      </form>
    </div>
    <div class="caixa" role="status" data-senha-gerada hidden></div>
    <div data-tabela aria-live="polite"></div>`;

  // Envia ao cliente o link para criar a nova senha (o admin não vê a senha).
  // Sem e-mail configurado na loja, gera uma senha temporária para repassar.
  async function gerarSenha(botao) {
    const nome = botao.dataset.nome;
    const id = encodeURIComponent(botao.dataset.novaSenha);
    if (!confirm(`Enviar para ${nome} um link de nova senha por e-mail?`)) return;
    try {
      aviso((await api(`/api/admin/clientes/${id}/redefinir`, { metodo: 'POST' })).mensagem);
      return;
    } catch (erro) {
      if (erro.status !== 503) throw erro;
      if (!confirm('O envio de e-mail ainda não está configurado. Gerar uma senha temporária? A senha atual deixa de funcionar.')) return;
    }
    const { senha } = await api(`/api/admin/clientes/${id}/senha`, { metodo: 'POST' });
    const caixa = painel.querySelector('[data-senha-gerada]');
    caixa.innerHTML = `<p>Senha temporária de <strong>${esc(nome)}</strong>: <code>${esc(senha)}</code></p>
      <p>Envie ao cliente e peça para trocá-la em <em>Minha conta</em> depois de entrar.</p>`;
    caixa.hidden = false;
    caixa.scrollIntoView({ block: 'nearest' });
  }

  async function carregar() {
    const params = new URLSearchParams({ busca: estado.busca, pagina: estado.pagina });
    const r = await api(`/api/admin/clientes?${params}`);
    estado.pagina = r.pagina;
    painel.querySelector('[data-tabela]').innerHTML = r.clientes.length
      ? `<p class="catalogo__total">${r.total} ${r.total === 1 ? 'conta' : 'contas'} · com ${r.comprasBomCliente} compras ou mais o cliente ganha o selo Bom cliente</p>
        <div class="tabela-rolagem"><table class="tabela">
          <thead><tr><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Desde</th><th>Compras</th><th>Curtidas</th><th>Acesso</th><th><span class="so-leitor">Ações</span></th></tr></thead>
          <tbody>${r.clientes.map((c) => `<tr>
            <td>${esc(c.nome)}${c.apelido ? `<br><span class="ajuda">@${esc(c.apelido)}</span>` : ''}${c.bomCliente ? `<br>${seloBomCliente()}` : ''}</td>
            <td><a href="mailto:${esc(c.email)}">${esc(c.email)}</a></td>
            <td>${esc(c.telefone || '—')}</td>
            <td>${dataCurta(c.criadoEm)}</td>
            <td>${c.compras}</td>
            <td>${c.curtidas.length}</td>
            <td><span class="etiqueta${c.papel === 'admin' ? ' etiqueta--ok' : ''}">${c.papel === 'admin' ? 'Admin' : 'Cliente'}</span></td>
            <td><div class="tabela__acoes">
              <button class="botao botao--sec botao--pequeno" type="button" data-notas="${esc(c.id)}">Notas fiscais</button>${c.id === eu.id ? '' : `
              <button class="botao botao--sec botao--pequeno" type="button" data-nova-senha="${esc(c.id)}" data-nome="${esc(c.nome)}">Enviar link de nova senha</button>`}</div></td>
          </tr><tr hidden data-notas-de="${esc(c.id)}"><td colspan="8"></td></tr>`).join('')}</tbody>
        </table></div>
        ${r.paginas > 1 ? `<div class="paginacao">
          <button class="botao botao--sec botao--pequeno" type="button" data-ir="${r.pagina - 1}"${r.pagina === 1 ? ' disabled' : ''}>Anterior</button>
          <span>Página ${r.pagina} de ${r.paginas}</span>
          <button class="botao botao--sec botao--pequeno" type="button" data-ir="${r.pagina + 1}"${r.pagina === r.paginas ? ' disabled' : ''}>Próxima</button>
        </div>` : ''}`
      : '<p>Nenhuma conta encontrada.</p>';
  }

  painel.querySelector('[data-busca]').addEventListener('submit', (e) => {
    e.preventDefault();
    Object.assign(estado, { busca: e.target.busca.value.trim(), pagina: 1 });
    carregar();
  });
  painel.addEventListener('click', async (e) => {
    const ir = e.target.closest('[data-ir]');
    if (ir) {
      estado.pagina = Number(ir.dataset.ir);
      return carregar();
    }
    const botaoNotas = e.target.closest('[data-notas]');
    if (botaoNotas) {
      const linha = painel.querySelector(`[data-notas-de="${CSS.escape(botaoNotas.dataset.notas)}"]`);
      if (!linha.hidden) return (linha.hidden = true);
      try {
        const { notas } = await api(`/api/admin/clientes/${encodeURIComponent(botaoNotas.dataset.notas)}/notas`);
        const situacao = { autorizada: 'Autorizada', processando: 'Em emissão', erro: 'Recusada', cancelada: 'Cancelada' };
        linha.querySelector('td').innerHTML = notas.length
          ? `<ul class="historico">${notas.map((n) => `<li>${dataCurta(n.criadoEm)} · ${situacao[n.status] || n.status}${n.numero ? ` · NF nº ${esc(n.numero)}` : ''}
              ${n.urlDanfe ? ` · <a href="${esc(n.urlDanfe)}" target="_blank" rel="noopener noreferrer">DANFE</a>` : ''}
              ${n.urlXml ? ` · <a href="${esc(n.urlXml)}" target="_blank" rel="noopener noreferrer">XML</a>` : ''}</li>`).join('')}</ul>`
          : '<span class="ajuda">Nenhuma nota fiscal emitida para este cliente.</span>';
        linha.hidden = false;
      } catch (erro) {
        aviso(erro.message, { erro: true });
      }
      return;
    }
    const novaSenha = e.target.closest('[data-nova-senha]');
    if (!novaSenha) return;
    try {
      await gerarSenha(novaSenha);
    } catch (erro) {
      aviso(erro.message, { erro: true });
    }
  });

  carregar();
}
