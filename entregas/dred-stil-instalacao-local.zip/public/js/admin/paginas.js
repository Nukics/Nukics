// Admin > Páginas: textos de Quem somos, Trocas e devoluções, Onde estamos etc.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { esc } from '../util.js';

export async function montarPaginas(painel) {
  const { paginas } = await api('/api/admin/conteudo');
  let atual = paginas[0];

  painel.innerHTML = `
    <div class="admin__topo">
      <h2>Textos das páginas</h2>
      <label class="so-leitor" for="pagina-editada">Página</label>
      <select class="catalogo__ordem" id="pagina-editada" data-escolher>
        ${paginas.map((p, i) => `<option value="${i}">${esc(p.titulo)}</option>`).join('')}
      </select>
    </div>
    <form class="caixa form-grade" data-form-pagina>
      <label class="campo"><span data-titulo></span><textarea name="texto" class="campo__texto-longo" required maxlength="20000"></textarea></label>
      <details class="ajuda-formato">
        <summary>Como formatar o texto</summary>
        <ul>
          <li>Deixe uma <strong>linha em branco</strong> entre os parágrafos.</li>
          <li><code>## Título</code> no começo da linha cria um subtítulo.</li>
          <li><code>- item</code> cria uma lista; <code>1. item</code> cria uma lista numerada.</li>
          <li><code>**texto**</code> deixa em <strong>negrito</strong>.</li>
          <li><code>[texto do link](/trocas-e-devolucoes)</code> cria um link.</li>
        </ul>
      </details>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <div class="form-acoes">
        <a class="botao botao--sec" target="_blank" rel="noopener" data-ver>Ver página</a>
        <button class="botao" type="submit">Salvar texto</button>
      </div>
    </form>`;

  const form = painel.querySelector('[data-form-pagina]');
  function mostrar(pagina) {
    atual = pagina;
    form.texto.value = pagina.texto;
    painel.querySelector('[data-titulo]').textContent = `Texto da página "${pagina.titulo}"`;
    painel.querySelector('[data-ver]').href = `/${pagina.endereco}`;
  }

  painel.querySelector('[data-escolher]').addEventListener('change', (e) => mostrar(paginas[Number(e.target.value)]));
  aoEnviar(form, async ({ texto }) => {
    const { pagina } = await api(`/api/admin/paginas/${atual.endereco}`, { metodo: 'PUT', dados: { texto } });
    atual.texto = pagina.texto;
    aviso('Texto salvo e publicado.');
  });

  mostrar(atual);
}
