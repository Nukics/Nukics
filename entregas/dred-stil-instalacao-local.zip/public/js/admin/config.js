// Admin > Configurações: contato, parcelas, faixa promocional, redes sociais e banners.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { aoEnviar } from '../formulario.js';
import { esc } from '../util.js';
import { enviarBanner } from './fotos.js';

const REDES = { instagram: 'Instagram', facebook: 'Facebook', tiktok: 'TikTok', youtube: 'YouTube' };

export async function montarConfig(painel) {
  const { config } = await api('/api/admin/conteudo');
  const banners = (config.banners || []).map((b) => ({ ...b, focoX: b.focoX ?? 50, focoY: b.focoY ?? 50, zoom: b.zoom ?? 100,
    focoMobileX: b.focoMobileX ?? b.focoX ?? 50, focoMobileY: b.focoMobileY ?? b.focoY ?? 50,
    zoomMobile: b.zoomMobile ?? b.zoom ?? 100 }));

  painel.innerHTML = `
    <form class="form-grade" data-form-config>
      <div class="caixa form-grade">
        <h3>Contato e vendas</h3>
        <div class="form-grade form-grade--2">
          <label class="campo"><span>WhatsApp dos pedidos</span><input name="whatsapp" inputmode="numeric" maxlength="20" value="${esc(config.whatsapp)}">
            <small>DDI 55 + DDD + número, só dígitos. Ex.: 5541999999999</small></label>
          <label class="campo"><span>Telefone exibido</span><input name="telefone" maxlength="20" value="${esc(config.telefone)}"></label>
          <label class="campo"><span>E-mail para receber respostas</span><input name="emailResposta" type="email" maxlength="160" value="${esc(config.emailResposta)}">
            <small>As respostas dos clientes vão para este e-mail. O remetente continua sendo o domínio verificado no Resend.</small></label>
          <label class="campo"><span>Parcelas sem juros</span><input name="parcelas" type="number" min="1" max="12" value="${config.parcelas || 1}"></label>
          <label class="campo"><span>Faixa promocional</span><input name="mensagemPromocional" maxlength="120" value="${esc(config.mensagemPromocional)}">
            <small>Texto que rola no topo do site. Vazio = sem faixa.</small></label>
        </div>
      </div>
      <div class="caixa form-grade">
        <h3>Redes sociais</h3>
        <div class="form-grade form-grade--2">
          ${Object.entries(REDES).map(([chave, nome]) => `<label class="campo"><span>${nome}</span>
            <input name="${chave}" type="url" maxlength="300" placeholder="https://" value="${esc(config.redesSociais?.[chave])}"></label>`).join('')}
        </div>
        <small>Os ícones aparecem no rodapé só para as redes preenchidas.</small>
      </div>
      <div class="caixa form-grade">
        <div class="admin__topo"><h3>Banners da página inicial</h3>
          <label class="botao botao--sec botao--pequeno">Adicionar banner<input class="so-leitor" type="file" accept="image/jpeg,image/png,image/webp" data-enviar-banner></label></div>
        <p class="ajuda">A imagem preenche toda a largura. Ajuste o enquadramento nas prévias e use o zoom para retirar bordas da própria foto. Desktop: proporção 3:1; celular: 4:3. As duas versões usam a mesma imagem, com ajustes independentes.</p>
        <div class="form-grade" data-banners></div>
      </div>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <div class="form-acoes"><button class="botao" type="submit">Salvar configurações</button></div>
    </form>`;

  const form = painel.querySelector('[data-form-config]');
  const caixa = form.querySelector('[data-banners]');
  const AJUSTES = ['focoX', 'focoY', 'zoom', 'focoMobileX', 'focoMobileY', 'zoomMobile'];
  const estilo = (b, mobile = false) => {
    const x = Number(mobile ? b.focoMobileX : b.focoX) || 0;
    const y = Number(mobile ? b.focoMobileY : b.focoY) || 0;
    const zoom = Number(mobile ? b.zoomMobile : b.zoom) / 100;
    return `object-position:${x}% ${y}%;transform:scale(${zoom || 1});transform-origin:${x}% ${y}%`;
  };
  const controle = (b, campo, rotulo, zoom = false) => `<label class="campo"><span>${rotulo}</span>
    <input data-campo="${campo}" type="range" min="${zoom ? 100 : 0}" max="${zoom ? 180 : 100}" value="${Number(b[campo] ?? (zoom ? 100 : 50))}">
    <output data-saida="${campo}">${Number(b[campo] ?? (zoom ? 100 : 50))}%</output></label>`;

  function renderizarBanners() {
    caixa.innerHTML = banners.map((b, i) => `
      <div class="item-lista banner-editor" data-banner="${i}">
        <h4>Banner ${i + 1}</h4>
        <div class="banner-editor__previas">
          <figure><figcaption>Desktop</figcaption><div class="banner-editor__quadro"><img src="${esc(b.imagem)}" alt="Prévia do banner no desktop" style="${estilo(b)}" data-previa-desktop decoding="async"></div></figure>
          <figure><figcaption>Celular</figcaption><div class="banner-editor__quadro banner-editor__quadro--mobile"><img src="${esc(b.imagem)}" alt="Prévia do banner no celular" style="${estilo(b, true)}" data-previa-mobile decoding="async"></div></figure>
        </div>
        <div class="form-grade form-grade--2">
          <label class="campo"><span>Descrição da imagem</span><input data-campo="alt" maxlength="120" value="${esc(b.alt)}"></label>
          <label class="campo"><span>Link ao clicar</span><input data-campo="link" maxlength="200" placeholder="/catalogo" value="${esc(b.link)}"></label>
          ${controle(b, 'focoX', 'Desktop · posição horizontal')}
          ${controle(b, 'focoY', 'Desktop · posição vertical')}
          ${controle(b, 'zoom', 'Desktop · zoom', true)}
          ${controle(b, 'focoMobileX', 'Celular · posição horizontal')}
          ${controle(b, 'focoMobileY', 'Celular · posição vertical')}
          ${controle(b, 'zoomMobile', 'Celular · zoom', true)}
        </div>
        <div class="item-lista__acoes"><button class="botao botao--sec botao--pequeno" type="button" data-restaurar-banner>Restaurar enquadramento</button><button class="botao botao--perigo botao--pequeno" type="button" data-remover-banner>Remover</button></div>
      </div>`).join('') || '<p>Sem banners: o topo da página inicial fica oculto.</p>';
  }

  caixa.addEventListener('input', (e) => {
    const campo = e.target.dataset.campo;
    if (campo) {
      const banner = banners[e.target.closest('[data-banner]').dataset.banner];
      banner[campo] = AJUSTES.includes(campo) ? Number(e.target.value) : e.target.value;
      if (AJUSTES.includes(campo)) {
        const item = e.target.closest('[data-banner]');
        item.querySelector('[data-previa-desktop]').setAttribute('style', estilo(banner));
        item.querySelector('[data-previa-mobile]').setAttribute('style', estilo(banner, true));
        item.querySelector(`[data-saida="${campo}"]`).textContent = `${banner[campo]}%`;
      }
    }
  });
  caixa.addEventListener('click', (e) => {
    if (e.target.closest('[data-restaurar-banner]')) {
      Object.assign(banners[e.target.closest('[data-banner]').dataset.banner], { focoX: 50, focoY: 50, zoom: 100, focoMobileX: 50, focoMobileY: 50, zoomMobile: 100 });
      return renderizarBanners();
    }
    if (!e.target.closest('[data-remover-banner]')) return;
    banners.splice(e.target.closest('[data-banner]').dataset.banner, 1);
    renderizarBanners();
  });
  form.querySelector('[data-enviar-banner]').addEventListener('change', async (e) => {
    const campo = e.target;
    if (!campo.files.length) return;
    campo.disabled = true;
    try {
      if (banners.length >= 8) throw new Error('Você pode cadastrar até 8 banners.');
      const imagem = await enviarBanner(campo.files[0]);
      banners.push({ ...imagem, alt: '', link: '/catalogo', focoX: 50, focoY: 50, zoom: 100, focoMobileX: 50, focoMobileY: 50, zoomMobile: 100 });
      renderizarBanners();
    } catch (erro) {
      aviso(erro.message, { erro: true });
    }
    campo.value = '';
    campo.disabled = false;
  });

  aoEnviar(form, async (dados) => {
    const redesSociais = Object.fromEntries(Object.keys(REDES).map((chave) => [chave, dados[chave]]));
    await api('/api/admin/config', {
      metodo: 'PUT',
      dados: { ...dados, parcelas: Number(dados.parcelas), redesSociais, banners },
    });
    aviso('Configurações salvas.');
  });

  renderizarBanners();
}
