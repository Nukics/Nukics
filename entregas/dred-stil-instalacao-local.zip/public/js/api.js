// Acesso à API do servidor.

export async function api(caminho, { metodo = 'GET', dados } = {}) {
  const resposta = await fetch(caminho, {
    method: metodo,
    credentials: 'same-origin',
    headers: dados === undefined ? {} : { 'Content-Type': 'application/json' },
    body: dados === undefined ? undefined : JSON.stringify(dados),
  });
  const json = await resposta.json().catch(() => ({}));
  if (!resposta.ok) {
    const erro = new Error(json.erro || 'Algo deu errado. Tente novamente.');
    erro.status = resposta.status;
    throw erro;
  }
  return json;
}
