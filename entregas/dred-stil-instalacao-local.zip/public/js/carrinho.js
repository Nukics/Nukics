// Carrinho salvo no navegador (localStorage) e gaveta lateral.
// Ao finalizar: checkout com Pix (se o pagamento online estiver ligado) ou pedido + WhatsApp.
import { api } from './api.js';
import { aviso } from './aviso.js';
import { carregarLoja, produtoPorHandle } from './estado.js';
import { abrirPainel, fecharPainel } from './gaveta.js';
import { brl, esc, urlProduto } from './util.js';
import { ehAtacado, precoAtacado, resumoAtacado } from './atacado.js';

const CHAVE = 'dredstil-carrinho';
let produtos = [];
let config = {};
let gaveta;
let finalizando = false;

function ler() {
  try {
    const itens = JSON.parse(localStorage.getItem(CHAVE));
    return Array.isArray(itens) ? itens : [];
  } catch {
    return [];
  }
}

function salvar(itens) {
  try {
    localStorage.setItem(CHAVE, JSON.stringify(itens));
  } catch {}
  atualizar();
}

// Itens com os dados atuais do produto; ignora produtos que saíram da loja.
function itensValidos() {
  return ler()
    .map((item) => ({ ...item, produto: produtoPorHandle(produtos, item.handle) }))
    .filter((item) => item.produto);
}

export function adicionarAoCarrinho(handle, cor, tamanho, qtd) {
  const itens = ler();
  const chave = `${handle}|${cor}|${tamanho}`;
  const existente = itens.find((i) => i.chave === chave);
  if (existente) existente.qtd = Math.min(99, existente.qtd + qtd);
  else itens.push({ chave, handle, cor, tamanho, qtd });
  salvar(itens);
}

function mudarQuantidade(chave, qtd) {
  const itens = ler();
  salvar(qtd <= 0 ? itens.filter((i) => i.chave !== chave) : itens.map((i) => (i.chave === chave ? { ...i, qtd: Math.min(qtd, 99) } : i)));
}

function totais(itens) {
  const atacado = resumoAtacado(itens);
  return itens.reduce((t, i) => ({ ...t, qtd: t.qtd + i.qtd, valor: t.valor + precoAtacado(i, atacado) * i.qtd }), { qtd: 0, valor: 0, atacado });
}

function htmlItem({ chave, produto, cor, tamanho, qtd }, itens) {
  const dadosCor = produto.cores.find((c) => c.nome === cor) || produto.cores[0];
  const url = urlProduto(produto.handle, dadosCor.nome);
  const atacado = resumoAtacado(itens);
  const preco = precoAtacado({ produto }, atacado);
  return `<div class="carrinho__item">
    <a class="carrinho__img" href="${url}"><img src="${esc(dadosCor.imagens[0])}" alt="${esc(produto.nome)}"></a>
    <div class="carrinho__info">
      <a class="carrinho__nome" href="${url}">${esc(produto.nome)}</a>
      <span class="carrinho__var">${esc(dadosCor.nome)} / ${esc(tamanho)}</span>
      <span>${produto.preco ? `${brl(preco)}${atacado.percentual && ehAtacado(produto) ? ` · ${atacado.percentual}% atacado` : ''}` : 'Preço sob consulta'}</span>
      <div class="carrinho__linha">
        <div class="qtd">
          <button type="button" aria-label="Diminuir quantidade" data-qtd="${qtd - 1}" data-chave="${esc(chave)}">−</button>
          <span>${qtd}</span>
          <button type="button" aria-label="Aumentar quantidade" data-qtd="${qtd + 1}" data-chave="${esc(chave)}">+</button>
        </div>
        <button type="button" class="carrinho__rem" data-qtd="0" data-chave="${esc(chave)}">Remover</button>
      </div>
    </div>
  </div>`;
}

function atualizar() {
  const itens = itensValidos();
  const t = totais(itens);
  document.querySelectorAll('[data-contador-carrinho]').forEach((el) => {
    el.textContent = t.qtd;
    el.hidden = t.qtd === 0;
  });
  if (!gaveta) return;

  gaveta.querySelector('[data-carrinho-itens]').innerHTML = itens.length
    ? itens.map((item) => htmlItem(item, itens)).join('')
    : '<div class="carrinho__vazio"><p>Seu carrinho está vazio.</p><button type="button" class="botao botao--sec" data-fechar-gaveta>Continuar comprando</button></div>';

  const rodape = gaveta.querySelector('[data-carrinho-rodape]');
  rodape.hidden = !itens.length;
  const temSobConsulta = itens.some((i) => !i.produto.preco);
  rodape.innerHTML = itens.length
    ? `${t.atacado.percentual ? `<p class="carrinho__obs">Atacado: ${t.atacado.quantidade} peças · ${t.atacado.percentual}% de desconto aplicado.</p>` : ''}
       <div class="carrinho__sub"><span>Subtotal</span><strong>${t.valor ? brl(t.valor) : 'A combinar'}</strong></div>
       <p class="carrinho__obs">${temSobConsulta && t.valor ? 'Itens sob consulta não entram no subtotal. ' : ''}${config.checkout ? (config.checkoutIntegrado ? 'Frete calculado na finalização. Pagamento seguro pela Getnet.' : 'Frete calculado na finalização. Pagamento por Pix.') : 'Frete e pagamento combinados na finalização.'}</p>
       <button type="button" class="botao botao--largo" data-finalizar>Finalizar a compra</button>
       <button type="button" class="botao botao--sec botao--largo" data-fechar-gaveta>Continuar comprando</button>`
    : '';
}

export function abrirCarrinho() {
  atualizar();
  abrirPainel(gaveta, { focar: '[data-fechar-gaveta].icone-btn' });
}

function mensagemDoPedido({ numero, itens, total }) {
  const linhas = itens.map((i) => `• ${i.qtd}x ${i.nome} (${i.cor} / ${i.tamanho}) — ${i.preco ? brl(i.preco * i.qtd) : 'sob consulta'}`);
  return `Olá! Acabei de fazer o pedido #${numero} na Dred Stil:\n\n${linhas.join('\n')}\n\nTotal: ${total ? brl(total) : 'a combinar'}`;
}

// Itens como estão salvos (para o checkout) e limpeza depois do pagamento.
export const itensDoCarrinho = () => ler();
export const limparCarrinho = () => salvar([]);

// Com pagamento online ligado, segue para o checkout (Pix). Senão, registra o pedido
// no site (preços conferidos no servidor) e segue para o WhatsApp.
export async function finalizarCompra() {
  const itens = itensValidos();
  if (!itens.length || finalizando) return; // evita pedido duplicado com clique duplo
  if (config.checkout) {
    location.href = '/checkout';
    return;
  }
  finalizando = true;
  // abre a aba já no clique, senão o navegador bloqueia a janela aberta depois da resposta
  const janela = window.open('about:blank', '_blank');
  if (janela) janela.opener = null;
  try {
    const { pedido } = await api('/api/pedidos', {
      metodo: 'POST',
      dados: { itens: itens.map(({ handle, cor, tamanho, qtd }) => ({ handle, cor, tamanho, qtd })) },
    });
    const whatsapp = `https://wa.me/${config.whatsapp || ''}?text=${encodeURIComponent(mensagemDoPedido(pedido))}`;
    if (janela) janela.location.href = whatsapp;
    else location.href = whatsapp;
    salvar([]);
    fecharPainel(gaveta);
    aviso(`Pedido #${pedido.numero} registrado! Combine pagamento e entrega pelo WhatsApp.`);
  } catch (erro) {
    janela?.close();
    aviso(erro.message, { erro: true });
  } finally {
    finalizando = false;
  }
}

export async function iniciarCarrinho() {
  gaveta = document.getElementById('carrinho');
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-abrir-carrinho]')) abrirCarrinho();
    const botaoQtd = e.target.closest('#carrinho [data-qtd]');
    if (botaoQtd) mudarQuantidade(botaoQtd.dataset.chave, Number(botaoQtd.dataset.qtd));
    if (e.target.closest('#carrinho [data-finalizar]')) finalizarCompra();
  });
  // mantém abas abertas do site sincronizadas
  window.addEventListener('storage', (e) => e.key === CHAVE && atualizar());

  const loja = await carregarLoja();
  produtos = loja.produtos;
  config = loja.config;
  atualizar();
}
