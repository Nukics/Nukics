// Ponto de entrada: comportamentos comuns a todas as páginas + módulo da página atual.
import { iniciarCarrinho } from './carrinho.js';
import { iniciarCartoes } from './cartao.js';
import { iniciarCurtidas } from './curtidas.js';
import { iniciarLayout } from './layout.js';

const PAGINAS = ['inicio', 'catalogo', 'atacado', 'produto', 'favoritos', 'conta', 'admin', 'checkout'];

iniciarLayout();
iniciarCarrinho();
iniciarCartoes();

// Curtidas dependem da sessão e não são necessárias para exibir a loja.
const quandoLivre = window.requestIdleCallback || ((fn) => setTimeout(fn, 180));
quandoLivre(iniciarCurtidas);

const pagina = document.body.dataset.pagina;
if (PAGINAS.includes(pagina)) import(`./paginas/${pagina}.js`).then((m) => m.iniciar());
