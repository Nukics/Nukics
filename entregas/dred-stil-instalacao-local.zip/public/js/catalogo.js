// Catálogo único: filtro por categoria (e subcategoria), busca, ordenação e "ver mais".
// Usado na página inicial e na página /catalogo (completo = com busca e filtros na URL).
import { cartaoProduto } from './cartao.js';
import {
  buscarProdutos,
  carregarLoja,
  categoriaPorSlug,
  categoriasPrincipais,
  comSubcategorias,
  subcategorias,
} from './estado.js';
import { esc } from './util.js';

const POR_PAGINA = 12;
const ORDENS = {
  recentes: ['Mais recentes', (a, b) => String(b.criadoEm).localeCompare(String(a.criadoEm))],
  curtidos: ['Mais curtidos', (a, b) => b.curtidas - a.curtidas],
  'menor-preco': ['Menor preço', (a, b) => a.preco - b.preco],
  'maior-preco': ['Maior preço', (a, b) => b.preco - a.preco],
};

const chip = (slug, rotulo) => `<button type="button" data-categoria="${esc(slug)}" aria-pressed="false">${esc(rotulo)}</button>`;

export async function montarCatalogo(raiz, { completo = false } = {}) {
  const { produtos, categorias, config } = await carregarLoja();
  const params = new URLSearchParams(completo ? location.search : '');
  const fixa = raiz.dataset.categoriaFixa || '';
  const grupoFixo = fixa ? comSubcategorias(categorias, fixa) : null;
  const solicitada = params.get('categoria');
  const estado = {
    categoria: categoriaPorSlug(categorias, solicitada) && (!grupoFixo || grupoFixo.includes(solicitada)) ? solicitada : fixa,
    termo: params.get('q') || '',
    ordem: ORDENS[params.get('ordem')] ? params.get('ordem') : 'recentes',
    limite: POR_PAGINA,
  };

  const inicial = JSON.stringify({ categoria: estado.categoria, termo: estado.termo, ordem: estado.ordem });
  const preservarHtml = raiz.querySelector('[data-estado-catalogo]')?.dataset.estadoCatalogo === inicial;
  if (!preservarHtml) raiz.innerHTML = `
    ${completo ? `<form class="catalogo__busca" role="search" data-busca>
      <input type="search" name="q" placeholder="Buscar no catálogo" aria-label="Buscar no catálogo" maxlength="80" value="${esc(estado.termo)}">
      <button class="botao" type="submit">Buscar</button>
    </form>` : ''}
    <div class="catalogo__barra">
      <div class="catalogo__filtros">
        <div class="chips" role="group" aria-label="Filtrar por categoria">
          ${fixa ? chip(fixa, 'Todos do atacado') : chip('', 'Todos') + categoriasPrincipais(categorias).map((c) => chip(c.slug, c.nome)).join('')}
        </div>
        <div class="chips chips--sub" role="group" aria-label="Filtrar por subcategoria" data-subcategorias hidden></div>
      </div>
      <div class="catalogo__ferramentas">
        <p class="catalogo__total" aria-live="polite" data-total></p>
        <select class="catalogo__ordem" aria-label="Ordenar produtos" data-ordem>
          ${Object.entries(ORDENS).map(([valor, [rotulo]]) => `<option value="${valor}"${valor === estado.ordem ? ' selected' : ''}>${rotulo}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="atacado__aviso" data-aviso-atacado hidden><strong>Descontos na categoria Atacado</strong><p>Combine peças e tenha até 30% de desconto por quantidade.</p><a href="/atacado">Ver tabela de preços de atacado</a></div>
    <div class="grade" data-grade></div>
    <p class="vazio" data-vazio hidden>Nenhum produto encontrado.</p>
    <div class="catalogo__mais"><button class="botao botao--sec" type="button" data-mais hidden>Ver mais</button></div>`;

  const $ = (seletor) => raiz.querySelector(seletor);

  function atualizarUrl() {
    const url = new URLSearchParams();
    if (estado.termo) url.set('q', estado.termo);
    if (estado.categoria) url.set('categoria', estado.categoria);
    if (estado.ordem !== 'recentes') url.set('ordem', estado.ordem);
    history.replaceState(null, '', url.size ? `?${url}` : location.pathname);
  }

  // Subcategorias aparecem quando a categoria principal (ou uma sub dela) está escolhida.
  function renderizarSubcategorias() {
    const atual = categoriaPorSlug(categorias, estado.categoria);
    const principal = atual?.pai || atual?.slug;
    const subs = principal ? subcategorias(categorias, principal) : [];
    const caixa = $('[data-subcategorias]');
    caixa.hidden = !subs.length;
    caixa.innerHTML = subs.length ? chip(principal, 'Todas') + subs.map((c) => chip(c.slug, c.nome)).join('') : '';
    raiz.querySelectorAll('.chips:not(.chips--sub) [data-categoria]').forEach((b) =>
      b.setAttribute('aria-pressed', b.dataset.categoria === (principal || '')));
    caixa.querySelectorAll('[data-categoria]').forEach((b) => b.setAttribute('aria-pressed', b.dataset.categoria === estado.categoria));
  }

  function renderizar(preservar = false) {
    let lista = buscarProdutos(produtos, estado.termo, categorias);
    if (grupoFixo) lista = lista.filter((p) => grupoFixo.includes(p.categoria));
    if (estado.categoria) {
      const aceitas = comSubcategorias(categorias, estado.categoria);
      lista = lista.filter((p) => aceitas.includes(p.categoria));
    }
    lista = [...lista].sort(ORDENS[estado.ordem][1]);

    if (!preservar) $('[data-grade]').innerHTML = lista
      .slice(0, estado.limite)
      .map((p) => cartaoProduto(p, { parcelas: config.parcelas }))
      .join('');
    const termo = estado.termo ? ` para “${estado.termo}”` : '';
    $('[data-total]').textContent = `${lista.length} ${lista.length === 1 ? 'produto' : 'produtos'}${termo}`;
    $('[data-vazio]').hidden = lista.length > 0;
    $('[data-mais]').hidden = lista.length <= estado.limite;
    $('[data-aviso-atacado]').hidden = Boolean(fixa) || !(estado.categoria === 'atacado' || categoriaPorSlug(categorias, estado.categoria)?.pai === 'atacado');
    renderizarSubcategorias();
    if (completo) atualizarUrl();
  }

  raiz.addEventListener('click', (e) => {
    const botao = e.target.closest('[data-categoria]');
    if (botao) Object.assign(estado, { categoria: botao.dataset.categoria, limite: POR_PAGINA });
    else if (e.target.closest('[data-mais]')) estado.limite += POR_PAGINA;
    else return;
    renderizar();
  });
  $('[data-ordem]').addEventListener('change', (e) => {
    estado.ordem = e.target.value;
    renderizar();
  });
  $('[data-busca]')?.addEventListener('submit', (e) => {
    e.preventDefault();
    Object.assign(estado, { termo: e.target.q.value.trim(), limite: POR_PAGINA });
    renderizar();
  });

  renderizar(preservarHtml);
}
