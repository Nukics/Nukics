// Envio de formulários com estado de carregando e mensagem de erro.
// O formulário precisa de um botão type="submit" e de um elemento [data-erro].

export function aoEnviar(form, acao) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const botao = form.querySelector('[type="submit"]');
    const erro = form.querySelector('[data-erro]');
    erro.hidden = true;
    botao.disabled = true;
    try {
      await acao(Object.fromEntries(new FormData(form)));
    } catch (falha) {
      erro.textContent = falha.message;
      erro.hidden = false;
    } finally {
      botao.disabled = false;
    }
  });
}
