// Abre/fecha painéis sobrepostos (menu, carrinho, busca) cuidando do foco e da rolagem.
const abertas = [];

export function abrirPainel(painel, { focar } = {}) {
  if (!painel.hidden) return;
  const gatilho = document.activeElement;
  abertas.push({ painel, gatilho });
  if (gatilho?.hasAttribute?.('aria-expanded')) gatilho.setAttribute('aria-expanded', 'true');
  painel.hidden = false;
  document.documentElement.style.overflow = 'hidden';
  painel.querySelector(focar || 'button, a, input')?.focus();
}

export function fecharPainel(painel) {
  const i = abertas.findIndex((a) => a.painel === painel);
  if (i < 0) return;
  const [{ gatilho }] = abertas.splice(i, 1);
  painel.hidden = true;
  if (!abertas.length) document.documentElement.style.overflow = '';
  if (gatilho?.hasAttribute?.('aria-expanded')) gatilho.setAttribute('aria-expanded', 'false');
  gatilho?.focus?.();
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && abertas.length) fecharPainel(abertas[abertas.length - 1].painel);
});
