// Funções pequenas usadas em todo o site.

export function brl(valor) {
  return Number(valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function esc(valor) {
  return String(valor ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

// Para buscas: ignora acentos e maiúsculas.
export function normalizar(texto) {
  return String(texto).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
}

export function urlProduto(handle, cor) {
  return `/produto/${encodeURIComponent(handle)}${cor ? `?cor=${encodeURIComponent(cor)}` : ''}`;
}

// Só aceita destinos internos (evita redirecionar para outro site).
export function destinoSeguro(destino, padrao = '/') {
  return typeof destino === 'string' && /^\/(?!\/)/.test(destino) ? destino : padrao;
}

// Situações dos pedidos, na ordem do atendimento.
export const SITUACOES_PEDIDO = {
  aguardando: 'Aguardando pagamento',
  pago: 'Pago',
  enviado: 'Enviado',
  entregue: 'Entregue',
  cancelado: 'Cancelado',
  expirado: 'Pix expirado',
  revisar: 'Em análise',
};

export function dataCurta(iso) {
  return new Date(iso).toLocaleDateString('pt-BR');
}

export function seloBomCliente() {
  return '<span class="selo-bom-cliente" title="Cliente com 5 compras ou mais">★ Bom cliente</span>';
}

export function iconeCoracao() {
  return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/></svg>';
}
