import { montarCatalogo } from '../catalogo.js';

export function iniciar() {
  montarCatalogo(document.querySelector('[data-catalogo]'), { completo: true });
}
