import { montarCatalogo } from '../catalogo.js';
import { percentualAtacado, precoAtacado } from '../atacado.js';
import { brl } from '../util.js';

export function iniciar() {
  montarCatalogo(document.querySelector('[data-catalogo]'), { completo: true });
  const form = document.querySelector('[data-simulador-atacado]');
  const resultado = document.querySelector('[data-resultado-atacado]');
  const calcular = () => {
    if (!form.checkValidity()) { resultado.textContent = 'Informe uma quantidade inteira e um preço maior que zero.'; return; }
    const quantidade = Number(form.elements.quantidade.value);
    const preco = Number(form.elements.preco.value);
    const percentual = percentualAtacado(quantidade);
    const unidade = precoAtacado({ produto: { preco, categoria: 'atacado' } }, { percentual });
    const total = Math.round(unidade * quantidade * 100) / 100;
    const economia = Math.round((preco * quantidade - total) * 100) / 100;
    resultado.replaceChildren();
    const faixa = document.createElement('p');
    const valor = document.createElement('strong');
    const soma = document.createElement('p');
    faixa.textContent = `${quantidade} ${quantidade === 1 ? 'peça' : 'peças'} · ${percentual}% de desconto`;
    valor.textContent = `${brl(unidade)} por peça`;
    soma.textContent = `Total: ${brl(total)} · economia de ${brl(economia)}`;
    resultado.append(faixa, valor, soma);
  };
  form.addEventListener('input', calcular);
  form.addEventListener('submit', (e) => e.preventDefault());
  calcular();
}
