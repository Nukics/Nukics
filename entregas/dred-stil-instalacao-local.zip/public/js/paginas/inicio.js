// Página inicial: banners, destaques por categoria, catálogo e perguntas frequentes.
import { cartaoProduto } from '../cartao.js';
import { montarCatalogo } from '../catalogo.js';
import { carregarLoja, produtoPorHandle } from '../estado.js';
import { esc } from '../util.js';

const INTERVALO_BANNER = 6000;

function iniciarBanners() {
  const raiz = document.querySelector('[data-banners]');
  const slides = [...raiz.querySelectorAll('.banners__slide')];
  if (!slides.length) raiz.hidden = true;
  if (slides.length < 2) return;

  let atual = 0;
  let timer;
  let pausado = false;
  const movimentoReduzido = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const pontos = document.createElement('div');
  pontos.className = 'banners__pontos';
  pontos.innerHTML = slides.map((_, i) => `<button type="button" aria-label="Banner ${i + 1}" data-banner="${i}"></button>`).join('');
  raiz.append(pontos);

  function mostrar(i) {
    atual = (i + slides.length) % slides.length;
    slides.forEach((s, j) => s.classList.toggle('is-ativo', j === atual));
    if (timer) raiz.classList.add('is-rodando'); // animação só na troca (não atrasa o primeiro banner)
    pontos.querySelectorAll('button').forEach((b, j) => b.setAttribute('aria-current', j === atual));
    clearTimeout(timer);
    if (!pausado && !document.hidden && !movimentoReduzido) timer = setTimeout(() => mostrar(atual + 1), INTERVALO_BANNER);
  }
  const pausar = () => { pausado = true; clearTimeout(timer); };
  const retomar = () => { pausado = false; mostrar(atual); };
  raiz.addEventListener('pointerenter', pausar);
  raiz.addEventListener('pointerleave', retomar);
  raiz.addEventListener('focusin', pausar);
  raiz.addEventListener('focusout', (e) => { if (!raiz.contains(e.relatedTarget)) retomar(); });
  document.addEventListener('visibilitychange', () => document.hidden ? clearTimeout(timer) : mostrar(atual));
  pontos.addEventListener('click', (e) => {
    const botao = e.target.closest('[data-banner]');
    if (botao) mostrar(Number(botao.dataset.banner));
  });
  mostrar(0);
}

// Abas e produtos escolhidos no admin (Admin > Destaques), na ordem definida lá.
async function iniciarDestaques() {
  const { produtos, destaques, config } = await carregarLoja();
  const abasComProdutos = destaques
    .map((aba) => ({ nome: aba.nome, produtos: aba.produtos.map((h) => produtoPorHandle(produtos, h)).filter(Boolean) }))
    .filter((aba) => aba.produtos.length);
  const abas = document.querySelector('[data-abas-destaques]');
  const grade = document.querySelector('[data-grade-destaques]');
  const controles = document.querySelector('[data-controles-destaques]');
  if (!abasComProdutos.length) {
    abas.closest('section').hidden = true;
    return;
  }

  if (!abas.querySelector('[data-aba]')) abas.innerHTML = abasComProdutos
    .map((aba, i) => `<button type="button" role="tab" id="aba-destaque-${i}" aria-controls="grade-destaques" aria-selected="false" data-aba="${i}">${esc(aba.nome)}</button>`)
    .join('');
  grade.id = 'grade-destaques';
  grade.setAttribute('role', 'tabpanel');
  const anterior = controles.querySelector('[data-destaques-anterior]');
  const proximo = controles.querySelector('[data-destaques-proximo]');
  const movimentoReduzido = matchMedia('(prefers-reduced-motion: reduce)');

  function atualizarControles() {
    const limite = Math.max(0, grade.scrollWidth - grade.clientWidth);
    controles.hidden = limite <= 1;
    anterior.setAttribute('aria-disabled', grade.scrollLeft <= 1);
    proximo.setAttribute('aria-disabled', grade.scrollLeft >= limite - 1);
  }

  function rolar(direcao) {
    grade.scrollBy({ left: direcao * grade.clientWidth, behavior: movimentoReduzido.matches ? 'instant' : 'smooth' });
  }

  anterior.addEventListener('click', () => {
    if (anterior.getAttribute('aria-disabled') !== 'true') rolar(-1);
  });
  proximo.addEventListener('click', () => {
    if (proximo.getAttribute('aria-disabled') !== 'true') rolar(1);
  });
  grade.addEventListener('scroll', atualizarControles, { passive: true });
  new ResizeObserver(atualizarControles).observe(grade);
  grade.addEventListener('keydown', (e) => {
    if (e.target !== grade) return;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      e.preventDefault();
      rolar(e.key === 'ArrowLeft' ? -1 : 1);
    }
  });

  function mostrar(indice, preservar = false) {
    abas.querySelectorAll('[data-aba]').forEach((b) => {
      const ativa = Number(b.dataset.aba) === indice;
      b.setAttribute('aria-selected', ativa);
      b.tabIndex = ativa ? 0 : -1;
      if (ativa) grade.setAttribute('aria-labelledby', b.id);
    });
    if (!preservar) {
      grade.innerHTML = abasComProdutos[indice].produtos
        .map((p) => cartaoProduto(p, { parcelas: config.parcelas }))
        .join('');
      grade.scrollTo({ left: 0, behavior: 'instant' });
    }
    atualizarControles();
  }
  abas.addEventListener('click', (e) => {
    const aba = e.target.closest('[data-aba]');
    if (aba) mostrar(Number(aba.dataset.aba));
  });
  abas.addEventListener('keydown', (e) => {
    const aba = e.target.closest('[data-aba]');
    if (!aba || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault();
    const total = abasComProdutos.length;
    const atual = Number(aba.dataset.aba);
    const indice = e.key === 'Home' ? 0 : e.key === 'End' ? total - 1 : (atual + (e.key === 'ArrowRight' ? 1 : -1) + total) % total;
    mostrar(indice);
    abas.querySelector(`[data-aba="${indice}"]`).focus();
  });
  mostrar(0, Boolean(grade.children.length));
}

export function iniciar() {
  iniciarBanners();
  iniciarDestaques();
  montarCatalogo(document.querySelector('[data-catalogo]'));
  const faq = document.getElementById('perguntas');
  faq.hidden = !faq.querySelector('.faq__item');
}
