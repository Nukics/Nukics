// Página de produto: galeria por cor, tamanho, quantidade, carrinho e curtir.
import { abrirCarrinho, adicionarAoCarrinho, finalizarCompra } from '../carrinho.js';
import { desconto, htmlPreco } from '../cartao.js';
import { botaoCurtir } from '../curtidas.js';
import { carregarLoja, categoriaPorSlug, produtoPorHandle } from '../estado.js';
import { esc, urlProduto } from '../util.js';

// "Categoria / Subcategoria / " com links para o catálogo filtrado.
function trilhaCategoria(categorias, slug) {
  const categoria = categoriaPorSlug(categorias, slug);
  if (!categoria) return '';
  const pai = categoria.pai && categoriaPorSlug(categorias, categoria.pai);
  const link = (c) => `<a href="/catalogo?categoria=${encodeURIComponent(c.slug)}">${esc(c.nome)}</a> / `;
  return (pai ? link(pai) : '') + link(categoria);
}

export async function iniciar() {
  const raiz = document.getElementById('produto');
  const { produtos, categorias, config } = await carregarLoja();
  const produto = produtoPorHandle(produtos, raiz.dataset.handle);
  if (!produto) return;

  const corDaUrl = new URLSearchParams(location.search).get('cor');
  const estado = {
    cor: produto.cores.find((c) => c.nome === corDaUrl) || produto.cores[0],
    tamanho: produto.tamanhos.length === 1 ? produto.tamanhos[0] : null,
    qtd: 1,
    foto: 0,
  };
  const off = desconto(produto);
  const corEsgotada = (cor) => Boolean(cor.esgotado ?? produto.esgotado);

  if (!raiz.querySelector('[data-foto-principal]')) raiz.innerHTML = `
    <div class="produto">
      <nav class="trilha" aria-label="Você está em">
        <a href="/">Início</a> / ${trilhaCategoria(categorias, produto.categoria)}<span aria-current="page">${esc(produto.nome)}</span>
      </nav>
      <div class="produto__grade">
        <div>
          <div class="produto__principal"><img alt="" fetchpriority="high" data-foto-principal>${botaoCurtir(produto)}</div>
          <div class="produto__miniaturas" data-miniaturas></div>
        </div>
        <div class="produto__info">
          <h1 class="produto__nome">${esc(produto.nome)}</h1>
          ${produto.atacado || produto.categoria === 'atacado' ? '<div class="atacado__aviso"><strong>Esta peça participa do preço de atacado.</strong><p>O desconto considera todas as peças de Atacado do carrinho.</p><a href="/atacado">Consultar descontos por quantidade</a></div>' : ''}
          <div class="preco-linha">${htmlPreco(produto, config.parcelas)}${off ? `<span class="produto__desconto">-${off}%</span>` : ''}</div>
          <div>
            <p class="opcao__rotulo">Cor: <strong data-nome-cor></strong></p>
            <div class="opcao__lista" data-cores></div>
          </div>
          <div>
            <p class="opcao__rotulo">Tamanho: <strong data-nome-tamanho></strong></p>
            <div class="opcao__lista" data-tamanhos></div>
            <p class="erro-form" role="alert" data-erro-tamanho hidden>Selecione um tamanho.</p>
          </div>
          <div class="produto__comprar">
            <div class="qtd qtd--grande">
              <button type="button" aria-label="Diminuir quantidade" data-mudar-qtd="-1">−</button>
              <span data-qtd>1</span>
              <button type="button" aria-label="Aumentar quantidade" data-mudar-qtd="1">+</button>
            </div>
            <button type="button" class="botao" data-adicionar${corEsgotada(estado.cor) ? ' disabled' : ''}>${corEsgotada(estado.cor) ? 'Cor esgotada' : 'Adicionar ao carrinho'}</button>
          </div>
          <p class="produto__esgotado" data-disponibilidade aria-live="polite"${corEsgotada(estado.cor) ? '' : ' hidden'}>Esta cor está esgotada no momento. Fale com a loja pelo WhatsApp para saber quando volta.</p>
          <button type="button" class="botao botao--sec botao--largo" data-comprar${corEsgotada(estado.cor) ? ' disabled' : ''}>Comprar agora</button>
          <ul class="selos"><li>Compra segura</li><li>Troca garantida</li>${config.parcelas > 1 ? `<li>Parcele em até ${config.parcelas}x sem juros</li>` : ''}</ul>
          ${produto.descricao ? `<details class="produto__desc" open><summary>Descrição</summary><p>${esc(produto.descricao)}</p></details>` : ''}
        </div>
      </div>
    </div>`;

  const $ = (seletor) => raiz.querySelector(seletor);
  const marcar = (seletor, atributo, ativo) => raiz.querySelectorAll(seletor).forEach((b) => b.setAttribute(atributo, ativo(b)));

  if (!$('[data-cores]').children.length) $('[data-cores]').innerHTML = produto.cores
    .map((c) => `<button type="button" class="cor" style="--c:${esc(c.hex)}" aria-label="${esc(c.nome)}${corEsgotada(c) ? ' — esgotado' : ''}" title="${esc(c.nome)}${corEsgotada(c) ? ' — esgotado' : ''}" data-cor="${esc(c.nome)}" data-esgotado="${corEsgotada(c)}"></button>`)
    .join('');
  if (!$('[data-tamanhos]').children.length) $('[data-tamanhos]').innerHTML = produto.tamanhos
    .map((t) => `<button type="button" class="tamanho" data-tamanho="${esc(t)}">${esc(t)}</button>`)
    .join('');

  let corDasMiniaturas = $('[data-miniaturas]').children.length === estado.cor.imagens.length ? estado.cor : null;
  function renderizar() {
    const fotos = estado.cor.imagens;
    if (corDasMiniaturas !== estado.cor) {
      corDasMiniaturas = estado.cor;
      $('[data-miniaturas]').innerHTML = fotos
        .map((src, i) => `<button type="button" aria-label="Ver foto ${i + 1}" data-foto="${i}"><img src="${esc(src)}" alt=""></button>`)
        .join('');
    }
    const principal = $('[data-foto-principal]');
    if (principal.getAttribute('src') !== fotos[estado.foto]) principal.src = fotos[estado.foto];
    principal.alt = `${produto.nome} — ${estado.cor.nome}`;
    marcar('[data-foto]', 'aria-current', (b) => Number(b.dataset.foto) === estado.foto);
    marcar('[data-cor]', 'aria-pressed', (b) => b.dataset.cor === estado.cor.nome);
    marcar('[data-tamanho]', 'aria-pressed', (b) => b.dataset.tamanho === estado.tamanho);
    $('[data-nome-cor]').textContent = estado.cor.nome;
    $('[data-nome-tamanho]').textContent = estado.tamanho || 'selecione';
    $('[data-qtd]').textContent = estado.qtd;
    const esgotada = corEsgotada(estado.cor);
    $('[data-adicionar]').disabled = esgotada;
    $('[data-adicionar]').textContent = esgotada ? 'Cor esgotada' : 'Adicionar ao carrinho';
    $('[data-comprar]').disabled = esgotada;
    $('[data-disponibilidade]').hidden = !esgotada;
    history.replaceState(null, '', urlProduto(produto.handle, estado.cor.nome));
  }

  function adicionar() {
    if (corEsgotada(estado.cor)) return false;
    if (!estado.tamanho) {
      $('[data-erro-tamanho]').hidden = false;
      $('[data-tamanhos] button')?.focus();
      return false;
    }
    adicionarAoCarrinho(produto.handle, estado.cor.nome, estado.tamanho, estado.qtd);
    return true;
  }

  raiz.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.foto) estado.foto = Number(b.dataset.foto);
    else if (b.dataset.cor) Object.assign(estado, { cor: produto.cores.find((c) => c.nome === b.dataset.cor), foto: 0 });
    else if (b.dataset.tamanho) {
      estado.tamanho = b.dataset.tamanho;
      $('[data-erro-tamanho]').hidden = true;
    } else if (b.dataset.mudarQtd) estado.qtd = Math.max(1, Math.min(99, estado.qtd + Number(b.dataset.mudarQtd)));
    else if ('adicionar' in b.dataset) return adicionar() && abrirCarrinho();
    else if ('comprar' in b.dataset) return adicionar() && finalizarCompra();
    else return;
    renderizar();
  });

  renderizar();
}
