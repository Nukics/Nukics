// Produtos curtidos pelo cliente.
import { cartaoProduto } from '../cartao.js';
import { carregarLoja, carregarUsuario } from '../estado.js';

export async function iniciar() {
  const raiz = document.querySelector('[data-favoritos]');
  const [{ produtos, config }, usuario] = await Promise.all([carregarLoja(), carregarUsuario()]);

  if (!usuario) {
    raiz.innerHTML = `<div class="vazio"><p>Entre na sua conta para ver os produtos que você curtiu.</p>
      <a class="botao" href="/conta?voltar=/favoritos">Entrar ou criar conta</a></div>`;
    return;
  }

  function renderizar() {
    const curtidos = produtos.filter((p) => usuario.curtidas.includes(p.handle));
    raiz.innerHTML = curtidos.length
      ? `<div class="grade">${curtidos.map((p) => cartaoProduto(p, { parcelas: config.parcelas, curtidas: usuario.curtidas })).join('')}</div>`
      : `<div class="vazio"><p>Você ainda não curtiu nenhum produto. Toque no coração dos produtos para guardá-los aqui.</p>
         <a class="botao" href="/catalogo">Ver o catálogo</a></div>`;
  }

  // ao descurtir aqui, o produto sai da lista
  document.addEventListener('curtidas:mudou', renderizar);
  renderizar();
}
