// Checkout: dados, entrega (frete do Melhor Envio) e pagamento por Pix (Getnet).
// Os valores mostrados aqui são só prévia: o servidor recalcula preço e frete ao criar o pedido.
import { api } from '../api.js';
import { itensDoCarrinho, limparCarrinho } from '../carrinho.js';
import { carregarLoja, carregarUsuario, produtoPorHandle } from '../estado.js';
import { brl, esc } from '../util.js';
import { ehAtacado, precoAtacado, resumoAtacado } from '../atacado.js';
import { abrirCheckout } from '../getnet-checkout.js';

const CHAVE_TENTATIVA = 'dredstil-checkout';
const ULTIMO_PEDIDO = 'dredstil-checkout-pedido';
let consulta;

// Mesma chave enquanto o carrinho não mudar: clique duplo ou recarregar não criam outro pedido.
function chaveIdempotencia(itens) {
  const assinatura = JSON.stringify(itens);
  try {
    const salvo = JSON.parse(sessionStorage.getItem(CHAVE_TENTATIVA) || 'null');
    if (salvo?.assinatura === assinatura) return salvo.chave;
    const chave = crypto.randomUUID();
    sessionStorage.setItem(CHAVE_TENTATIVA, JSON.stringify({ assinatura, chave }));
    return chave;
  } catch {
    return crypto.randomUUID();
  }
}

const itensApi = () => itensDoCarrinho().map(({ handle, cor, tamanho, qtd }) => ({ handle, cor, tamanho, qtd }));

function mensagem(raiz, titulo, html) {
  raiz.innerHTML = `<h1 class="secao__titulo">${esc(titulo)}</h1><div class="caixa form-grade">${html}</div>`;
}

function telaCheckout(raiz, usuario, loja) {
  const itens = itensDoCarrinho()
    .map((i) => ({ ...i, produto: produtoPorHandle(loja.produtos, i.handle) }))
    .filter((i) => i.produto);
  const atacado = resumoAtacado(itens);
  const subtotal = itens.reduce((t, i) => t + precoAtacado(i, atacado) * i.qtd, 0);
  const resumo = itens.map((i) => {
    const cor = i.produto.cores.find((c) => c.nome === i.cor) || i.produto.cores[0];
    return `<div class="resumo__item"><img src="${esc(cor.imagens[0])}" alt=""><div><strong>${esc(i.produto.nome)}</strong>
      <small>${esc(i.cor)} / ${esc(i.tamanho)} · ${i.qtd}x${atacado.percentual && ehAtacado(i.produto) ? ` · ${atacado.percentual}% atacado` : ''}</small></div><span>${brl(precoAtacado(i, atacado) * i.qtd)}</span></div>`;
  }).join('');

  raiz.innerHTML = `
    <h1 class="secao__titulo">Finalizar compra</h1>
    <div class="checkout__grade">
      <form class="form-grade" data-form="checkout" novalidate>
        <div class="caixa form-grade">
          <h2>1. Seus dados</h2>
          <label class="campo"><span>Nome completo</span><input name="nome" autocomplete="name" required minlength="3" maxlength="100" value="${esc(usuario.nome)}"></label>
          <div class="checkout__linha checkout__linha--2">
            <label class="campo"><span>CPF</span><input name="cpf" inputmode="numeric" autocomplete="off" required maxlength="14" placeholder="000.000.000-00"></label>
            <label class="campo"><span>Celular</span><input type="tel" name="telefone" autocomplete="tel" required maxlength="15" value="${esc(usuario.telefone || '')}" placeholder="(41) 99999-9999"></label>
          </div>
          <small>O CPF é exigido para a nota fiscal e o envio.</small>
        </div>
        <div class="caixa form-grade">
          <h2>2. Como você prefere receber?</h2>
          <div class="opcoes" data-tipos-entrega>
            <label class="opcao"><input type="radio" name="tipo-entrega" value="melhor-envio" checked>
              <span><strong>Entrega por transportadora ou Correios</strong><br><small>Veja as opções e prazos pelo Melhor Envio.</small></span></label>
            <label class="opcao"><input type="radio" name="tipo-entrega" value="retirada-loja">
              <span><strong>Retirar na loja</strong><br><small>Grátis · Av. Maria Antonieta, 354 · Pinhais/PR.</small></span></label>
            <label class="opcao"><input type="radio" name="tipo-entrega" value="whatsapp">
              <span><strong>Combinar entrega pelo WhatsApp</strong><br><small>Fale com a loja para acertar a melhor entrega.</small></span></label>
          </div>
          <div data-entrega-melhor-envio>
            <p data-endereco-cobranca hidden>Para o pagamento, informe seu endereço de cobrança.</p>
            <div class="checkout__linha checkout__linha--2">
              <label class="campo"><span>CEP</span><input name="cep" inputmode="numeric" autocomplete="postal-code" required maxlength="9" placeholder="00000-000"></label>
              <button class="botao botao--sec" type="button" data-calcular>Calcular frete</button>
            </div>
            <div class="checkout__linha checkout__linha--3">
              <label class="campo"><span>Rua</span><input name="rua" autocomplete="address-line1" required maxlength="120"></label>
              <label class="campo"><span>Número</span><input name="numero" required maxlength="20"></label>
              <label class="campo"><span>Complemento</span><input name="complemento" autocomplete="address-line2" maxlength="80"></label>
            </div>
            <div class="checkout__linha checkout__linha--3">
              <label class="campo"><span>Bairro</span><input name="bairro" required maxlength="80"></label>
              <label class="campo"><span>Cidade</span><input name="cidade" autocomplete="address-level2" required maxlength="80"></label>
              <label class="campo"><span>ESTADO</span><input name="uf" autocomplete="address-level1" required maxlength="2" placeholder="PR"></label>
            </div>
            <div class="opcoes" data-opcoes><small>Informe o CEP e clique em "Calcular frete".</small></div>
          </div>
          <p data-entrega-retirada hidden><strong>Retirada grátis.</strong> Depois do pagamento aprovado, a loja confirma pelo WhatsApp quando o pedido estiver pronto para buscar.</p>
          <p data-entrega-whatsapp hidden><strong>Entrega a combinar.</strong> Ao continuar, você será levado ao WhatsApp com seu pedido para acertar entrega e pagamento.</p>
        </div>
        <div class="caixa form-grade">
          <h2>3. Pagamento</h2>
          ${loja.config.checkoutIntegrado ? `<div class="checkout__seguro"><strong>Cartão de crédito ou Pix</strong>
            <p>Escolha no formulário seguro da Getnet, aqui no site. As parcelas disponíveis aparecem antes da confirmação.</p>
            <small>Os dados do cartão são preenchidos diretamente na Getnet.</small></div>` : `<div class="opcoes">
            <label class="opcao"><input type="radio" name="pagamento" value="pix" checked><span><strong>Pix</strong><br><small>Aprovação na hora. O código vale 30 minutos.</small></span></label>
            <label class="opcao" aria-disabled="true"><input type="radio" disabled><span><strong>Cartão de crédito</strong><br><small>Em breve</small></span></label>
          </div>`}
        </div>
        <p class="erro-form" role="alert" data-erro hidden></p>
        <button class="botao botao--largo" type="submit" data-finalizar>Finalizar pedido</button>
      </form>
      <aside class="caixa">
        <h2>Resumo</h2>
        ${resumo}
        ${atacado.percentual ? `<div class="resumo__total"><span>Desconto de atacado (${atacado.quantidade} peças)</span><span>${atacado.percentual}%</span></div>` : ''}
        <div class="resumo__total"><span>Subtotal</span><span>${brl(subtotal)}</span></div>
        <div class="resumo__total"><span>Frete</span><span data-frete>—</span></div>
        <div class="resumo__total resumo__total--g"><span>Total</span><span data-total>${brl(subtotal)}</span></div>
        <small>O valor final é confirmado pela loja ao criar o pedido.</small>
      </aside>
    </div>`;

  const form = raiz.querySelector('[data-form="checkout"]');
  const erro = form.querySelector('[data-erro]');
  const painelMelhorEnvio = form.querySelector('[data-entrega-melhor-envio]');
  const avisoRetirada = form.querySelector('[data-entrega-retirada]');
  const avisoWhatsApp = form.querySelector('[data-entrega-whatsapp]');
  const botaoFinalizar = form.querySelector('[data-finalizar]');
  let opcoes = [];
  const mostrarErro = (texto) => {
    erro.textContent = texto || '';
    erro.hidden = !texto;
  };
  const atualizarTotal = () => {
    const escolhida = tipoEntrega() === 'retirada-loja' ? opcoes[0] : opcoes.find((o) => o.id === form.querySelector('input[name="frete"]:checked')?.value);
    raiz.querySelector('[data-frete]').textContent = escolhida ? (escolhida.preco ? brl(escolhida.preco) : 'Grátis') : 'A combinar';
    raiz.querySelector('[data-total]').textContent = brl(subtotal + (escolhida?.preco || 0));
  };

  const tipoEntrega = () => form.querySelector('input[name="tipo-entrega"]:checked')?.value;
  const habilitarCamposEndereco = (ativo) => {
    painelMelhorEnvio.hidden = !ativo;
    painelMelhorEnvio.querySelectorAll('input').forEach((campo) => { campo.disabled = !ativo; });
    const faturamento = loja.config.checkoutIntegrado && tipoEntrega() === 'retirada-loja';
    form.querySelector('[data-endereco-cobranca]').hidden = !faturamento;
    form.querySelector('[data-calcular]').hidden = faturamento;
    form.querySelector('[data-opcoes]').hidden = faturamento;
    painelMelhorEnvio.setAttribute('aria-label', faturamento ? 'Endereço de cobrança' : 'Endereço de entrega');
  };
  const atualizarTipoEntrega = () => {
    const tipo = tipoEntrega();
    const porTransportadora = tipo === 'melhor-envio';
    habilitarCamposEndereco(porTransportadora || (loja.config.checkoutIntegrado && tipo === 'retirada-loja'));
    avisoRetirada.hidden = tipo !== 'retirada-loja';
    avisoWhatsApp.hidden = tipo !== 'whatsapp';
    if (tipo === 'retirada-loja') opcoes = [{ id: 'retirada-loja', nome: 'Retirada na loja', preco: 0, prazoDias: 0 }];
    if (tipo === 'whatsapp') opcoes = [];
    botaoFinalizar.textContent = tipo === 'whatsapp' ? 'Continuar no WhatsApp' : 'Finalizar pedido';
    atualizarTotal();
    mostrarErro('');
  };

  raiz.querySelector('[data-calcular]').addEventListener('click', async (e) => {
    const botao = e.currentTarget;
    mostrarErro('');
    botao.disabled = true;
    try {
      ({ opcoes } = await api('/api/frete', { metodo: 'POST', dados: { cep: form.cep.value, itens: itensApi() } }));
      raiz.querySelector('[data-opcoes]').innerHTML = opcoes.map((o, i) => `
        <label class="opcao"><input type="radio" name="frete" value="${esc(o.id)}"${i ? '' : ' checked'}>
          <span><strong>${esc(o.nome)}</strong><br><small>${o.prazoDias ? `até ${o.prazoDias} dias úteis` : 'prazo a confirmar'}</small></span>
          <strong>${brl(o.preco)}</strong></label>`).join('');
      atualizarTotal();
    } catch (falha) {
      mostrarErro(falha.message);
    } finally {
      botao.disabled = false;
    }
  });
  raiz.querySelector('[data-opcoes]').addEventListener('change', atualizarTotal);
  form.querySelector('[data-tipos-entrega]').addEventListener('change', atualizarTipoEntrega);
  atualizarTipoEntrega();

  async function combinarNoWhatsApp() {
    const janela = window.open('about:blank', '_blank');
    if (janela) janela.opener = null;
    try {
      const { pedido } = await api('/api/pedidos', { metodo: 'POST', dados: { itens: itensApi() } });
      const linhas = pedido.itens.map((i) => `• ${i.qtd}x ${i.nome} (${i.cor} / ${i.tamanho}) — ${brl(i.preco * i.qtd)}`);
      const texto = `Olá! Quero combinar a entrega do pedido #${pedido.numero}:\n\n${linhas.join('\n')}\n\nSubtotal: ${brl(pedido.total)}`;
      const url = `https://wa.me/${loja.config.whatsapp || ''}?text=${encodeURIComponent(texto)}`;
      if (janela) janela.location.href = url;
      else location.href = url;
      limparCarrinho();
    } catch (falha) {
      janela?.close();
      throw falha;
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const tipo = tipoEntrega();
    const frete = tipo === 'retirada-loja'
      ? { value: 'retirada-loja' }
      : form.querySelector('input[name="frete"]:checked');
    if (tipo === 'melhor-envio' && !frete) return mostrarErro('Calcule e escolha o frete.');
    const d = Object.fromEntries(new FormData(form));
    botaoFinalizar.disabled = true;
    mostrarErro('');
    try {
      if (tipo === 'whatsapp') {
        await combinarNoWhatsApp();
        return mensagem(raiz, 'Pedido enviado ao WhatsApp', '<p>Seu pedido foi registrado. Continue o atendimento pelo WhatsApp da loja.</p>');
      }
      const { pedido } = await api('/api/checkout', {
        metodo: 'POST',
        dados: {
          itens: itensApi(),
          tipoEntrega: tipo,
          freteServico: frete.value,
          cliente: { nome: d.nome, cpf: d.cpf, telefone: d.telefone },
          endereco: tipo === 'melhor-envio' || loja.config.checkoutIntegrado
            ? { cep: d.cep, rua: d.rua, numero: d.numero, complemento: d.complemento, bairro: d.bairro, cidade: d.cidade, uf: d.uf }
            : undefined,
          pagamento: loja.config.checkoutIntegrado ? 'getnet-checkout' : 'pix',
          chaveIdempotencia: chaveIdempotencia(itensApi()),
        },
      });
      history.replaceState(null, '', `/checkout#pedido=${pedido.id}`);
      try { sessionStorage.setItem(ULTIMO_PEDIDO, pedido.id); } catch {}
      telaPix(raiz, pedido);
    } catch (falha) {
      mostrarErro(falha.message);
      botaoFinalizar.disabled = false;
    }
  });
}

function telaPix(raiz, pedido) {
  clearTimeout(consulta);
  if (['pago', 'enviado', 'entregue'].includes(pedido.status)) {
    limparCarrinho();
    try { sessionStorage.removeItem(CHAVE_TENTATIVA); sessionStorage.removeItem(ULTIMO_PEDIDO); } catch {}
    return mensagem(raiz, 'Pagamento confirmado!', `<p>Pedido <strong>#${pedido.numero}</strong> confirmado. Você recebe o código de rastreio assim que ele for enviado.</p>
      <a class="botao" href="/conta">Acompanhar pedido</a>`);
  }
  if (pedido.status === 'aguardando' && pedido.pagamentoDados?.tipo === 'getnet-global') return telaGlobal(raiz, pedido);
  if (pedido.status === 'aguardando' && !pedido.pagamentoId && pedido.pagamentoMetodo === 'getnet-checkout') {
    return mensagem(raiz, `Pedido #${pedido.numero}`, '<p>Esta tentativa de pagamento aguarda conferência pela loja. Não faça outro pagamento até confirmar a situação.</p><a class="botao" href="/conta">Ver meus pedidos</a>');
  }
  if (pedido.status !== 'aguardando' || !pedido.pagamentoDados?.copiaECola) {
    return mensagem(raiz, `Pedido #${pedido.numero}`, `<p>Situação: <strong>${esc(pedido.status)}</strong>.</p><a class="botao" href="/conta">Ver meus pedidos</a>`);
  }
  const codigo = pedido.pagamentoDados.copiaECola;
  raiz.innerHTML = `
    <h1 class="secao__titulo">Pague com Pix</h1>
    <div class="caixa pix">
      <p>Pedido <strong>#${pedido.numero}</strong> · Total <strong>${brl(pedido.total)}</strong></p>
      <p>Copie o código e cole no app do seu banco, em <strong>Pix copia e cola</strong>.</p>
      <textarea readonly aria-label="Código Pix copia e cola">${esc(codigo)}</textarea>
      <button class="botao" type="button" data-copiar>Copiar código Pix</button>
      <small aria-live="polite" data-situacao>Aguardando a confirmação do pagamento…</small>
    </div>`;
  raiz.querySelector('[data-copiar]').addEventListener('click', async (e) => {
    try {
      await navigator.clipboard.writeText(codigo);
      e.target.textContent = 'Código copiado!';
    } catch {
      raiz.querySelector('textarea').select();
    }
  });
  const verificar = () => {
    consulta = setTimeout(async () => {
      try {
        const r = await api(`/api/pedidos/${encodeURIComponent(pedido.id)}`);
        if (r.pedido.status !== 'aguardando') return telaPix(raiz, r.pedido);
      } catch {}
      verificar();
    }, 5000);
  };
  verificar();
}

function telaGlobal(raiz, pedido) {
  raiz.innerHTML = `<h1 class="secao__titulo">Pagamento seguro</h1>
    <div class="caixa getnet">
      <div class="getnet__cabecalho"><div><small>DRED STIL · CHECKOUT</small><h2>Pedido #${pedido.numero}</h2></div><strong>${brl(pedido.total)}</strong></div>
      ${pedido.pagamentoDados.ambiente === 'homologacao' ? '<p class="getnet__aviso">Ambiente de homologação · use apenas os dados de teste fornecidos pela Getnet.</p>' : ''}
      <p>Escolha cartão ou Pix e confira as condições antes de pagar. O pagamento é preenchido na Getnet, dentro desta página.</p>
      <button type="button" class="botao" data-abrir-getnet>Abrir pagamento seguro</button>
      <p class="erro-form" role="alert" data-erro-getnet hidden></p>
      <div class="getnet__componente" data-getnet aria-label="Formulário de pagamento"></div>
      <p role="status" aria-live="polite" data-status-getnet>Aguardando pagamento.</p>
      <button type="button" class="botao botao--sec" data-consultar-getnet>Já paguei, verificar status</button>
      <a href="/conta">Acompanhar meus pedidos</a>
    </div>`;
  const abrir = raiz.querySelector('[data-abrir-getnet]');
  const erro = raiz.querySelector('[data-erro-getnet]');
  const status = raiz.querySelector('[data-status-getnet]');
  const verificar = raiz.querySelector('[data-consultar-getnet]');
  const container = raiz.querySelector('[data-getnet]');
  abrir.addEventListener('click', async () => {
    abrir.disabled = true;
    erro.hidden = true;
    try {
      await abrirCheckout(container, pedido.pagamentoDados);
      abrir.hidden = true;
    } catch (e) { erro.textContent = e.message; erro.hidden = false; abrir.disabled = false; }
  });
  let consultando = false;
  let ultimoInicio = 0;
  const consultar = async () => {
    if (!container.isConnected || consultando || Date.now() - ultimoInicio < 8000) return;
    ultimoInicio = Date.now();
    consultando = true;
    verificar.disabled = true;
    try {
      const r = await api(`/api/pedidos/${encodeURIComponent(pedido.id)}/consultar-pagamento`, { metodo: 'POST', dados: {} });
      if (!container.isConnected) return;
      if (r.pedido.status !== 'aguardando') return telaPix(raiz, r.pedido);
      status.textContent = r.pedido.pagamentoStatus === 'negado'
        ? 'Pagamento recusado. Você pode escolher outra opção no formulário seguro.'
        : 'Pagamento ainda pendente. A confirmação será atualizada automaticamente.';
    } catch (e) { if (container.isConnected) status.textContent = `Não foi possível confirmar agora. ${e.message}`; }
    finally { consultando = false; verificar.disabled = false; }
  };
  verificar.addEventListener('click', consultar);
  const repetir = () => {
    consulta = setTimeout(async () => {
      if (!container.isConnected) return;
      if (!document.hidden) await consultar();
      if (container.isConnected) repetir();
    }, 10_000);
  };
  repetir();
}

export async function iniciar() {
  const raiz = document.querySelector('[data-checkout]');
  const [usuario, loja] = await Promise.all([carregarUsuario(), carregarLoja()]);
  if (!usuario) {
    return mensagem(raiz, 'Finalizar compra', `<p>Entre ou crie sua conta para concluir o pedido e acompanhar a entrega.</p>
      <a class="botao" href="/conta?voltar=/checkout">Entrar ou criar conta</a>`);
  }
  let pedidoId = new URLSearchParams(location.hash.slice(1)).get('pedido');
  if (!pedidoId) { try { pedidoId = sessionStorage.getItem(ULTIMO_PEDIDO); } catch {} }
  if (pedidoId) {
    try {
      return telaPix(raiz, (await api(`/api/pedidos/${encodeURIComponent(pedidoId)}`)).pedido);
    } catch (falha) {
      return mensagem(raiz, 'Pedido', `<p>${esc(falha.message)}</p><a class="botao" href="/conta">Ver meus pedidos</a>`);
    }
  }
  if (!loja.config.checkout) {
    return mensagem(raiz, 'Finalizar compra', '<p>O pagamento online está indisponível no momento. Finalize pelo carrinho, que segue para o WhatsApp da loja.</p><a class="botao" href="/catalogo">Voltar à loja</a>');
  }
  if (!itensDoCarrinho().length) {
    return mensagem(raiz, 'Seu carrinho está vazio', '<a class="botao" href="/catalogo">Ver o catálogo</a>');
  }
  telaCheckout(raiz, usuario, loja);
}
