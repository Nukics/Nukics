// Minha conta: entrar (com código em duas etapas) / criar conta / esqueci a senha e, logado,
// dados pessoais, senha, segurança e pedidos.
import { api } from '../api.js';
import { aviso } from '../aviso.js';
import { carregarLoja, carregarUsuario } from '../estado.js';
import { aoEnviar } from '../formulario.js';
import { SITUACOES_PEDIDO, brl, dataCurta, destinoSeguro, esc, seloBomCliente } from '../util.js';

const destino = () => destinoSeguro(new URLSearchParams(location.search).get('voltar'), '/conta');
const irParaDestino = () => (location.href = destino()); // recarrega para o cabeçalho refletir a conta

const linkWhatsApp = (whatsapp, texto) => 'https://wa.me/' + whatsapp + '?text=' + encodeURIComponent(texto);

function telaAcesso(raiz, whatsapp, avisoInicial) {
  raiz.innerHTML = `
    <h1 class="secao__titulo">Minha conta</h1>
    <div class="abas conta__abas" role="tablist" aria-label="Acesso">
      <button type="button" role="tab" id="aba-entrar" aria-controls="form-entrar" aria-selected="true" data-modo="entrar">Entrar</button>
      <button type="button" role="tab" id="aba-cadastro" aria-controls="form-cadastro" aria-selected="false" data-modo="cadastro">Criar conta</button>
    </div>
    <p class="conta__ok" role="status" data-ok ${avisoInicial ? '' : 'hidden'}>${esc(avisoInicial || '')}</p>
    <form class="cartao-form" id="form-entrar" role="tabpanel" aria-labelledby="aba-entrar" data-form="entrar">
      <label class="campo"><span>E-mail ou apelido</span><input name="identificador" autocomplete="username" required maxlength="160"></label>
      <label class="campo"><span>Senha</span><input type="password" name="senha" autocomplete="current-password" required></label>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <button class="botao botao--largo" type="submit">Entrar</button>
      <button type="button" class="conta__esqueci link-botao" data-modo="esqueci">Esqueci minha senha</button>
    </form>
    <form class="cartao-form" id="form-cadastro" role="tabpanel" aria-labelledby="aba-cadastro" data-form="cadastro" hidden>
      <label class="campo"><span>Nome completo</span><input name="nome" autocomplete="name" required minlength="5" maxlength="100" placeholder="Nome e sobrenome"></label>
      <label class="campo"><span>Apelido</span><input name="apelido" autocomplete="username" required minlength="3" maxlength="30" pattern="[A-Za-z0-9_.]{3,30}" placeholder="ex.: joao.silva">
        <small>Nome de usuário da conta: letras sem acento, números, ponto ou sublinhado.</small></label>
      <label class="campo"><span>E-mail</span><input type="email" name="email" autocomplete="email" required maxlength="160"></label>
      <label class="campo"><span>Telefone (com DDD)</span><input type="tel" name="telefone" autocomplete="tel" required maxlength="15" placeholder="(41) 99999-9999"></label>
      <label class="campo"><span>CPF <small>(opcional)</small></span><input name="cpf" inputmode="numeric" autocomplete="off" maxlength="14" placeholder="000.000.000-00"></label>
      <label class="campo"><span>Senha</span><input type="password" name="senha" autocomplete="new-password" required minlength="8">
        <small>Mínimo de 8 caracteres. Não use a mesma senha de outros sites.</small></label>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <button class="botao botao--largo" type="submit">Criar conta</button>
      <small>Ao criar a conta você concorda com os <a href="/termos-de-uso">Termos de uso</a> e a <a href="/politica-de-privacidade">Política de privacidade</a>.</small>
    </form>
    <form class="cartao-form" data-form="esqueci" hidden>
      <p>Informe o <strong>e-mail</strong>, o <strong>apelido</strong> ou o <strong>nome completo</strong> da sua conta. O link para criar uma nova senha vai para o e-mail cadastrado.</p>
      <label class="campo"><span>E-mail, apelido ou nome completo</span><input name="identificador" autocomplete="username" required maxlength="160"></label>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <button class="botao botao--largo" type="submit">Enviar link</button>
      <button type="button" class="conta__esqueci link-botao" data-modo="entrar">Voltar para o login</button>
    </form>`;

  const mostrar = (modo) => {
    raiz.querySelectorAll('[role="tab"]').forEach((b) => b.setAttribute('aria-selected', b.dataset.modo === modo));
    raiz.querySelectorAll('[data-form]').forEach((f) => (f.hidden = f.dataset.form !== modo));
    raiz.querySelector(`[data-form="${modo}"] input`).focus();
  };
  raiz.addEventListener('click', (e) => {
    const botao = e.target.closest('[data-modo]');
    if (botao) mostrar(botao.dataset.modo);
  });

  aoEnviar(raiz.querySelector('[data-form="entrar"]'), async (dados) => {
    const r = await api('/api/conta/entrar', { metodo: 'POST', dados });
    if (r.etapa === 'codigo') telaCodigo(raiz, r.desafio, 'o e-mail da sua conta', whatsapp);
    else irParaDestino();
  });
  aoEnviar(raiz.querySelector('[data-form="cadastro"]'), async (dados) => {
    await api('/api/conta/cadastro', { metodo: 'POST', dados });
    irParaDestino();
  });
  const formEsqueci = raiz.querySelector('[data-form="esqueci"]');
  aoEnviar(formEsqueci, async (dados) => {
    try {
      const r = await api('/api/conta/esqueci-senha', { metodo: 'POST', dados });
      formEsqueci.reset();
      aviso(r.mensagem);
    } catch (erro) {
      // sem e-mail configurado: segue pelo WhatsApp da loja
      if (erro.status === 503 && whatsapp) {
        window.open(linkWhatsApp(whatsapp, `Olá! Esqueci a senha da minha conta no site da Dred Stil. Meus dados de cadastro: ${dados.identificador}`), '_blank', 'noopener');
        return;
      }
      throw erro;
    }
  });
}

function telaCodigo(raiz, desafio, email, whatsapp) {
  raiz.innerHTML = `
    <h1 class="secao__titulo">Verificação em duas etapas</h1>
    <form class="cartao-form" data-form="codigo">
      <p>Enviamos um código de 6 dígitos para ${esc(email)}. Ele vale por 10 minutos.</p>
      <label class="campo"><span>Código</span><input class="campo-codigo" name="codigo" inputmode="numeric" autocomplete="one-time-code" pattern="\\d{6}" maxlength="6" required></label>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <button class="botao botao--largo" type="submit">Confirmar</button>
      <button type="button" class="conta__esqueci link-botao" data-voltar>Voltar</button>
    </form>`;
  raiz.querySelector('input').focus();
  raiz.querySelector('[data-voltar]').addEventListener('click', () => telaAcesso(raiz, whatsapp));
  aoEnviar(raiz.querySelector('form'), async ({ codigo }) => {
    await api('/api/conta/codigo', { metodo: 'POST', dados: { desafio, codigo } });
    irParaDestino();
  });
}

function telaNovaSenha(raiz, token, whatsapp) {
  raiz.innerHTML = `
    <h1 class="secao__titulo">Criar nova senha</h1>
    <form class="cartao-form" data-form="nova-senha">
      <p>Ao salvar, você sai da conta em todos os aparelhos.</p>
      <label class="campo"><span>Nova senha</span><input type="password" name="senha" autocomplete="new-password" required minlength="8"></label>
      <label class="campo"><span>Repita a nova senha</span><input type="password" name="repetir" autocomplete="new-password" required minlength="8"></label>
      <p class="erro-form" role="alert" data-erro hidden></p>
      <button class="botao botao--largo" type="submit">Salvar nova senha</button>
    </form>`;
  raiz.querySelector('input').focus();
  aoEnviar(raiz.querySelector('form'), async ({ senha, repetir }) => {
    if (senha !== repetir) throw new Error('As senhas não são iguais.');
    const r = await api('/api/conta/redefinir-senha', { metodo: 'POST', dados: { token, senha } });
    telaAcesso(raiz, whatsapp, r.mensagem);
  });
}

function htmlNota(nota) {
  if (!nota) return '';
  if (nota.status === 'autorizada') {
    return `<span>Nota fiscal nº ${esc(nota.numero || '')}: ${nota.urlDanfe ? `<a href="${esc(nota.urlDanfe)}" target="_blank" rel="noopener noreferrer">ver DANFE (PDF)</a>` : 'emitida'}</span>`;
  }
  return nota.status === 'processando' ? '<span class="ajuda">Nota fiscal em emissão</span>' : '';
}

function htmlPedidos(pedidos, notas = []) {
  if (!pedidos.length) return '<p>Você ainda não fez pedidos. <a href="/catalogo">Ver o catálogo</a></p>';
  return `<ul class="pedidos">${pedidos.map((p) => {
    const pagarPix = p.status === 'aguardando' && p.pagamentoDados?.copiaECola;
    const pagarGetnet = p.status === 'aguardando' && p.pagamentoDados?.tipo === 'getnet-global';
    return `
    <li class="pedido">
      <div class="pedido__topo"><strong>Pedido #${p.numero}</strong><span class="etiqueta etiqueta--${esc(p.status)}">${esc(SITUACOES_PEDIDO[p.status] || p.status)}</span></div>
      <span class="pedido__data">${dataCurta(p.criadoEm)} · ${p.total ? brl(p.total) : 'valor a combinar'}${p.freteNome ? ` · ${esc(p.freteNome)}` : ''}</span>
      <span class="pedido__itens">${p.itens.map((i) => `${i.qtd}x ${esc(i.nome)} (${esc(i.cor)} / ${esc(i.tamanho)})`).join(', ')}</span>
      ${p.rastreio ? `<span>Rastreio: <strong>${esc(p.rastreio)}</strong></span>` : ''}
      ${htmlNota(notas.find((n) => n.pedidoId === p.id))}
      ${pagarPix ? `<a class="botao botao--pequeno" href="/checkout#pedido=${encodeURIComponent(p.id)}">Pagar com Pix</a>` : ''}
      ${pagarGetnet ? `<a class="botao botao--pequeno" href="/checkout#pedido=${encodeURIComponent(p.id)}">Continuar pagamento</a>` : ''}
    </li>`;
  }).join('')}</ul>`;
}

function htmlSeguranca(usuario) {
  const confirmar = usuario.emailVerificado
    ? '<p class="conta__selo-ok">✓ E-mail confirmado</p>'
    : `<p>Seu e-mail ainda não foi confirmado.</p>
       <button class="botao botao--sec botao--pequeno" type="button" data-confirmar-email>Enviar link de confirmação</button>`;
  return `
    <div class="caixa form-grade" data-seguranca>
      <h2>Segurança</h2>
      ${usuario.adminPendente2fa ? '<p class="erro-form">A conta admin precisa da verificação em duas etapas para usar o painel. Ative abaixo e entre de novo.</p>' : ''}
      ${confirmar}
      <form class="form-grade" data-form="dois-fatores">
        <p><strong>Verificação em duas etapas</strong> <span class="etiqueta${usuario.doisFatores ? ' etiqueta--ok' : ''}">${usuario.doisFatores ? 'Ativa' : 'Desligada'}</span><br>
        <small>A cada login pedimos um código enviado ao seu e-mail.</small></p>
        <label class="campo"><span>Confirme sua senha</span><input type="password" name="senha" autocomplete="current-password" required></label>
        <p class="erro-form" role="alert" data-erro hidden></p>
        <button class="botao${usuario.doisFatores ? ' botao--sec' : ''}" type="submit"${!usuario.emailVerificado && !usuario.doisFatores ? ' disabled' : ''}>
          ${usuario.doisFatores ? 'Desativar' : 'Ativar'} verificação em duas etapas</button>
      </form>
      <button class="botao botao--sec botao--pequeno" type="button" data-sair-todos>Sair de todos os aparelhos</button>
    </div>`;
}

function telaPerfil(raiz, usuario, { pedidos, notas, compras, bomCliente }) {
  raiz.innerHTML = `
    <h1 class="secao__titulo">Minha conta</h1>
    ${usuario.cadastroIncompleto ? '<p class="erro-form conta__aviso">Complete seu cadastro em <strong>Meus dados</strong>: nome completo, apelido e telefone agora são obrigatórios.</p>' : ''}
    <div class="conta__grade">
      <div class="caixa">
        <p class="conta__ola">Olá, ${esc(usuario.nome.split(' ')[0])}! ${bomCliente ? seloBomCliente() : ''}</p>
        <p class="conta__email">${esc(usuario.email)}</p>
        <p class="conta__compras">${compras === 1 ? '1 compra' : `${compras} compras`} na Dred Stil</p>
        <div class="conta__atalhos">
          <a class="botao botao--sec botao--pequeno" href="/favoritos">Meus favoritos (${usuario.curtidas.length})</a>
          ${usuario.papel === 'admin' && !usuario.adminPendente2fa ? '<a class="botao botao--pequeno" href="/admin">Painel admin</a>' : ''}
          <button class="botao botao--perigo botao--pequeno" type="button" data-sair>Sair</button>
        </div>
      </div>
      <div class="caixa">
        <h2>Meus pedidos</h2>
        ${htmlPedidos(pedidos, notas)}
      </div>
      ${htmlSeguranca(usuario)}
      <form class="caixa form-grade" data-form="perfil">
        <h2>Meus dados</h2>
        <label class="campo"><span>Nome completo</span><input name="nome" autocomplete="name" required minlength="5" maxlength="100" value="${esc(usuario.nome)}"></label>
        <label class="campo"><span>Apelido</span><input name="apelido" autocomplete="username" required minlength="3" maxlength="30" pattern="[A-Za-z0-9_.]{3,30}" value="${esc(usuario.apelido || '')}"></label>
        <label class="campo"><span>Telefone (com DDD)</span><input type="tel" name="telefone" autocomplete="tel" required maxlength="15" value="${esc(usuario.telefone)}" placeholder="(41) 99999-9999"></label>
        <label class="campo"><span>CPF <small>(opcional)</small></span><input name="cpf" inputmode="numeric" autocomplete="off" maxlength="14" value="${esc(usuario.cpf || '')}" placeholder="000.000.000-00"></label>
        <p class="erro-form" role="alert" data-erro hidden></p>
        <button class="botao" type="submit">Salvar dados</button>
      </form>
      <form class="caixa form-grade" data-form="senha">
        <h2>Trocar senha</h2>
        <label class="campo"><span>Senha atual</span><input type="password" name="senhaAtual" autocomplete="current-password" required></label>
        <label class="campo"><span>Nova senha</span><input type="password" name="senhaNova" autocomplete="new-password" required minlength="8"></label>
        <p class="erro-form" role="alert" data-erro hidden></p>
        <button class="botao" type="submit">Trocar senha</button>
      </form>
    </div>`;

  raiz.querySelector('[data-sair]').addEventListener('click', async () => {
    await api('/api/conta/sair', { metodo: 'POST' });
    location.href = '/';
  });
  raiz.querySelector('[data-sair-todos]').addEventListener('click', async () => {
    if (!confirm('Sair da conta em todos os aparelhos, inclusive este?')) return;
    await api('/api/conta/sair-de-todos', { metodo: 'POST' });
    location.href = '/conta';
  });
  raiz.querySelector('[data-confirmar-email]')?.addEventListener('click', async (e) => {
    e.target.disabled = true;
    try {
      aviso((await api('/api/conta/verificar-email/enviar', { metodo: 'POST' })).mensagem);
    } catch (erro) {
      aviso(erro.message, { erro: true });
      e.target.disabled = false;
    }
  });
  aoEnviar(raiz.querySelector('[data-form="dois-fatores"]'), async ({ senha }) => {
    const ativar = !usuario.doisFatores;
    await api('/api/conta/dois-fatores', { metodo: 'POST', dados: { ativar, senha } });
    aviso(ativar ? 'Verificação em duas etapas ativada. Os outros aparelhos foram desconectados.' : 'Verificação em duas etapas desativada.');
    setTimeout(() => location.reload(), 1200);
  });
  aoEnviar(raiz.querySelector('[data-form="perfil"]'), async (dados) => {
    const r = await api('/api/conta', { metodo: 'PATCH', dados });
    Object.assign(usuario, r.usuario);
    raiz.querySelector('.conta__ola').firstChild.textContent = `Olá, ${usuario.nome.split(' ')[0]}! `;
    raiz.querySelector('.conta__aviso')?.remove();
    aviso('Dados salvos.');
  });
  const formSenha = raiz.querySelector('[data-form="senha"]');
  aoEnviar(formSenha, async ({ senhaAtual, senhaNova }) => {
    await api('/api/conta/senha', { metodo: 'POST', dados: { senhaAtual, senhaNova } });
    formSenha.reset();
    aviso('Senha alterada. Outros aparelhos foram desconectados.');
  });
}

export async function iniciar() {
  const raiz = document.querySelector('[data-conta]');
  const whatsapp = () => carregarLoja().then((l) => l.config.whatsapp || '').catch(() => '');

  // Links dos e-mails chegam no fragmento (#), que não vai para servidores nem logs.
  window.addEventListener('hashchange', () => /^#(verificar|redefinir)=/.test(location.hash) && location.reload());
  const hash = new URLSearchParams(location.hash.slice(1));
  const verificar = hash.get('verificar');
  const redefinir = hash.get('redefinir');
  if (verificar || redefinir) history.replaceState(null, '', location.pathname + location.search);
  if (redefinir) return telaNovaSenha(raiz, redefinir, await whatsapp());
  if (verificar) {
    try {
      aviso((await api('/api/conta/verificar-email', { metodo: 'POST', dados: { token: verificar } })).mensagem);
    } catch (erro) {
      aviso(erro.message, { erro: true });
    }
  }

  const usuario = await carregarUsuario();
  if (!usuario) return telaAcesso(raiz, await whatsapp());
  // já logado e veio de um link "entre para continuar": segue para o destino
  if (new URLSearchParams(location.search).has('voltar') && !usuario.adminPendente2fa) return location.replace(destino());
  telaPerfil(raiz, usuario, await api('/api/conta/pedidos'));
}
