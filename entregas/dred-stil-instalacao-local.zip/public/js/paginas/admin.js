// Painel admin: abas que carregam cada seção sob demanda.
import { aviso } from '../aviso.js';

const SECOES = {
  vendas: () => import('../admin/vendas.js').then((m) => m.montarVendas),
  pedidos: () => import('../admin/pedidos.js').then((m) => m.montarPedidos),
  produtos: () => import('../admin/produtos.js').then((m) => m.montarProdutos),
  estoque: () => import('../admin/estoque.js').then((m) => m.montarEstoque),
  categorias: () => import('../admin/categorias.js').then((m) => m.montarCategorias),
  destaques: () => import('../admin/destaques.js').then((m) => m.montarDestaques),
  menu: () => import('../admin/menu.js').then((m) => m.montarMenu),
  clientes: () => import('../admin/clientes.js').then((m) => m.montarClientes),
  paginas: () => import('../admin/paginas.js').then((m) => m.montarPaginas),
  faq: () => import('../admin/faq.js').then((m) => m.montarFaq),
  config: () => import('../admin/config.js').then((m) => m.montarConfig),
};

export function iniciar() {
  const montadas = new Set();

  function abrir(nome) {
    document.querySelectorAll('[data-secao]').forEach((b) => b.setAttribute('aria-selected', b.dataset.secao === nome));
    document.querySelectorAll('[data-painel]').forEach((p) => (p.hidden = p.dataset.painel !== nome));
    if (!montadas.has(nome)) {
      montadas.add(nome);
      SECOES[nome]().then((montar) => montar(document.querySelector(`[data-painel="${nome}"]`))).catch((erro) => {
        montadas.delete(nome);
        aviso(erro.message, { erro: true });
      });
    }
    history.replaceState(null, '', `#${nome}`);
  }

  document.addEventListener('click', (e) => {
    const aba = e.target.closest('[data-secao], [data-ir-aba]');
    if (!aba) return;
    e.preventDefault();
    abrir(aba.dataset.secao || aba.dataset.irAba);
  });
  const inicial = location.hash.slice(1);
  abrir(SECOES[inicial] ? inicial : 'vendas');
}
