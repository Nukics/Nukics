# Destaques, estoque por cor e categorias

## Atualizar a loja existente

O ZIP contém o projeto completo, incluindo as melhorias de banners, logo, Atacado e a integração Getnet já preparadas. Nenhuma migração foi aplicada no seu Supabase e nenhum site de produção foi publicado por esta entrega.

1. Faça uma cópia do banco antes da atualização.
2. Se as migrações 002, 003 e 004 já foram aplicadas, execute no SQL Editor do Supabase, nesta ordem:
   - `supabase/migracoes/005-estoque-por-cor.sql`
   - `supabase/migracoes/006-categorias-mover.sql`
3. Publique o código completo junto com essas migrações. Preserve suas variáveis de ambiente; o ZIP contém somente `.env.example`, sem credenciais.
4. Confira os saldos reais no admin antes de habilitar vendas com os novos grupos.

As migrações são reaplicáveis. Elas não apagam produtos, categorias, pedidos nem quantidades antigas. Não execute os arquivos de reversão como parte da instalação.

## Estoque por tipo de peça e cor

Em **Admin > Estoque > Novo grupo e cor**, informe:

- Tipo de peça / grupo: `Camisa oversized`.
- Cor: `Preto` (lista das cores já cadastradas nos produtos).
- Peças disponíveis: `30`.
- Produtos: `Camisa oversized Nike`, `Camisa Oversized DredStil`, `Camisa Oversized Vans`.

Use **Adicionar cor** no mesmo grupo para cadastrar `Branco`, por exemplo com 15 peças. Não precisa criar categorias de catálogo para controlar o estoque: os agrupamentos de estoque ficam no painel de Estoque.

Uma venda de Nike preta baixa apenas o saldo Preto desse grupo. A mesma cor de DredStil e Vans usa o saldo restante; o Branco mantém suas 15 peças. Tamanhos distintos compartilham o saldo da mesma cor. Um produto pode usar grupos diferentes por cor. Apenas produtos que possuem a cor escolhida podem ser vinculados.

O carrinho é conferido pelo servidor, somando todos os produtos e tamanhos vinculados ao mesmo saldo. O navegador não define o saldo usado. Se a cor escolhida estiver esgotada, a página do produto desabilita a compra dessa cor; as demais cores continuam compráveis. As quantidades e os identificadores dos saldos não são publicados nos dados da vitrine.

A cor de um saldo existente é fixa, para preservar os pedidos e o histórico. Para outra cor, crie um novo saldo. Nome, quantidade e produtos vinculados continuam editáveis. Mover a cor de um produto para outro grupo não move suas outras cores nem transfere quantidades automaticamente.

### Grupos antigos

Grupos existentes ficam identificados como **Saldo compartilhado (legado)**. Eles continuam controlando as cores sem saldo específico. Um saldo específico da cor tem prioridade sobre esse vínculo antigo.

A migração não sabe quantas peças de cada cor existem: conte as peças e crie os saldos com as quantidades reais. Ao terminar, retire os vínculos antigos ou arquive o saldo compartilhado. Não copie o total antigo para cada cor. O painel lista explicitamente as cores sem controle; elas continuam vendendo sem limite, como no funcionamento anterior.

### Pagamento, devoluções e histórico

A quantidade é baixada quando o pedido passa a **Pago**, **Enviado** ou **Entregue**, uma única vez. Cancelar uma venda devolve a baixa registrada ao saldo original. Mudar os produtos de grupo ou arquivar o saldo depois da compra não redireciona as peças para outra cor.

**Excluir** arquiva o saldo: remove os vínculos para novas vendas, mas preserva seu registro e os vínculos dos pedidos anteriores. Se houver saldo compartilhado antigo, ele volta a valer para aquela cor; sem outro vínculo, novas vendas daquela cor ficam sem limite. Pedidos já criados conservam o saldo conferido na compra. Os movimentos podem ser consultados pela rota administrativa de histórico, inclusive depois do arquivamento, com o identificador do saldo.

Pedidos aguardando pagamento continuam sem reserva de peças, como antes. Duas cobranças abertas podem disputar as últimas peças. A confirmação não torna o saldo negativo nem retira de outra cor; eventual falta fica identificada no histórico da venda como **faltam N peças; conferir reposição**, e a loja precisa tratar a reposição ou o estorno com o cliente. Os novos movimentos registram a baixa efetiva para não devolver peças que não foram retiradas. Movimentos antigos conservam os valores gravados pelo sistema anterior; a migração não reconstrói contagens históricas.

A vitrine usa cache curto; o checkout sempre confere o saldo atual no servidor. Notificações de pagamento limpam o cache na instância que as processa. A CDN revalida a cada 60 segundos, sem a janela anterior de até 10 minutos de conteúdo desatualizado.

## Categorias existentes como subcategorias

Em **Admin > Categorias**, escolha uma categoria principal no seletor **Dentro de** da categoria que deseja mover. Também é possível mover uma subcategoria para outra principal ou escolher **Categoria principal** para trazê-la à raiz.

O endereço (slug), os produtos vinculados e a opção de aparecer no menu são preservados. A categoria vai para o fim da lista dos novos irmãos. A loja mantém uma categoria principal e um nível de subcategorias. Uma categoria que já tem filhas precisa ter as filhas movidas primeiro. O painel e o banco impedem ciclos, autorreferência e um terceiro nível.

## Destaques na horizontal

Todos os produtos escolhidos em **Admin > Destaques** aparecem no trilho, sem o limite anterior de oito itens. Use gesto lateral no celular ou as setas no computador. O trilho também aceita teclado. Trocar a aba retorna ao primeiro produto. O catálogo comum continua com sua grade.

## Validação local

```sh
npm ci
npm test
node scripts/demo-local.js
```

A demonstração usa um banco descartável e pagamentos simulados. Estes testes não validam transações reais Getnet; a homologação e as habilitações documentadas em `docs/GETNET.md` continuam necessárias.
