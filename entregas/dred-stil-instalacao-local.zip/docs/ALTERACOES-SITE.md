# Ajustes do site Dred Stil

## Banners no admin

Em **Admin > Configurações > Banners**, adicione a imagem e ajuste as prévias de desktop e celular. Cada versão tem posição horizontal, posição vertical e zoom próprios (100% a 180%). **Restaurar enquadramento** volta para a posição central e zoom de 100%. Salve as configurações para aplicar ao site.

O banner cobre toda a largura, com proporção 3:1 no desktop e 4:3 no celular. Se houver margens desenhadas na própria imagem, use o zoom para cortá-las. O preenchimento pode cortar parte da imagem; as duas prévias mostram esse recorte antes de salvar. Banners antigos continuam funcionando com enquadramento central ou com os ajustes anteriores herdados.

Novos banners são convertidos para WebP com lado máximo de 2400 px. As dimensões são salvas na configuração para evitar buscar o arquivo remoto antes de enviar o HTML da página.

## Logo e rodapé

A arte utilizada é `public/img/logo-dredstil-correta.png`, convertida para `logo-dredstil-oficial.webp` sem alteração de pixels. O arquivo passou de 355.429 para 158.988 bytes (55% menor que o original correto). A logo é usada no cabeçalho, menu mobile, rodapé e metadados. Os arquivos antigos foram preservados.

O rodapé recebeu mais espaço superior/inferior, alinhamento das colunas, melhor separação das informações e quebra de textos longos. Sua altura deixa de usar uma estimativa que podia mudar durante a rolagem.

## Página de Atacado

A nova página `/atacado` contém tabela de descontos, simulador e catálogo restrito aos produtos da categoria Atacado e suas subcategorias. O menu de uma categoria com slug `atacado` aponta para essa página; também há acesso pelo rodapé e pelo menu mobile.

| Peças de Atacado | Desconto |
| --- | --- |
| 1 | 0% |
| 2 | 6% |
| 3 | 7% |
| 4 | 8% |
| 5 | 9% |
| 6 | 10% |
| 7 | 11% |
| 8 | 12% |
| 9 | 11% |
| 10 | 12% |
| 11 e 12 | 12% |
| A partir de 13 | 30% |

Os 12% para 11 e 12 peças foram mantidos do comportamento existente. A faixa de 9 peças foi preservada exatamente como solicitada.

É possível combinar modelos, cores e tamanhos. Somente peças elegíveis entram na contagem e recebem desconto; produtos de varejo mantêm o preço. O arredondamento acontece por unidade e a economia mostrada no carrinho corresponde ao valor efetivamente cobrado. O servidor recalcula o pedido nos fluxos WhatsApp, Pix legado e checkout Getnet.

Se ainda não existir, crie no admin a categoria **Atacado** (slug `atacado`) e associe os produtos participantes. Nenhum produto foi reclassificado automaticamente e nenhum dado do Supabase real foi alterado. Os novos campos de banner usam o JSON de configuração existente: estas mudanças do site não exigem migração adicional. A migração 004 continua pertencendo à integração Getnet anterior.

## Carregamento

- O catálogo, os destaques e a foto principal do produto reutilizam o HTML já renderizado pelo servidor, sem reconstruir os elementos na abertura.
- A segunda foto do cartão é baixada ao interagir com ele, evitando carregamento desnecessário em celular e na primeira abertura.
- As seções do admin carregam seus módulos sob demanda; abrir Configurações não baixa os outros dez módulos de seção.
- As curtidas públicas são consultadas em paralelo com os demais dados da vitrine.
- A entrega do HTML não espera consultas de dimensões de banners remotos.
- A troca automática de banners pausa durante interação ou quando a aba fica oculta, e respeita a preferência de movimento reduzido.

Essas melhorias foram verificadas localmente. Não houve medição da hospedagem de produção nem publicação do site nesta tarefa.

## Validação

`npm test`: **79 aprovados, 0 falhas, 0 ignorados**, incluindo pagamentos e novos testes de faixas de desconto, subcategorias, arredondamento e banners.

No Chromium, com banco descartável: larguras 320, 390, 768 e 1440 px sem rolagem horizontal; banner cobrindo a largura; logo correta e espaço do rodapé; preservação dos elementos renderizados no servidor; fotos secundárias carregadas sob interação; tabela/simulador de Atacado; carrinho com 13 peças totalizando R$ 910,00; admin carregando só a seção solicitada; ajustes por dispositivo salvos e reaplicados; upload WebP com dimensões persistidas. Nenhum erro JavaScript no fluxo completo.

A integração Getnet foi mantida. Sua homologação com conta própria permanece pendente conforme `GETNET.md`; os testes de pagamento continuam simulados.
