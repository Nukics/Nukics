# Relatório de segurança — Dred Stil (versão publicada)

Avaliação de 08/10/2026 sobre este código (`dred-stil-v2`, publicado em dred-stil.vercel.app).
Testes feitos **só em ambiente local**, com banco descartável. Nenhum teste invasivo, pagamento real ou mudança no banco de produção.
Segurança de 100% não existe: abaixo está o que foi verificado, corrigido e o que ainda falta.

## 1. O que foi analisado

| Item | Situação encontrada |
|---|---|
| Arquitetura | Node.js puro (`server/`) como função da Vercel; Supabase (Postgres + Storage) com chave `service_role` só no servidor |
| Autenticação | Senhas com scrypt; sessão em cookie assinado (HMAC), com versão para invalidar na troca de senha |
| Proteções já existentes | Preço conferido no banco; CSRF por origem e JSON obrigatório; RLS ligado sem políticas; CSP `script-src 'self'`; upload que confere o tipo real da imagem; sem scripts de terceiros |
| Git | O código publicado **não estava no git**: salvo no commit `d31613a` antes de qualquer mudança |

## 2. Achados

**C** = crítica · **A** = alta · **M** = média · **B** = baixa

| # | Problema e evidência | Cenário e impacto | Sev. | Correção | Como verificar | Status |
|---|---|---|---|---|---|---|
| 1 | Limite de tentativas de login guardado na memória de cada instância e por `req.socket.remoteAddress` | Na Vercel, cada instância tem a própria contagem, e o socket é o proxy da plataforma. Chutar senhas fica praticamente sem limite (ou todos os clientes dividem o mesmo limite) | A | Limites no banco (função `consumir_limite`), IP real via `x-forwarded-for` da Vercel, limite por IP **e** por conta | Teste "limite por conta vale mesmo trocando de IP" | Corrigido |
| 2 | "Esqueci a senha" = admin gera e **vê** uma senha temporária, que segue válida sem troca obrigatória | Admin (ou quem invadir a conta admin) conhece as senhas dos clientes; repasse por WhatsApp expõe a senha | A | Link de redefinição por e-mail (uso único, 30 min, só o hash no banco). O admin só dispara o envio. A senha temporária fica como reserva apenas enquanto o e-mail não estiver configurado | Testes de redefinição e "admin envia link" | Corrigido (depende de configurar o e-mail) |
| 3 | Conta admin sem segundo fator | Senha vazada = controle total da loja (pedidos, clientes, preços) | A | Verificação em duas etapas por e-mail, obrigatória para o admin; a sessão marca se o código foi usado | Testes "admin sem duas etapas é barrado" | Corrigido (exigida quando o e-mail estiver configurado) |
| 4 | Sem pagamento/frete integrados (requisito) | — | — | Checkout Pix (Getnet) e frete Melhor Envio, com regras no servidor | 20 testes de checkout | Implementado |
| 5 | Sem HSTS | Primeiro acesso por HTTP pode ser interceptado | M | HSTS em produção (`vercel.json` e servidor) | `curl -I` mostra `Strict-Transport-Security` | Corrigido |
| 6 | Senhas muito comuns aceitas (`12345678`) | Credential stuffing e chute | M | Lista de senhas comuns recusada | Teste "senha comum é recusada" | Corrigido |
| 7 | Pedido com corpo grande demais derrubava a conexão sem resposta | Cliente via erro de rede em vez de mensagem | B | Servidor descarta o excesso e responde 413 | Teste de corpo gigante | Corrigido |
| 8 | Cadastro informa "Já existe uma conta com este e-mail" | Permite descobrir quem é cliente | M | Mantido por usabilidade (o cadastro entra direto na conta); login e "esqueci a senha" não revelam | — | Risco aceito, revisar |
| 9 | Sem "sair de todos os aparelhos" | Sessão roubada continua válida | M | Rota e botão que invalidam todas as sessões | Teste "sair de todos" | Corrigido |

## 3. Controles do checkout e pagamento

- **Preço, frete e total calculados só no servidor.** Valores enviados pelo navegador são ignorados. Produto "sob consulta" não vai para o Pix.
- **Idempotência:** a mesma tentativa (clique duplo, recarregar, duas requisições juntas) gera um pedido e um Pix só (função `criar_pedido_checkout` + índice único).
- **Anti-abuso:** no máximo 3 pedidos aguardando Pix por cliente e 10 tentativas de checkout a cada 15 minutos.
- **Webhook da Getnet:**
  - segredo na URL, comparado em tempo constante;
  - o conteúdo da notificação **não é confiável**: o status é consultado na Getnet;
  - repetições são ignoradas (`pagamento_eventos`);
  - não regride (de "pago" não volta);
  - valor diferente do total ou pagamento depois de expirar vai para "Em análise".
- **Isolamento:** o cliente só vê os próprios pedidos (o de outra pessoa responde 404).
- **Dados de cartão nunca passam pelo servidor.** O cartão deve entrar pelo checkout hospedado da Getnet (PCI SAQ A).
- **Produção nunca usa simulação:** sem credenciais, o checkout fica desligado e a compra segue pelo WhatsApp, como antes.

## 4. Testes

`npm test` → **32 aprovados, 0 falhos** (banco descartável PGlite com a estrutura e as funções reais da migração; o servidor real responde por HTTP):
- **12 de contas:** scrypt, senha comum, mensagens iguais, limite por conta com troca de IP, esqueci a senha sem enumeração, link de uso único/expirado/substituído, duas etapas (e-mail confirmado, senha, código, 5 tentativas, uso único, derruba outros aparelhos), sair de todos.
- **20 de checkout e admin:** login obrigatório, preço e frete do servidor, frete inventado, sob consulta, CPF/HTML/quantidade/corpo gigante, CSRF, idempotência simultânea, limite de pedidos abertos, isolamento, webhook (sem segredo, falso, repetido, fora de ordem, valor divergente), expiração, pedidos antigos preservados, admin sem/com duas etapas, link de senha pelo admin, funções bloqueadas para a chave pública, produção sem simulação.

**Teste manual no navegador** (`node scripts/demo-local.js`, aprovado):
- cadastro;
- link de confirmação de e-mail;
- ativar as duas etapas;
- sair e entrar de novo com código;
- carrinho → checkout → frete;
- recusa de CPF inválido;
- `/admin` bloqueado para cliente.

**Não executados ou bloqueados:**
- Getnet sandbox: faltam credenciais.
- Melhor Envio real: falta o token.
- E-mail real: falta a conta Resend e o domínio.
- Migração no Supabase de produção: aguarda autorização.
- Carga, DDoS e pentest externo.

## 5. Riscos restantes

1. **Getnet a confirmar.** A URL de consulta do Pix e o formato da notificação estão marcados como `CONFIRMAR` em `server/pagamento/getnet.js`. Teste no sandbox antes de produção.
2. **Sem e-mail configurado em produção:**
   - "esqueci a senha" volta para o WhatsApp;
   - a verificação em duas etapas do admin **não é exigida**, senão o admin ficaria trancado para fora.

   Configure o Resend o quanto antes.
3. **Expiração do Pix uma vez por dia** (limite do plano Hobby da Vercel). Pedidos vencidos ficam "Aguardando" até a tarefa rodar. Não há estoque reservado, então o impacto é baixo.
4. **Sessão em cookie assinado.** "Sair" apaga o cookie do aparelho; um cookie roubado vale até expirar, a menos que se use "Sair de todos os aparelhos" ou se troque a senha.
5. **Cancelar um pedido pago não estorna o Pix:** o estorno é manual no painel Getnet.
6. **LGPD:** CPF e endereço ficam no pedido (nota fiscal e envio). Defina o prazo de retenção e publique-o na Política de privacidade.
7. **`.env.local` local aponta para o banco de produção.** Rodar `node serve.js` no computador mexe em dados reais. Para testar, use `node scripts/demo-local.js`.

## 6. Configurações externas necessárias (sem valores)

| Onde | O quê |
|---|---|
| Supabase | Rodar `supabase/migracoes/002-contas-pagamentos-seguranca.sql` (reversível com `002-reverter.sql`); backups/PITR; MFA na conta |
| Vercel | Variáveis do `.env.example` (`RESEND_API_KEY`, `GETNET_*`, `MELHOR_ENVIO_*`, `CRON_SECRET`, `APP_URL`); MFA na conta |
| Resend + DNS | Domínio verificado com **SPF, DKIM e DMARC** |
| Getnet | Credenciais sandbox e depois produção; URL de notificação `https://SEU-DOMINIO/api/webhooks/getnet?token=GETNET_WEBHOOK_TOKEN` |
| Melhor Envio | Token e CEP de origem; peso e medidas reais em cada produto (Admin > Produtos) |
| GitHub (quando houver) | Repositório privado, `main` protegido, Dependabot |

## 7. Plano e rotina

1. **Agora:**
   - autorizar a migração no Supabase e a publicação;
   - configurar o Resend;
   - ativar a verificação em duas etapas na conta admin.
2. **Depois:**
   - credenciais Getnet (sandbox → produção) e Melhor Envio;
   - testar um Pix de verdade no sandbox;
   - cartão pelo checkout hospedado da Getnet.
3. **Rotina:**
   - **semanal:** pedidos "Em análise" e tabela `auditoria` (logins que falharam);
   - **mensal:** `npm audit`, atualizações e revisão de acessos;
   - **trimestral:** trocar `SESSION_SECRET` (desconecta todos), `GETNET_WEBHOOK_TOKEN` e `CRON_SECRET`, e testar a restauração do backup;
   - **incidente:** trocar os segredos, preservar a `auditoria` e avisar os clientes e a ANPD quando a LGPD exigir.
