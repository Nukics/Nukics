# Dred Stil — Loja

Loja em Node.js com dados no Supabase (Postgres + Storage), publicada na Vercel.

## 1. Banco de dados (Supabase) — uma vez só

1. Crie um projeto em https://supabase.com.
2. **Projeto novo:** abra o arquivo `supabase/instalar-loja-nova.sql` do ZIP, copie seu conteúdo inteiro para uma consulta no **SQL Editor** do Supabase e clique em **Run** uma única vez, com o papel administrador padrão. Esse arquivo já reúne a estrutura, as migrações 002 a 006, as permissões de acesso do servidor e os dados iniciais em uma transação. Ele não cria admin nem quantidades de estoque por cor. O instalador recusa tabelas de uma loja já existente para preservar seus dados.
3. Em **Project Settings > API / API Keys**, localize a *Project URL* e uma chave secreta de servidor (`sb_secret_...` ou a chave JWT legada `service_role`). A chave pública `publishable`/`anon` não dá acesso às operações administrativas da loja.

**Loja existente:** não execute `instalar-loja-nova.sql` nem carregue os dados iniciais novamente. Faça uma cópia do banco e aplique somente as migrações pendentes em ordem: `002-contas-pagamentos-seguranca.sql`, `003-cadastro-estoque-notas.sql`, `004-getnet-global.sql`, `005-estoque-por-cor.sql` e `006-categorias-mover.sql`, da pasta `supabase/migracoes/`. Os arquivos `*-reverter.sql` são reversões e não fazem parte da instalação.

O arquivo de instalação nova já vem pronto no ZIP. Para regenerá-lo após mudar as fontes SQL, execute `npm run sql:instalar`; esse comando apenas escreve o arquivo local, sem se conectar a banco algum. Depois da instalação, revise no admin os contatos, produtos, banners, textos e quantidades reais da sua loja antes de vender.

## 2. Rodar localmente

No Windows:

1. Instale o **Node.js 24 LTS** pelo site https://nodejs.org (o projeto exige Node.js 22 ou superior).
2. Extraia o ZIP inteiro. Abra a pasta extraída que contém `package.json`; se houver outra pasta dentro, entre nela primeiro.
3. Abra o terminal nessa pasta. Pode usar o **Prompt de Comando** do Windows. Execute, nesta ordem:

```bash
npm ci
npm run configurar
npm run verificar
npm start
```

O comando `configurar` pergunta a URL do seu Supabase e a chave secreta de servidor no próprio terminal; a chave fica oculta enquanto você digita ou cola. Esses valores vêm do painel do seu projeto, em **Project Settings > API / API Keys**. Use uma chave secreta `sb_secret_...` ou JWT `service_role`; a chave `publishable`/`anon` não serve. Não envie a chave pelo chat.

O assistente gera um `SESSION_SECRET` aleatório e cria `.env.local` com os valores informados. Ele não sobrescreve um `.env.local` existente. O arquivo `.env.example` é só um modelo; não contém as credenciais da sua loja. O `.env.local` real fica somente na sua instalação e não é incluído no ZIP nem no Git.

O comando `verificar` confere a configuração e o esquema do banco sem alterar os dados. Se indicar migrações pendentes, aplique no SQL Editor os arquivos que faltam conforme a seção 1 e execute o diagnóstico novamente. Corrija as pendências antes de iniciar a loja. Com `npm start` em execução, abra http://localhost:5173 e mantenha o terminal aberto. **Atenção:** com o `.env.local` apontando para o Supabase de produção, o site local usa o banco de verdade.

A configuração inicial deixa o pagamento online desligado e mantém a compra pelo WhatsApp. Pagamentos reais por cartão, parcelas e Pix dependem das credenciais próprias Getnet, da configuração de frete e da homologação descrita em [docs/GETNET.md](docs/GETNET.md).

Se quiser abrir primeiro uma demonstração sem configurar Supabase, depois de `npm ci` execute o comando abaixo em vez de `configurar`, `verificar` e `start`. Ela usa banco descartável em memória, Pix e frete simulados e e-mails em `.dev-emails/`:

```bash
npm run demo
```

Abra http://localhost:5174. O acesso do admin de demonstração fica em `.dev-emails/admin-demo.txt`; os códigos de acesso e links de confirmação são gravados na mesma pasta. Os dados da demonstração desaparecem ao reiniciar e não substituem a configuração da loja real. Instale também as dependências de desenvolvimento para executar a demonstração e os testes (`npm ci`, sem `--omit=dev`).

Testes automáticos (também rodam num banco descartável):

```bash
npm test
```

## 3. Conta admin

```bash
npm run criar-admin -- email@seudominio.com.br "Nome Completo" apelido 41999999999 "SUA-SENHA-FORTE"
```

Os cinco argumentos são obrigatórios: e-mail, nome completo, apelido, telefone com DDD e senha. Use uma senha própria com pelo menos oito caracteres, que não seja comum. O script usa as variáveis de `.env.local` ou do ambiente e cria uma conta nova; não promove uma conta de cliente existente.

A loja tem **um único admin** (o banco recusa um segundo). Se esse e-mail ou apelido já estiver cadastrado como cliente, use dados disponíveis para criar o admin ou solicite uma transferência de acesso específica; o painel de clientes não altera permissões.

Depois, entre em `/conta` com o e-mail ou apelido e a senha criada. Quando a verificação em duas etapas for exigida, confirme seu e-mail pelo botão da conta, abra o link recebido e ative a verificação em duas etapas antes de acessar `/admin`. Em desenvolvimento, sem Resend, as mensagens ficam em `.dev-emails/`; em produção configure o envio real antes de depender desses recursos.

No painel admin (`/admin`) dá para:
- **Vendas:** faturamento de hoje, 7 dias, mês e total, ticket médio e gráfico dos últimos 30 dias, com botão para esconder os valores.
- **Pedidos:** pedidos pagos por Pix mudam para Pago sozinhos; os combinados pelo WhatsApp o admin atualiza. Mostra endereço de entrega e campo de código de rastreio. "Em análise" = pagamento com valor diferente ou pago depois do Pix expirar.
- **Produtos** (com envio de fotos) e **Categorias** (com subcategorias e opção de aparecer no menu).
- **Destaques:** abas da página inicial e os produtos de cada uma.
- **Menu:** itens do menu do site (Catálogo com as categorias, categorias, páginas, links), ordem e visibilidade.
- **Clientes:** número de compras, selo "Bom cliente" a partir de 5 compras e botão que envia ao cliente um link de nova senha por e-mail (o admin nunca vê a senha).
- **Páginas:** textos de Quem somos, Trocas e devoluções, Onde estamos, Segurança, Privacidade e Termos.
- **Perguntas frequentes** e **Configurações** (WhatsApp, parcelas, faixa promocional, redes sociais e banners).

## 4. Publicar na Vercel

Cadastre as variáveis em **Vercel > Project > Settings > Environment Variables** (ou `vercel env add NOME production`) e selecione Node.js 22 ou superior. O núcleo da loja exige `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` e `SESSION_SECRET`. Defina `APP_URL` com o domínio HTTPS público para os links da conta e callbacks das integrações.

Para o funcionamento completo em produção, configure também:

- E-mail: `RESEND_API_KEY` e `EMAIL_FROM` com domínio verificado, para confirmação de cadastro, recuperação de senha e códigos de acesso do admin.
- Pagamento e frete: credenciais do provedor escolhido e do Melhor Envio, conforme `.env.example`. Para cartão, parcelas e Pix incorporados, siga [o guia Getnet](docs/GETNET.md), começando em homologação. Sem pagamento e frete configurados, o checkout online fica desligado e a compra segue pelo WhatsApp.
- Tarefa agendada: `CRON_SECRET`, para a conciliação e expiração de pedidos.

As variáveis locais de `.env.local` não são enviadas automaticamente à Vercel. Confira o banco, o WhatsApp, os produtos, os saldos reais por cor e as integrações antes de publicar com `vercel --prod`. Pagamento e frete simulados ficam indisponíveis em produção.

Na Vercel, os arquivos de `public/` são entregues direto pela CDN e todo o resto
(páginas e `/api`) passa pela função `api/index.js`.

## Estrutura

```
api/index.js       função da Vercel (usa server/)
server/            servidor
  index.js         cabeçalhos de segurança, arquivos estáticos (local) e roteamento
  paginas.js       rotas das páginas (HTML)
  render.js        layout único (cabeçalho, rodapé, barra mobile) + views
  api/             API JSON: loja.js (público, curtidas e pedidos), conta.js
  api/admin/       rotas do admin por assunto (vendas, produtos, categorias, clientes, conteúdo)
  db.js            acesso aos dados no Supabase
  auth.js          senhas (scrypt) e sessão em cookie assinado
  validar.js       validação de tudo que chega do navegador
  vitrine.js       regras de exibição: menu, categorias, páginas de texto, selo de bom cliente
  texto.js         formatação segura dos textos das páginas editados no admin
views/             HTML das páginas (layout.html envolve todas)
public/            CSS, JS do navegador, fontes e imagens
  js/main.js       entrada; carrega js/paginas/<página>.js
  js/admin/        seções do painel admin
supabase/          SQL da estrutura e dos dados iniciais
scripts/           utilitários de linha de comando
```

## Pagamento e frete

- **Checkout com Pix (Getnet)** e **frete por produto (Melhor Envio)** ligam sozinhos quando as variáveis de `.env.example` estão preenchidas. Enquanto não estiverem, a compra continua pelo WhatsApp.
- Preço e frete são sempre calculados no servidor. Cada tentativa de checkout tem chave de idempotência (clique duplo não cria dois pedidos).
- A notificação da Getnet (`/api/webhooks/getnet?token=...`) só serve de aviso: o status é consultado na própria Getnet.
- Pix não pago expira em 30 minutos (tarefa diária em `vercel.json`; no plano Pro dá para rodar a cada 15 minutos).
- Peso e medidas da embalagem ficam no cadastro de cada produto (Admin > Produtos) e entram no cálculo do frete.

## Segurança

Veja [SEGURANCA.md](SEGURANCA.md). Resumo:
- Senhas com scrypt (senhas comuns recusadas); sessão em cookie `HttpOnly`, `SameSite=Lax` e `Secure` em produção.
- Esqueci a senha por e-mail (link de uso único, 30 min, derruba todas as sessões) e confirmação de e-mail.
- Verificação em duas etapas por e-mail (código de 6 dígitos, máximo 5 tentativas), obrigatória para o admin quando o e-mail estiver configurado.
- Limites de tentativas no banco (valem para todas as instâncias da Vercel), por IP e por conta.
- A chave `service_role` só existe no servidor. Tabelas com RLS ligado e sem políticas; funções do banco sem permissão para as chaves públicas.
- Mutações só em JSON e com checagem de origem (CSRF); HSTS e CSP.

## Global API Getnet: cartão, parcelamento e Pix no site

O provedor adicional `getnet-global` usa o Web Checkout oficial incorporado por iframe, com OAuth no servidor e webhook autenticado. O Pix legado e o WhatsApp foram preservados. Veja [configuração, fontes oficiais e homologação](docs/GETNET.md). É necessário aplicar a migração `004-getnet-global.sql` e obter as credenciais/habilitações próprias antes de usar pagamentos reais.

## Banners, identidade visual e Atacado

O admin permite ajustar posição e zoom dos banners separadamente para desktop e celular. A página `/atacado` apresenta tabela, simulador e produtos elegíveis, com o mesmo desconto aplicado pelo servidor. Consulte [as mudanças do site e como configurar](docs/ALTERACOES-SITE.md).


## Destaques, estoque por cor e categorias

Os Destaques rolam na horizontal em celular e computador. Em **Admin > Estoque**, um tipo de peça reúne saldos por cor e vários produtos podem compartilhar cada saldo. Em **Categorias**, o seletor **Dentro de** move categorias existentes preservando produtos e endereço. Para atualizar uma loja existente, consulte [o guia das migrações 005 e 006](docs/ESTOQUE-CORES-CATEGORIAS.md).
