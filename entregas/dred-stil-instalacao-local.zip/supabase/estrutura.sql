-- Dred Stil: estrutura do banco no Supabase.
-- Rodar uma vez no SQL Editor do projeto (depois, rodar dados-iniciais.sql).

-- Categorias do catálogo (com um nível de subcategoria: pai aponta para a categoria principal).
create table if not exists categorias (
  slug       text primary key,
  nome       text not null,
  pai        text references categorias (slug) on update cascade on delete restrict,
  ordem      integer not null default 0,
  no_menu    boolean not null default true,
  criado_em  timestamptz not null default now()
);

create table if not exists produtos (
  handle     text primary key,
  nome       text not null,
  categoria  text not null references categorias (slug) on update cascade on delete restrict,
  preco      numeric(10, 2) not null default 0,
  preco_de   numeric(10, 2) not null default 0,
  descricao  text not null default '',
  tamanhos   jsonb not null default '[]',
  cores      jsonb not null default '[]',
  ativo      boolean not null default true,
  criado_em  timestamptz not null default now()
);

create table if not exists usuarios (
  id             uuid primary key default gen_random_uuid(),
  nome           text not null,
  email          text not null unique,
  senha          text not null,
  telefone       text not null default '',
  papel          text not null default 'cliente' check (papel in ('cliente', 'admin')),
  versao_sessao  integer not null default 1,
  criado_em      timestamptz not null default now()
);

-- A loja tem um único admin: o banco recusa um segundo.
create unique index if not exists usuarios_admin_unico on usuarios ((papel)) where papel = 'admin';

-- Excluir o produto ou a conta apaga as curtidas; trocar o handle do produto atualiza as curtidas.
create table if not exists curtidas (
  usuario_id  uuid not null references usuarios (id) on delete cascade,
  handle      text not null references produtos (handle) on delete cascade on update cascade,
  criado_em   timestamptz not null default now(),
  primary key (usuario_id, handle)
);
create index if not exists curtidas_handle_idx on curtidas (handle);

-- Pedidos feitos no site. Os itens guardam nome e preço do momento da compra.
-- Contam como venda os pedidos pagos, enviados ou entregues.
create table if not exists pedidos (
  id             uuid primary key default gen_random_uuid(),
  numero         bigint generated always as identity unique,
  usuario_id     uuid references usuarios (id) on delete set null,
  itens          jsonb not null,
  total          numeric(10, 2) not null default 0,
  status         text not null default 'aguardando'
                 check (status in ('aguardando', 'pago', 'enviado', 'entregue', 'cancelado')),
  criado_em      timestamptz not null default now(),
  atualizado_em  timestamptz not null default now()
);
create index if not exists pedidos_usuario_idx on pedidos (usuario_id);
create index if not exists pedidos_criado_idx on pedidos (criado_em desc);

-- Conteúdo editável pelo admin: 'faq', 'config', 'menu', 'destaques' e 'paginas'.
create table if not exists conteudo (
  chave  text primary key,
  valor  jsonb not null
);

create or replace view curtidas_por_produto with (security_invoker = true) as
  select handle, count(*)::int as total from curtidas group by handle;

create or replace view compras_por_usuario with (security_invoker = true) as
  select usuario_id, count(*)::int as compras
  from pedidos
  where usuario_id is not null and status in ('pago', 'enviado', 'entregue')
  group by usuario_id;

-- Faturamento no fuso de Brasília: hoje, últimos 7 dias, mês atual e total.
create or replace view vendas_resumo with (security_invoker = true) as
  with vendas as (
    select total, (criado_em at time zone 'America/Sao_Paulo') as quando
    from pedidos where status in ('pago', 'enviado', 'entregue')
  ), agora as (select (now() at time zone 'America/Sao_Paulo') as t)
  select
    count(*) filter (where quando::date = (select t::date from agora))::int as vendas_hoje,
    coalesce(sum(total) filter (where quando::date = (select t::date from agora)), 0) as faturamento_hoje,
    count(*) filter (where quando >= (select t from agora) - interval '7 days')::int as vendas_7_dias,
    coalesce(sum(total) filter (where quando >= (select t from agora) - interval '7 days'), 0) as faturamento_7_dias,
    count(*) filter (where date_trunc('month', quando) = date_trunc('month', (select t from agora)))::int as vendas_mes,
    coalesce(sum(total) filter (where date_trunc('month', quando) = date_trunc('month', (select t from agora))), 0) as faturamento_mes,
    count(*)::int as vendas_total,
    coalesce(sum(total), 0) as faturamento_total,
    (select count(*)::int from pedidos where status = 'aguardando') as pedidos_aguardando
  from vendas;

-- Faturamento por dia nos últimos 30 dias (dias sem venda aparecem com zero).
create or replace view vendas_por_dia with (security_invoker = true) as
  with dias as (
    select generate_series(
      (now() at time zone 'America/Sao_Paulo')::date - 29,
      (now() at time zone 'America/Sao_Paulo')::date,
      interval '1 day'
    )::date as dia
  )
  select d.dia, count(p.id)::int as vendas, coalesce(sum(p.total), 0) as faturamento
  from dias d
  left join pedidos p
    on (p.criado_em at time zone 'America/Sao_Paulo')::date = d.dia
   and p.status in ('pago', 'enviado', 'entregue')
  group by d.dia
  order by d.dia;

-- RLS ligado e sem políticas: só o servidor da loja (chave service_role) lê e grava.
alter table categorias enable row level security;
alter table produtos enable row level security;
alter table usuarios enable row level security;
alter table curtidas enable row level security;
alter table pedidos enable row level security;
alter table conteudo enable row level security;

-- Permissões explícitas: instalações novas não dependem dos grants padrão do
-- projeto Supabase. O servidor usa service_role, que no Supabase ignora RLS.
-- As chaves públicas continuam sem acesso, inclusive às views com security_invoker.
grant usage on schema public to service_role;
revoke all on table categorias, produtos, usuarios, curtidas, pedidos, conteudo,
  curtidas_por_produto, compras_por_usuario, vendas_resumo, vendas_por_dia from public, anon, authenticated;
grant select, insert, update, delete on table categorias, produtos, usuarios, curtidas, pedidos, conteudo to service_role;
grant select on table curtidas_por_produto, compras_por_usuario, vendas_resumo, vendas_por_dia to service_role;
revoke all on sequence pedidos_numero_seq from public, anon, authenticated;
grant usage, select on sequence pedidos_numero_seq to service_role;

-- Fotos enviadas pelo painel admin (leitura pública, envio só pelo servidor).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('produtos', 'produtos', true, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do nothing;
