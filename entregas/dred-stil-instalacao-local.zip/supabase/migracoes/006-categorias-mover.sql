-- Categorias existentes podem mudar de pai sem alterar slug, produtos ou menu.
-- Rodar após as migrações anteriores. A loja mantém somente um nível de subcategoria.
-- A trava antes do comando serializa alterações concorrentes da árvore.
create or replace function public.travar_arvore_categorias()
returns trigger language plpgsql set search_path = public as $$
begin
  perform pg_advisory_xact_lock(783420761);
  return null;
end;
$$;

create or replace function public.validar_arvore_categorias()
returns trigger language plpgsql set search_path = public as $$
declare v_pai text;
begin
  if new.pai is null then return new; end if;
  if new.pai = new.slug then
    raise exception 'Uma categoria não pode ficar dentro dela mesma.' using errcode = '23514';
  end if;
  select pai into v_pai from public.categorias where slug = new.pai;
  if not found then
    raise exception 'Categoria principal não encontrada.' using errcode = '23503';
  end if;
  if v_pai is not null then
    raise exception 'Subcategorias só podem ficar dentro de uma categoria principal.' using errcode = '23514';
  end if;
  if exists (select 1 from public.categorias where pai = new.slug) then
    raise exception 'Esta categoria tem subcategorias. Mova as subcategorias primeiro.' using errcode = '23514';
  end if;
  return new;
end;
$$;

drop trigger if exists categorias_travar_arvore on public.categorias;
create trigger categorias_travar_arvore before insert or update of pai on public.categorias
for each statement execute function public.travar_arvore_categorias();
drop trigger if exists categorias_validar_arvore on public.categorias;
create trigger categorias_validar_arvore before insert or update of pai on public.categorias
for each row execute function public.validar_arvore_categorias();
