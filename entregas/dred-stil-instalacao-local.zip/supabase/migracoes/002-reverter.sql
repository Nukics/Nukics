-- Reverte a migração 002. ATENÇÃO: apaga tokens, códigos, limites, auditoria e eventos de pagamento,
-- e os dados de checkout dos pedidos (frete, endereço, Pix). Faça backup antes.
-- Pedidos com situação 'expirado' ou 'revisar' voltam para 'cancelado'.
begin;
drop function if exists processar_pagamento(text, text, text, numeric);
drop function if exists criar_pedido_checkout(uuid, text, jsonb, numeric, numeric, text, text, integer, jsonb, jsonb, text, integer);
drop function if exists tentar_desafio_2fa(text);
drop function if exists consumir_token_conta(text, text);
drop function if exists consumir_limite(text, integer, integer);
drop table if exists pagamento_eventos, auditoria, limites, desafios_2fa, tokens_conta;
update pedidos set status = 'cancelado' where status in ('expirado', 'revisar');
alter table pedidos drop constraint if exists pedidos_status_check;
alter table pedidos add constraint pedidos_status_check check (status in ('aguardando', 'pago', 'enviado', 'entregue', 'cancelado'));
drop index if exists pedidos_idempotencia_idx, pedidos_pagamento_idx, pedidos_expira_idx;
alter table pedidos drop column if exists chave_idempotencia, drop column if exists subtotal, drop column if exists frete,
  drop column if exists frete_servico, drop column if exists frete_nome, drop column if exists frete_prazo_dias,
  drop column if exists cliente, drop column if exists endereco, drop column if exists pagamento_metodo,
  drop column if exists pagamento_id, drop column if exists pagamento_status, drop column if exists pagamento_dados,
  drop column if exists rastreio, drop column if exists expira_em;
alter table produtos drop column if exists peso_kg, drop column if exists largura_cm, drop column if exists altura_cm,
  drop column if exists comprimento_cm;
alter table usuarios drop column if exists email_verificado_em, drop column if exists dois_fatores;
commit;
