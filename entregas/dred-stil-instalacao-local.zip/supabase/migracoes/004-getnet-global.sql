-- Somente o checkout Global: uma intenção pode conter tentativa recusada e depois aprovada.
-- A recusa de uma tentativa não cancela a intenção nem o pedido.
create or replace function processar_pagamento_global(p_pagamento_id text, p_status text, p_valor numeric)
returns text
language plpgsql set search_path = public as $$
declare p pedidos; v_novo text;
begin
  if p_status not in ('aprovado', 'negado', 'pendente', 'cancelado') then
    raise exception 'status_pagamento_invalido';
  end if;
  select * into p from pedidos where pagamento_id = p_pagamento_id and pagamento_metodo = 'getnet-checkout' for update;
  if not found then return 'ignorado'; end if;
  -- Nunca regredir um pedido já pago, em transporte ou entregue por aviso atrasado.
  if p.status in ('pago', 'enviado', 'entregue', 'revisar') then return 'ignorado'; end if;
  if p.pagamento_status = p_status then return 'ignorado'; end if;
  if p_status = 'aprovado' then
    if p_valor is null or p_valor <> p.total or p.status in ('expirado', 'cancelado') then v_novo := 'revisar';
    elsif p.status = 'aguardando' then v_novo := 'pago';
    end if;
  elsif p_status = 'cancelado' and p.status = 'aguardando' then v_novo := 'cancelado';
  end if;
  insert into pagamento_eventos (provedor, chave_evento, pedido_id, status_obtido)
    values ('getnet-global', p_pagamento_id || ':' || p_status, p.id, p_status)
    on conflict (provedor, chave_evento) do nothing;
  update pedidos set pagamento_status = p_status, status = coalesce(v_novo, status), atualizado_em = now() where id = p.id;
  insert into auditoria (usuario_id, acao, detalhe)
    values (p.usuario_id, 'pagamento_atualizado', jsonb_build_object('pedido', p.numero, 'status', p_status, 'novo', v_novo));
  return 'atualizado';
end $$;

revoke execute on function processar_pagamento_global(text, text, numeric) from public, anon, authenticated;
grant execute on function processar_pagamento_global(text, text, numeric) to service_role;
