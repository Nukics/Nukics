-- Reverte a migração 003. ATENÇÃO: apaga grupos de estoque, movimentos e o registro das notas fiscais
-- (as notas continuam existindo no emissor e na SEFAZ). Faça backup antes.
begin;
drop trigger if exists pedidos_estoque on pedidos;
drop function if exists pedidos_estoque();
drop table if exists notas_fiscais, estoque_movimentos;
alter table produtos drop column if exists estoque_id, drop column if exists codigo_ncm;
drop table if exists estoques;
alter table pedidos drop column if exists estoque_baixado;
drop index if exists usuarios_apelido_unico, usuarios_cpf_unico, usuarios_nome_idx;
alter table usuarios drop constraint if exists usuarios_apelido_formato, drop constraint if exists usuarios_cpf_formato;
alter table usuarios drop column if exists apelido, drop column if exists cpf;
commit;
