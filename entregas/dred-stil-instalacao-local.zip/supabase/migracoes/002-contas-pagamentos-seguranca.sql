-- Dred Stil — migração 002: recuperação de senha, verificação em duas etapas, limites de tentativas
-- compartilhados, checkout com Pix (Getnet) e frete (Melhor Envio).
--
-- Rodar UMA vez no SQL Editor do Supabase, depois de estrutura.sql. É idempotente (pode repetir).
-- Não apaga dados: só cria tabelas/colunas/funções novas e amplia a lista de situações de pedido.
-- Reverter: ver supabase/migracoes/002-reverter.sql.

begin;

/* ---------------- contas ---------------- */
alter table usuarios add column if not exists email_verificado_em timestamptz;
alter table usuarios add column if not exists dois_fatores boolean not null default false;

-- Tokens de uso único (confirmar e-mail, redefinir senha). Só o hash fica guardado.
create table if not exists tokens_conta (
  token_hash  text primary key,
  usuario_id  uuid not null references usuarios (id) on delete cascade,
  tipo        text not null check (tipo in ('verificar_email', 'redefinir_senha')),
  expira_em   timestamptz not null,
  usado_em    timestamptz,
  criado_em   timestamptz not null default now()
);
create index if not exists tokens_conta_usuario_idx on tokens_conta (usuario_id, tipo);

-- Código de 6 dígitos enviado por e-mail no login (guardado como HMAC).
create table if not exists desafios_2fa (
  id_hash      text primary key,
  usuario_id   uuid not null references usuarios (id) on delete cascade,
  codigo_hash  text not null,
  tentativas   integer not null default 0,
  expira_em    timestamptz not null,
  criado_em    timestamptz not null default now()
);

-- Limites de tentativas: no banco para valerem em todas as instâncias da Vercel.
create table if not exists limites (
  chave          text primary key,
  contagem       integer not null,
  janela_inicio  timestamptz not null
);

-- Eventos de segurança (sem senhas, tokens, códigos, CPF ou dados de cartão).
create table if not exists auditoria (
  id          bigint generated always as identity primary key,
  usuario_id  uuid,
  acao        text not null,
  detalhe     jsonb not null default '{}',
  ip          text,
  criado_em   timestamptz not null default now()
);
create index if not exists auditoria_usuario_idx on auditoria (usuario_id, criado_em desc);

/* ---------------- produtos: embalagem para o frete ---------------- */
alter table produtos add column if not exists peso_kg        numeric(6, 3) not null default 0.3;
alter table produtos add column if not exists largura_cm     integer not null default 20;
alter table produtos add column if not exists altura_cm      integer not null default 4;
alter table produtos add column if not exists comprimento_cm integer not null default 28;

/* ---------------- pedidos: checkout e pagamento ---------------- */
alter table pedidos add column if not exists chave_idempotencia text;
alter table pedidos add column if not exists subtotal          numeric(10, 2);
alter table pedidos add column if not exists frete             numeric(10, 2) not null default 0;
alter table pedidos add column if not exists frete_servico     text;
alter table pedidos add column if not exists frete_nome        text;
alter table pedidos add column if not exists frete_prazo_dias  integer;
alter table pedidos add column if not exists cliente           jsonb;  -- nome, CPF e telefone (nota fiscal e envio)
alter table pedidos add column if not exists endereco          jsonb;
alter table pedidos add column if not exists pagamento_metodo  text;
alter table pedidos add column if not exists pagamento_id      text;
alter table pedidos add column if not exists pagamento_status  text;
alter table pedidos add column if not exists pagamento_dados   jsonb;  -- Pix copia-e-cola e validade
alter table pedidos add column if not exists rastreio          text;
alter table pedidos add column if not exists expira_em         timestamptz;

create unique index if not exists pedidos_idempotencia_idx on pedidos (usuario_id, chave_idempotencia) where chave_idempotencia is not null;
create unique index if not exists pedidos_pagamento_idx on pedidos (pagamento_id) where pagamento_id is not null;
create index if not exists pedidos_expira_idx on pedidos (status, expira_em) where expira_em is not null;

-- 'expirado': Pix não pago no prazo. 'revisar': pagamento com valor divergente ou pago depois de expirar.
alter table pedidos drop constraint if exists pedidos_status_check;
alter table pedidos add constraint pedidos_status_check
  check (status in ('aguardando', 'pago', 'enviado', 'entregue', 'cancelado', 'expirado', 'revisar'));

-- Notificações de pagamento já processadas (proteção contra repetição).
create table if not exists pagamento_eventos (
  id            bigint generated always as identity primary key,
  provedor      text not null,
  chave_evento  text not null,
  pedido_id     uuid references pedidos (id) on delete set null,
  status_obtido text,
  recebido_em   timestamptz not null default now(),
  unique (provedor, chave_evento)
);

alter table tokens_conta      enable row level security;
alter table desafios_2fa      enable row level security;
alter table limites           enable row level security;
alter table auditoria         enable row level security;
alter table pagamento_eventos enable row level security;

-- Permissões explícitas: em projetos novos do Supabase, tabelas novas não recebem permissões
-- automáticas (nem para service_role). Só o servidor (service_role) acessa; as chaves públicas não.
revoke all on table tokens_conta, desafios_2fa, limites, auditoria, pagamento_eventos from anon, authenticated;
grant select, insert, update, delete on table tokens_conta, desafios_2fa, limites, auditoria, pagamento_eventos to service_role;
grant usage, select on sequence auditoria_id_seq, pagamento_eventos_id_seq to service_role;

/* ---------------- funções (operações atômicas) ---------------- */

-- Conta uma tentativa na janela fixa. Devolve se ainda está permitido e quantos segundos faltam.
create or replace function consumir_limite(p_chave text, p_max integer, p_janela_s integer)
returns table (permitido boolean, espera_s integer)
language plpgsql set search_path = public as $$
declare v limites;
begin
  insert into limites as l (chave, contagem, janela_inicio) values (p_chave, 1, now())
  on conflict (chave) do update set
    contagem = case when l.janela_inicio < now() - make_interval(secs => p_janela_s) then 1 else l.contagem + 1 end,
    janela_inicio = case when l.janela_inicio < now() - make_interval(secs => p_janela_s) then now() else l.janela_inicio end
  returning * into v;
  return query select v.contagem <= p_max,
    greatest(1, ceil(extract(epoch from (v.janela_inicio + make_interval(secs => p_janela_s) - now()))))::integer;
end $$;

-- Consome um token de uso único; devolve o dono ou nada (inválido, expirado ou já usado).
create or replace function consumir_token_conta(p_hash text, p_tipo text)
returns uuid
language sql set search_path = public as $$
  update tokens_conta set usado_em = now()
   where token_hash = p_hash and tipo = p_tipo and usado_em is null and expira_em > now()
  returning usuario_id;
$$;

-- Registra a tentativa ANTES da comparação (no máximo 5) e devolve o hash para conferir.
create or replace function tentar_desafio_2fa(p_id_hash text)
returns table (usuario_id uuid, codigo_hash text)
language sql set search_path = public as $$
  update desafios_2fa set tentativas = tentativas + 1
   where id_hash = p_id_hash and expira_em > now() and tentativas < 5
  returning usuario_id, codigo_hash;
$$;

-- Cria o pedido do checkout. A mesma chave de idempotência devolve o pedido já criado
-- (clique duplo ou requisições simultâneas). Limita pedidos aguardando Pix por cliente.
create or replace function criar_pedido_checkout(
  p_usuario uuid, p_chave text, p_itens jsonb, p_subtotal numeric, p_frete numeric,
  p_frete_servico text, p_frete_nome text, p_frete_prazo integer,
  p_cliente jsonb, p_endereco jsonb, p_metodo text, p_validade_min integer
) returns setof pedidos
language plpgsql set search_path = public as $$
declare v_abertos integer;
begin
  return query select * from pedidos where usuario_id = p_usuario and chave_idempotencia = p_chave;
  if found then return; end if;

  select count(*) into v_abertos from pedidos
   where usuario_id = p_usuario and status = 'aguardando' and expira_em > now();
  if v_abertos >= 3 then raise exception 'limite_pedidos_abertos' using errcode = 'P0001'; end if;

  begin
    return query insert into pedidos (usuario_id, chave_idempotencia, itens, subtotal, frete, total, frete_servico,
                                      frete_nome, frete_prazo_dias, cliente, endereco, pagamento_metodo, expira_em)
      values (p_usuario, p_chave, p_itens, p_subtotal, p_frete, p_subtotal + p_frete, p_frete_servico,
              p_frete_nome, p_frete_prazo, p_cliente, p_endereco, p_metodo, now() + make_interval(mins => p_validade_min))
      returning *;
  exception when unique_violation then
    return query select * from pedidos where usuario_id = p_usuario and chave_idempotencia = p_chave;
  end;
end $$;

-- Aplica o status consultado no provedor. Nunca regride (de "pago" não volta), ignora repetições
-- e manda para "revisar" valor divergente ou pagamento que chegou depois de o pedido expirar.
create or replace function processar_pagamento(p_provedor text, p_pagamento_id text, p_status text, p_valor numeric)
returns text
language plpgsql set search_path = public as $$
declare p pedidos; v_novo text;
begin
  select * into p from pedidos where pagamento_id = p_pagamento_id for update;
  if not found then return 'ignorado'; end if;

  insert into pagamento_eventos (provedor, chave_evento, pedido_id, status_obtido)
  values (p_provedor, p_pagamento_id || ':' || p_status, p.id, p_status)
  on conflict (provedor, chave_evento) do nothing;
  if not found then return 'ignorado'; end if;

  if p_status = 'aprovado' then
    if p_valor is not null and p_valor <> p.total then v_novo := 'revisar';
    elsif p.status = 'aguardando' then v_novo := 'pago';
    elsif p.status in ('expirado', 'cancelado') then v_novo := 'revisar';
    end if;
  elsif p_status in ('negado', 'cancelado') and p.status = 'aguardando' then
    v_novo := 'cancelado';
  end if;

  update pedidos set pagamento_status = p_status, status = coalesce(v_novo, status), atualizado_em = now() where id = p.id;
  insert into auditoria (usuario_id, acao, detalhe)
  values (p.usuario_id, 'pagamento_atualizado', jsonb_build_object('pedido', p.numero, 'status', p_status, 'novo', v_novo));
  return case when v_novo is null then 'ignorado' else 'atualizado' end;
end $$;

-- As funções só podem ser chamadas pelo servidor (chave service_role), nunca pela API pública.
revoke execute on function consumir_limite(text, integer, integer) from public, anon, authenticated;
revoke execute on function consumir_token_conta(text, text) from public, anon, authenticated;
revoke execute on function tentar_desafio_2fa(text) from public, anon, authenticated;
revoke execute on function criar_pedido_checkout(uuid, text, jsonb, numeric, numeric, text, text, integer, jsonb, jsonb, text, integer) from public, anon, authenticated;
revoke execute on function processar_pagamento(text, text, text, numeric) from public, anon, authenticated;
grant execute on function consumir_limite(text, integer, integer) to service_role;
grant execute on function consumir_token_conta(text, text) to service_role;
grant execute on function tentar_desafio_2fa(text) to service_role;
grant execute on function criar_pedido_checkout(uuid, text, jsonb, numeric, numeric, text, text, integer, jsonb, jsonb, text, integer) to service_role;
grant execute on function processar_pagamento(text, text, text, numeric) to service_role;

commit;
