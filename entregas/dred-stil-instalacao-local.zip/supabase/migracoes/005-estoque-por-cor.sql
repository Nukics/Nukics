-- Dred Stil — 005: saldos por tipo de peça + cor. Aplicar depois da 004.
-- Os grupos antigos permanecem com cor NULL e seu saldo não é duplicado.
begin;

alter table estoques add column if not exists cor text;
alter table estoques add column if not exists arquivado boolean not null default false;
alter table estoques drop constraint if exists estoques_cor_formato;
alter table estoques add constraint estoques_cor_formato check (cor is null or length(btrim(cor)) between 1 and 40);
alter table estoques drop constraint if exists estoques_nome_key;
create unique index if not exists estoques_nome_cor_unicos on estoques
  ((case when cor is null then nome else lower(btrim(nome)) end), lower(btrim(coalesce(cor, '')))) where not arquivado;

-- A mesma cor de um produto só pode consumir um saldo. Cores distintas são independentes.
create table if not exists estoque_produtos_cores (
  handle text not null references produtos(handle) on update cascade on delete cascade,
  cor text not null check (cor = lower(btrim(cor)) and length(cor) between 1 and 40),
  estoque_id uuid not null references estoques(id) on delete restrict,
  primary key (handle, cor)
);
create index if not exists estoque_produtos_cores_estoque_idx on estoque_produtos_cores(estoque_id);
alter table estoque_produtos_cores enable row level security;
revoke all on estoque_produtos_cores from anon, authenticated;
grant select, insert, update, delete on estoque_produtos_cores to service_role;

-- Saldo, vínculos e histórico são alterados numa única transação.
create or replace function salvar_estoque_cor(p_id uuid, p_nome text, p_cor text,
  p_quantidade integer, p_produtos jsonb, p_usuario uuid) returns jsonb
language plpgsql set search_path = public as $$
declare v estoques; v_anterior integer := 0; v_novo boolean := p_id is null;
begin
  if length(btrim(p_nome)) not between 2 and 60 or p_quantidade not between 0 and 100000
     or (p_cor is not null and length(btrim(p_cor)) not between 1 and 40) then
    raise exception 'estoque_invalido' using errcode = '23514';
  end if;
  -- Também protege chamadas diretas da função com a chave do servidor.
  if exists (select 1 from jsonb_array_elements_text(p_produtos) h where not exists (
    select 1 from produtos p where p.handle = h and (p_cor is null or exists (
      select 1 from jsonb_array_elements(p.cores) c where lower(btrim(c->>'nome')) = lower(btrim(p_cor))
    ))
  )) then raise exception 'produto_sem_cor' using errcode = '23514'; end if;
  if v_novo then
    insert into estoques(nome, cor, quantidade) values (btrim(p_nome), nullif(btrim(p_cor), ''), p_quantidade) returning * into v;
  else
    select * into v from estoques where id = p_id and not arquivado for update;
    if not found then return null; end if;
    if lower(btrim(coalesce(v.cor, ''))) <> lower(btrim(coalesce(p_cor, ''))) then
      raise exception 'cor_estoque_imutavel' using errcode = '23514';
    end if;
    v_anterior := v.quantidade;
    update estoques set nome = btrim(p_nome), quantidade = p_quantidade, atualizado_em = now()
      where id = p_id returning * into v;
  end if;
  if v.cor is null then
    update produtos set estoque_id = null where estoque_id = v.id;
    update produtos set estoque_id = v.id where handle in (select jsonb_array_elements_text(p_produtos));
  else
    delete from estoque_produtos_cores where estoque_id = v.id;
    insert into estoque_produtos_cores(handle, cor, estoque_id)
      select h, lower(btrim(v.cor)), v.id from jsonb_array_elements_text(p_produtos) h
      on conflict(handle, cor) do update set estoque_id = excluded.estoque_id;
  end if;
  if v_novo or v_anterior <> p_quantidade then
    insert into estoque_movimentos(estoque_id, delta, quantidade_final, motivo, usuario_id)
    values (v.id, p_quantidade - v_anterior, p_quantidade,
      case when v_novo then 'Estoque criado' when p_quantidade > v_anterior then 'Entrada de peças' else 'Ajuste manual' end, p_usuario);
  end if;
  return to_jsonb(v);
end $$;

-- Arquivar mantém os saldos históricos e a referência dos pedidos já criados.
create or replace function arquivar_estoque(p_id uuid) returns boolean
language plpgsql set search_path = public as $$
begin
  perform 1 from estoques where id = p_id and not arquivado for update;
  if not found then return false; end if;
  update estoques set arquivado = true, atualizado_em = now() where id = p_id;
  delete from estoque_produtos_cores where estoque_id = p_id;
  update produtos set estoque_id = null where estoque_id = p_id;
  return true;
end $$;

-- Usa o vínculo conferido pelo servidor no momento da compra. Trocar o produto de
-- grupo depois não desvia a baixa nem a devolução para outro grupo/cor.
create or replace function pedidos_estoque() returns trigger
language plpgsql set search_path = public as $$
declare r record; v_sinal integer; v_antes integer; v_depois integer; v_delta integer;
begin
  if new.status in ('pago', 'enviado', 'entregue') and not old.estoque_baixado then
    v_sinal := -1; new.estoque_baixado := true;
  elsif new.status = 'cancelado' and old.estoque_baixado then
    v_sinal := 1; new.estoque_baixado := false;
  else return new;
  end if;
  if v_sinal = -1 then
    for r in
      select e.id as estoque_id, sum((i->>'qtd')::integer)::integer as qtd
      from jsonb_array_elements(new.itens) i
      left join produtos p on p.handle = i->>'handle'
      left join estoque_produtos_cores pc on pc.handle = p.handle and pc.cor = lower(btrim(i->>'cor'))
      join estoques e on e.id = case when i ? 'estoqueId'
        then nullif(i->>'estoqueId', '')::uuid else coalesce(pc.estoque_id, p.estoque_id) end
      group by e.id order by e.id
    loop
      select quantidade into v_antes from estoques where id = r.estoque_id for update;
      v_depois := greatest(0, v_antes - r.qtd);
      v_delta := v_depois - v_antes;
      update estoques set quantidade = v_depois, atualizado_em = now() where id = r.estoque_id;
      insert into estoque_movimentos(estoque_id, delta, quantidade_final, motivo, pedido_id)
      values (r.estoque_id, v_delta, v_depois, 'Venda #' || new.numero ||
        case when r.qtd > v_antes then ' (faltam ' || (r.qtd - v_antes) || ' peças; conferir reposição)' else '' end, new.id);
    end loop;
  else
    -- Os novos movimentos guardam a baixa efetiva. Movimentos anteriores à 005
    -- mantêm os valores já registrados pelo sistema antigo (sem reescrever o histórico).
    for r in select estoque_id, -sum(delta)::integer as qtd from estoque_movimentos
      where pedido_id = new.id group by estoque_id having sum(delta) < 0 order by estoque_id
    loop
      update estoques set quantidade = quantidade + r.qtd, atualizado_em = now()
        where id = r.estoque_id returning quantidade into v_depois;
      insert into estoque_movimentos(estoque_id, delta, quantidade_final, motivo, pedido_id)
      values (r.estoque_id, r.qtd, v_depois, 'Cancelamento #' || new.numero, new.id);
    end loop;
  end if;
  return new;
end $$;

revoke execute on function salvar_estoque_cor(uuid,text,text,integer,jsonb,uuid), arquivar_estoque(uuid) from public, anon, authenticated;
grant execute on function salvar_estoque_cor(uuid,text,text,integer,jsonb,uuid), arquivar_estoque(uuid) to service_role;
revoke execute on function pedidos_estoque() from public, anon, authenticated;
commit;
