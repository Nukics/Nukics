-- Dred Stil — migração 003: cadastro completo (nome, apelido, telefone, CPF), estoque por grupo
-- e notas fiscais. Rodar UMA vez no SQL Editor do Supabase, depois da 002. Idempotente.
-- Não apaga dados. Reverter: supabase/migracoes/003-reverter.sql.

begin;

/* ---------------- contas: apelido (nick) e CPF ---------------- */
alter table usuarios add column if not exists apelido text;
alter table usuarios add column if not exists cpf text;
alter table usuarios drop constraint if exists usuarios_apelido_formato;
alter table usuarios add constraint usuarios_apelido_formato check (apelido is null or apelido ~ '^[a-z0-9_.]{3,30}$');
alter table usuarios drop constraint if exists usuarios_cpf_formato;
alter table usuarios add constraint usuarios_cpf_formato check (cpf is null or cpf ~ '^[0-9]{11}$');
-- Apelido e CPF não se repetem entre contas (CPF é opcional).
create unique index if not exists usuarios_apelido_unico on usuarios (apelido) where apelido is not null;
create unique index if not exists usuarios_cpf_unico on usuarios (cpf) where cpf is not null;
-- Recuperação de senha pelo nome completo (busca sem diferenciar maiúsculas).
create index if not exists usuarios_nome_idx on usuarios (lower(nome));

/* ---------------- estoque por grupo ---------------- */
-- Um grupo (ex.: "Camisas", 30 peças) com vários produtos. Cada venda desce o total do grupo.
create table if not exists estoques (
  id             uuid primary key default gen_random_uuid(),
  nome           text not null unique check (length(nome) between 2 and 60),
  quantidade     integer not null default 0 check (quantidade >= 0),
  criado_em      timestamptz not null default now(),
  atualizado_em  timestamptz not null default now()
);
alter table produtos add column if not exists estoque_id uuid references estoques (id) on delete set null;
-- NCM do produto para a nota fiscal (61091000 = camiseta de malha de algodão; confirmar com o contador).
alter table produtos add column if not exists codigo_ncm text not null default '61091000';
alter table produtos drop constraint if exists produtos_codigo_ncm_formato;
alter table produtos add constraint produtos_codigo_ncm_formato check (codigo_ncm ~ '^[0-9]{8}$');

create table if not exists estoque_movimentos (
  id                bigint generated always as identity primary key,
  estoque_id        uuid not null references estoques (id) on delete cascade,
  delta             integer not null,
  quantidade_final  integer not null,
  motivo            text not null,
  pedido_id         uuid references pedidos (id) on delete set null,
  usuario_id        uuid,
  criado_em         timestamptz not null default now()
);
create index if not exists estoque_movimentos_idx on estoque_movimentos (estoque_id, criado_em desc);

alter table pedidos add column if not exists estoque_baixado boolean not null default false;

-- Baixa o estoque quando o pedido vira venda (Pago/Enviado/Entregue) e devolve se uma venda for cancelada.
-- Fica no banco para valer em todos os caminhos: Pix automático e mudança manual pelo admin.
create or replace function pedidos_estoque() returns trigger
language plpgsql set search_path = public as $$
declare r record; v_sinal integer;
begin
  if new.status in ('pago', 'enviado', 'entregue') and not old.estoque_baixado then
    v_sinal := -1; new.estoque_baixado := true;
  elsif new.status = 'cancelado' and old.estoque_baixado then
    v_sinal := 1; new.estoque_baixado := false;
  else
    return new;
  end if;
  for r in
    select p.estoque_id, sum((i ->> 'qtd')::integer) as qtd
      from jsonb_array_elements(new.itens) i
      join produtos p on p.handle = i ->> 'handle'
     where p.estoque_id is not null
     group by p.estoque_id
  loop
    update estoques set quantidade = greatest(0, quantidade + v_sinal * r.qtd), atualizado_em = now() where id = r.estoque_id;
    insert into estoque_movimentos (estoque_id, delta, quantidade_final, motivo, pedido_id)
    select r.estoque_id, v_sinal * r.qtd, e.quantidade,
           case when v_sinal < 0 then 'Venda #' else 'Cancelamento #' end || new.numero, new.id
      from estoques e where e.id = r.estoque_id;
  end loop;
  return new;
end $$;

drop trigger if exists pedidos_estoque on pedidos;
create trigger pedidos_estoque before update of status on pedidos
  for each row when (old.status is distinct from new.status) execute function pedidos_estoque();

/* ---------------- notas fiscais ---------------- */
create table if not exists notas_fiscais (
  id                uuid primary key default gen_random_uuid(),
  pedido_id         uuid not null references pedidos (id) on delete restrict,
  usuario_id        uuid references usuarios (id) on delete set null,
  ref               text not null unique,  -- referência enviada ao emissor
  provedor          text not null,
  status            text not null check (status in ('processando', 'autorizada', 'erro', 'cancelada')),
  numero            text,
  serie             text,
  chave             text,
  url_danfe         text,
  url_xml           text,
  mensagem          text,
  email_enviado_em  timestamptz,
  criado_em         timestamptz not null default now(),
  atualizado_em     timestamptz not null default now()
);
-- No máximo uma nota em andamento ou autorizada por pedido (evita nota duplicada).
create unique index if not exists notas_ativas_por_pedido on notas_fiscais (pedido_id) where status in ('processando', 'autorizada');
create index if not exists notas_usuario_idx on notas_fiscais (usuario_id, criado_em desc);

/* ---------------- RLS e permissões (só o servidor acessa) ---------------- */
alter table estoques           enable row level security;
alter table estoque_movimentos enable row level security;
alter table notas_fiscais      enable row level security;
revoke all on table estoques, estoque_movimentos, notas_fiscais from anon, authenticated;
grant select, insert, update, delete on table estoques, estoque_movimentos, notas_fiscais to service_role;
grant usage, select on sequence estoque_movimentos_id_seq to service_role;
revoke execute on function pedidos_estoque() from public, anon, authenticated;

commit;
