// Senhas (scrypt) e sessão em cookie assinado (HMAC).
const crypto = require('crypto');
const { usuarios } = require('./db');
const { lerCookies } = require('./http');
const { exigir2faAdmin } = require('./ambiente');

const COOKIE = 'dred_sessao';
const DURACAO_CLIENTE_S = 60 * 60 * 24 * 30; // 30 dias
const DURACAO_ADMIN_S = 60 * 60 * 12; // 12 horas
const EM_PRODUCAO = process.env.NODE_ENV === 'production';
const SEGREDO = process.env.SESSION_SECRET || segredoTemporario();

// Só para desenvolvimento: sem SESSION_SECRET, as sessões valem até reiniciar o servidor.
function segredoTemporario() {
  if (EM_PRODUCAO) throw new Error('Defina SESSION_SECRET (veja o README).');
  console.warn('SESSION_SECRET não definido: usando um segredo temporário.');
  return crypto.randomBytes(32).toString('hex');
}

function hashSenha(senha) {
  const sal = crypto.randomBytes(16);
  return `scrypt$${sal.toString('hex')}$${crypto.scryptSync(senha, sal, 64).toString('hex')}`;
}

function conferirSenha(senha, armazenado) {
  const [, sal, hash] = String(armazenado).split('$');
  if (!sal || !hash) return false;
  const calculado = crypto.scryptSync(senha, Buffer.from(sal, 'hex'), 64);
  return crypto.timingSafeEqual(calculado, Buffer.from(hash, 'hex'));
}

function assinar(dados) {
  return crypto.createHmac('sha256', SEGREDO).update(dados).digest('base64url');
}

function cookie(valor, maxAge) {
  const seguro = EM_PRODUCAO ? '; Secure' : '';
  return `${COOKIE}=${valor}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${seguro}`;
}

// A sessão do admin dura menos que a dos clientes. "m" marca que o login passou
// pelo código de verificação em duas etapas (exigido para o admin).
function iniciarSessao(res, usuario, { mfa = false } = {}) {
  const duracao = usuario.papel === 'admin' ? DURACAO_ADMIN_S : DURACAO_CLIENTE_S;
  const dados = Buffer.from(
    JSON.stringify({ id: usuario.id, v: usuario.versaoSessao, m: mfa === true, exp: Date.now() + duracao * 1000 })
  ).toString('base64url');
  res.setHeader('Set-Cookie', cookie(`${dados}.${assinar(dados)}`, duracao));
}

function encerrarSessao(res) {
  res.setHeader('Set-Cookie', cookie('', 0));
}

// Devolve o usuário logado ou null. A versão da sessão invalida cookies
// antigos quando a senha é trocada.
async function usuarioDaSessao(req) {
  const [dados, assinatura] = (lerCookies(req)[COOKIE] || '').split('.');
  if (!dados || !assinatura) return null;
  const esperado = Buffer.from(assinar(dados));
  const recebido = Buffer.from(assinatura);
  if (esperado.length !== recebido.length || !crypto.timingSafeEqual(esperado, recebido)) return null;
  let sessao;
  try {
    sessao = JSON.parse(Buffer.from(dados, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (!(sessao.exp > Date.now())) return null;
  const usuario = await usuarios.porId(sessao.id);
  if (!usuario || usuario.versaoSessao !== sessao.v) return null;
  return { ...usuario, sessaoMfa: sessao.m === true };
}

// Admin: exige verificação em duas etapas ligada e usada neste login (quando o e-mail está configurado).
const adminVerificado = (u) => u?.papel === 'admin' && (!exigir2faAdmin() || (u.doisFatores && u.sessaoMfa));

// Formato seguro para mandar ao navegador (sem hash de senha).
function usuarioPublico(u) {
  return u && {
    id: u.id,
    nome: u.nome,
    apelido: u.apelido,
    email: u.email,
    telefone: u.telefone,
    cpf: u.cpf,
    // contas antigas sem apelido, telefone ou sobrenome são convidadas a completar o cadastro
    cadastroIncompleto: !u.apelido || String(u.telefone || '').replace(/\D/g, '').length < 10 || String(u.nome).trim().split(/\s+/).length < 2,
    papel: u.papel,
    curtidas: u.curtidas,
    criadoEm: u.criadoEm,
    emailVerificado: Boolean(u.emailVerificadoEm),
    doisFatores: u.doisFatores,
    adminPendente2fa: u.papel === 'admin' && !adminVerificado(u),
  };
}

module.exports = { hashSenha, conferirSenha, iniciarSessao, encerrarSessao, usuarioDaSessao, usuarioPublico, adminVerificado };
