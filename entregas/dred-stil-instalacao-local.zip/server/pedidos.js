// Regras de pedido compartilhadas: conferência do carrinho, checkout com Pix,
// confirmação de pagamento e expiração. Preço e frete SEMPRE vêm do servidor.
const db = require('./db');
const frete = require('./frete');
const { provedor } = require('./pagamento');
const { ErroHttp } = require('./http');
const publico = require('./publico');

const VALIDADE_PIX_MIN = 30;
const centavos = (reais) => Math.round(reais * 100);
const somar = (valores) => Math.round(valores.reduce((t, v) => t + v, 0) * 100) / 100;

function percentualAtacado(quantidade) {
  if (quantidade >= 13) return 30;
  return ({ 2: 6, 3: 7, 4: 8, 5: 9, 6: 10, 7: 11, 8: 12, 9: 11, 10: 12, 11: 12, 12: 12 })[quantidade] || 0;
}

function aplicarDescontoAtacado(conferidos) {
  const ehAtacado = (i) => i.produto.atacado || i.produto.categoria === 'atacado';
  const quantidade = conferidos.filter(ehAtacado).reduce((t, i) => t + i.qtd, 0);
  const percentual = percentualAtacado(quantidade);
  if (!percentual) return conferidos;
  return conferidos.map((i) => ehAtacado(i)
    ? { ...i, preco: Math.round(i.preco * (1 - percentual / 100) * 100) / 100, descontoAtacado: percentual }
    : i);
}

// Itens do carrinho -> itens com nome e preço do banco (rejeita produto/opção que não existe mais
// e quantidade maior que as peças que restam no grupo de estoque).
async function conferirItens(itens) {
  const [produtos, estoque, categorias] = await Promise.all([
    db.produtos.buscarVarios([...new Set(itens.map((i) => i.handle))]),
    db.estoques.disponibilidade(),
    db.categorias.listar(),
  ]);
  const categoriasAtacado = new Set(['atacado', ...categorias.filter((c) => c.pai === 'atacado').map((c) => c.slug)]);
  const conferidos = itens.map((item) => {
    const produto = produtos.find((p) => p.handle === item.handle && p.ativo);
    const corValida = produto?.cores.some((c) => c.nome === item.cor);
    if (!produto || !corValida || !produto.tamanhos.includes(item.tamanho)) {
      throw new ErroHttp(409, `"${produto?.nome || 'Um produto'}" não está mais disponível nessa opção. Revise o carrinho.`);
    }
    return { ...item, estoqueId: db.estoques.idDaCor(produto, item.cor, estoque), nome: produto.nome, preco: produto.preco, produto: { ...produto, atacado: categoriasAtacado.has(produto.categoria) } };
  });
  const pedidoPorGrupo = {};
  for (const i of conferidos) if (i.estoqueId) pedidoPorGrupo[i.estoqueId] = (pedidoPorGrupo[i.estoqueId] || 0) + i.qtd;
  for (const [grupo, qtd] of Object.entries(pedidoPorGrupo)) {
    const resta = estoque.quantidades[grupo] ?? 0;
    if (qtd > resta) {
      const nomes = [...new Set(conferidos.filter((i) => i.estoqueId === grupo).map((i) => `${i.nome} (${i.cor})`))].join(', ');
      throw new ErroHttp(409, resta ? `Só restam ${resta} peça(s) disponíveis de ${nomes}. Ajuste o carrinho.` : `${nomes}: esgotado no momento.`);
    }
  }
  return conferidos;
}

const paraGravar = (conferidos) => conferidos.map(({ handle, cor, tamanho, qtd, nome, preco, estoqueId }) => ({ handle, cor, tamanho, qtd, nome, preco, estoqueId: estoqueId || null }));

async function cotarFrete(cep, conferidos) {
  return frete.cotar(cep, conferidos.map(({ produto, qtd }) => ({ produto, qtd })));
}

// Cria (ou devolve, pela chave de idempotência) o pedido e gera o Pix.
async function criarCheckout(usuario, dados) {
  const conferidos = aplicarDescontoAtacado(await conferirItens(dados.itens));
  if (conferidos.some((i) => !i.preco)) throw new ErroHttp(409, 'Há produto com preço sob consulta no carrinho. Fale com a loja pelo WhatsApp.');
  const subtotal = somar(conferidos.map((i) => i.preco * i.qtd));
  const opcao = dados.tipoEntrega === 'retirada-loja'
    ? { id: 'retirada-loja', nome: 'Retirada na loja — Pinhais/PR', preco: 0, prazoDias: 0 }
    : (await cotarFrete(dados.endereco.cep, conferidos)).find((o) => o.id === dados.freteServico);
  if (!opcao) throw new ErroHttp(409, 'Essa opção de frete não está mais disponível. Calcule o frete de novo.');

  const r = await db.pedidos.criarCheckout({
    usuarioId: usuario.id,
    chave: dados.chave,
    itens: paraGravar(conferidos),
    subtotal,
    frete: opcao.preco,
    freteServico: opcao.id,
    freteNome: opcao.nome,
    fretePrazoDias: opcao.prazoDias,
    cliente: dados.cliente,
    endereco: dados.endereco,
    metodo: dados.pagamento,
    validadeMin: VALIDADE_PIX_MIN,
  });
  if (r.limite) throw new ErroHttp(429, 'Você já tem pedidos aguardando pagamento. Pague ou espere eles expirarem.');
  const pedido = r.pedido;
  if (pedido.pagamentoId || pedido.status !== 'aguardando') return pedido; // repetição da mesma tentativa

  if (dados.pagamento === 'getnet-checkout') {
    if (!await db.pedidos.reservarPagamentoGlobal(pedido.id)) {
      throw new ErroHttp(409, 'O pagamento está sendo preparado ou aguarda conciliação. Consulte seus pedidos antes de tentar novamente.');
    }
    try {
      const pagamento = await provedor().criarCheckout({ pedido, usuario, cliente: dados.cliente, cobranca: dados.cobranca });
      await db.pedidos.definirPagamento(pedido.id, pagamento);
      return { ...pedido, pagamentoId: pagamento.pagamentoId, pagamentoDados: pagamento.dadosPagamento };
    } catch (erro) {
      await db.pedidos.falhaPagamentoGlobal(pedido.id);
      // Sem corpos HTTP, tokens ou dados de cartão nos logs e sem nova criação automática.
      throw new ErroHttp(502, 'Não foi possível preparar o pagamento. Consulte seus pedidos; a loja precisa conferir esta tentativa antes de gerar outra.');
    }
  }

  try {
    const pix = await provedor().criarPix({ pedidoId: pedido.id, totalCentavos: centavos(pedido.total), clienteId: usuario.id });
    const dadosPagamento = { copiaECola: pix.copiaECola, expiraEm: pix.expiraEm };
    await db.pedidos.definirPagamento(pedido.id, { pagamentoId: pix.pagamentoId, dadosPagamento });
    await db.seguranca.auditar('pedido_criado', { usuarioId: usuario.id, detalhe: { pedido: pedido.numero, total: pedido.total } });
    return { ...pedido, pagamentoId: pix.pagamentoId, pagamentoDados: dadosPagamento };
  } catch (erro) {
    await db.pedidos.cancelarSemPagamento(pedido.id);
    if (erro instanceof ErroHttp) throw erro;
    console.error(`pagamento: falha ao gerar o Pix do pedido #${pedido.numero}: ${erro.message}`);
    throw new ErroHttp(502, 'Não foi possível gerar o pagamento agora. Tente de novo em instantes.');
  }
}

// Notificação de pagamento: o status é sempre consultado no provedor (a notificação não é confiável).
async function confirmarPagamento(pagamentoId) {
  const p = provedor();
  if (p.nome === 'getnet-global') return confirmarPagamentoGlobal(pagamentoId);
  const consulta = await p.consultar(pagamentoId);
  const valor = consulta.valorCentavos == null ? null : consulta.valorCentavos / 100;
  const resultado = await db.pedidos.processarPagamento(p.nome, pagamentoId, consulta.status, valor);
  publico.limpar();
  return resultado;
}

async function confirmarPagamentoGlobal(id) {
  const pedido = await db.pedidos.porPagamentoId(id);
  if (!pedido || pedido.pagamentoMetodo !== 'getnet-checkout') return 'ignorado';
  const p = require('./pagamento/getnet-global');
  const consulta = await p.consultar(id);
  if (consulta.pedidoId !== pedido.id) throw new ErroHttp(502, 'Referência do pagamento Getnet divergente.');
  const resultado = await db.pedidos.processarPagamentoGlobal(id, consulta.status,
    consulta.valorCentavos == null ? null : consulta.valorCentavos / 100);
  publico.limpar();
  return resultado;
}

// Tarefa agendada: confere Pix vencidos (pode ter pago no último minuto) e expira os demais.
async function expirarVencidos() {
  let expirados = 0;
  for (const v of await db.pedidos.vencidos()) {
    if (v.pagamento_metodo === 'getnet-checkout') {
      // Nunca expirar localmente após falha de consulta, nem deixar uma intenção pagável aberta.
      if (!v.pagamento_id) continue; // falha de criação requer conciliação pelo order_id
      try {
        await confirmarPagamentoGlobal(v.pagamento_id);
        const atual = await db.pedidos.porPagamentoId(v.pagamento_id);
        if (atual.status !== 'aguardando') continue;
        await require('./pagamento/getnet-global').cancelar(v.pagamento_id);
        await confirmarPagamentoGlobal(v.pagamento_id);
        expirados++;
      } catch { console.error('Getnet: intenção vencida permanece em conciliação.'); }
      continue;
    }
    if (v.pagamento_id) {
      const resultado = await confirmarPagamento(v.pagamento_id).catch((e) => console.error(`expiração: ${e.message}`));
      if (resultado === 'atualizado') continue;
    }
    if (await db.pedidos.expirar(v.id)) expirados++;
  }
  return expirados;
}

module.exports = { conferirItens, paraGravar, cotarFrete, criarCheckout, confirmarPagamento, confirmarPagamentoGlobal, expirarVencidos, aplicarDescontoAtacado, percentualAtacado };
