// Limites de tentativas guardados no banco (valem para todas as instâncias da Vercel).
const db = require('./db');
const { ErroHttp } = require('./http');

const MINUTO = 60;

// Conta uma tentativa e barra quem passou do limite na janela.
async function limitar(chave, max, janelaS) {
  const { permitido, esperaS } = await db.seguranca.consumirLimite(chave, max, janelaS);
  if (!permitido) {
    const minutos = Math.max(1, Math.ceil(esperaS / MINUTO));
    throw new ErroHttp(429, `Muitas tentativas. Tente de novo em ${minutos} ${minutos === 1 ? 'minuto' : 'minutos'}.`);
  }
}

module.exports = { limitar, zerarLimite: (chave) => db.seguranca.zerarLimite(chave), MINUTO };
