// Largura e altura de imagens (WebP, PNG, JPEG) lidas do cabeçalho do arquivo.
// Com width/height no <img>, o navegador reserva o espaço antes de baixar: a página não "pula".
const fs = require('fs');
const path = require('path');

const PUBLICO = path.join(__dirname, '..', 'public');
const cache = new Map(); // src -> { largura, altura } | null

function ler(buf) {
  if (buf.length >= 30 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') {
    const tipo = buf.toString('ascii', 12, 16);
    if (tipo === 'VP8X') return { largura: 1 + buf.readUIntLE(24, 3), altura: 1 + buf.readUIntLE(27, 3) };
    if (tipo === 'VP8 ') return { largura: buf.readUInt16LE(26) & 0x3fff, altura: buf.readUInt16LE(28) & 0x3fff };
    if (tipo === 'VP8L') {
      const v = buf.readUInt32LE(21);
      return { largura: (v & 0x3fff) + 1, altura: ((v >> 14) & 0x3fff) + 1 };
    }
  }
  if (buf.length >= 24 && buf.readUInt32BE(0) === 0x89504e47) return { largura: buf.readUInt32BE(16), altura: buf.readUInt32BE(20) };
  if (buf.length >= 4 && buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) return null;
      const marcador = buf[i + 1];
      const tamanho = buf.readUInt16BE(i + 2);
      // SOF0..SOF15 (exceto DHT/JPG/DAC) trazem altura e largura
      if (marcador >= 0xc0 && marcador <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marcador)) {
        return { altura: buf.readUInt16BE(i + 5), largura: buf.readUInt16BE(i + 7) };
      }
      i += 2 + tamanho;
    }
  }
  return null;
}

async function dimensoes(src) {
  if (cache.has(src)) return cache.get(src);
  let medida = null;
  try {
    if (src.startsWith('/img/')) {
      const arquivo = path.join(PUBLICO, path.normalize(src));
      if (arquivo.startsWith(PUBLICO + path.sep)) {
        const fd = fs.openSync(arquivo, 'r');
        const buf = Buffer.alloc(65536);
        const lidos = fs.readSync(fd, buf, 0, buf.length, 0);
        fs.closeSync(fd);
        medida = ler(buf.subarray(0, lidos));
      }
    } else if (/^https:\/\/[\w.-]+\.supabase\.co\//.test(src)) {
      // fotos enviadas pelo admin (Storage): baixa só o começo do arquivo
      const r = await fetch(src, { headers: { Range: 'bytes=0-65535' }, signal: AbortSignal.timeout(3000) });
      if (r.ok) medida = ler(Buffer.from(await r.arrayBuffer()));
    }
  } catch {
    medida = null; // sem medida, a imagem só não ganha width/height
  }
  if (medida && !(medida.largura > 0 && medida.altura > 0)) medida = null;
  cache.set(src, medida);
  return medida;
}

module.exports = { dimensoes };
