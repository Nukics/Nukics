// Dados públicos da loja (vitrine, menu, configurações) com cache curto em memória.
// Cada página consultava o banco várias vezes; agora a mesma instância reaproveita por 30 s.
// Qualquer alteração feita no admin limpa o cache (ver api/index.js).
const db = require('./db');
const { checkoutAtivo, provedorPagamento } = require('./ambiente');

const TTL_MS = 30_000;
const cache = new Map();

function memo(chave, fn) {
  const item = cache.get(chave);
  if (item && item.expira > Date.now()) return item.valor;
  const valor = fn().catch((erro) => {
    cache.delete(chave); // não guarda falha
    throw erro;
  });
  cache.set(chave, { valor, expira: Date.now() + TTL_MS });
  return valor;
}

const limpar = () => cache.clear();

const config = () => memo('config', () => db.config.ler());
const menu = () => memo('menu', () => db.menu.ler());
const categorias = () => memo('categorias', () => db.categorias.listar());
const paginas = () => memo('paginas', () => db.paginas.ler());
const faq = () => memo('faq', () => db.faq.ler());

// Mesmo formato de GET /api/loja. Esgotado: o grupo de estoque chegou a zero
// (a quantidade e os dados internos do produto não são expostos).
const dadosLoja = () => memo('loja', async () => {
  const [{ whatsapp, telefone, parcelas, banners }, produtos, cats, destaques, perguntas, estoque, curtidas] = await Promise.all([
    config(), db.produtos.listar(), categorias(), db.destaques.ler(), faq(), db.estoques.disponibilidade(), db.curtidas.totais(),
  ]);
  const categoriasAtacado = new Set(['atacado', ...cats.filter((c) => c.pai === 'atacado').map((c) => c.slug)]);
  const publicos = produtos.map(({ estoqueId, codigoNcm, pesoKg, larguraCm, alturaCm, comprimentoCm, ...p }) => {
    const cores = p.cores.map((cor) => {
      const id = db.estoques.idDaCor({ handle: p.handle, estoqueId }, cor.nome, estoque);
      return { ...cor, esgotado: Boolean(id) && !(estoque.quantidades[id] > 0) };
    });
    return { ...p, cores, atacado: categoriasAtacado.has(p.categoria), esgotado: cores.every((c) => c.esgotado) };
  });
  return {
    config: { whatsapp, telefone, parcelas, banners, checkout: checkoutAtivo(), checkoutIntegrado: provedorPagamento() === 'getnet-global' },
    produtos: publicos.map((p) => ({ ...p, curtidas: curtidas[p.handle] || 0 })),
    categorias: cats,
    destaques,
    faq: perguntas,
  };
});

module.exports = { config, menu, categorias, paginas, faq, dadosLoja, limpar };
