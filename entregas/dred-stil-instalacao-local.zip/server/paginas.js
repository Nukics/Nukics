// Rotas das páginas do site (HTML).
// Páginas públicas (início, catálogo, produto, textos) saem prontas do servidor, iguais para todos,
// e ficam na CDN da Vercel por 60 s. Páginas da conta, checkout e admin nunca são guardadas.
const publico = require('./publico');
const { renderizar, htmlFaq, htmlBanners, htmlPromo } = require('./render');
const { redirecionar } = require('./http');
const { usuarioDaSessao, adminVerificado } = require('./auth');
const { textoParaHtml } = require('./texto');
const { PAGINAS_DE_TEXTO } = require('./vitrine');
const { htmlDestaques, htmlCatalogo, htmlProduto, urlProduto } = require('./vitrine-html');
const { urlSite } = require('./ambiente');

// Dados estruturados da loja (Google: nome, endereço, contato).
function jsonLdLoja(config) {
  const base = urlSite();
  const redes = Object.values(config.redesSociais || {}).filter(Boolean);
  return {
    '@context': 'https://schema.org',
    '@type': 'ClothingStore',
    name: 'Dred Stil',
    url: base,
    logo: `${base}/img/logo-dredstil-oficial.webp`,
    image: `${base}/img/logo-dredstil-oficial.webp`,
    ...(config.telefone ? { telephone: config.telefone } : {}),
    address: { '@type': 'PostalAddress', streetAddress: 'Av. Maria Antonieta, 354', addressLocality: 'Pinhais', addressRegion: 'PR', addressCountry: 'BR' },
    ...(redes.length ? { sameAs: redes } : {}),
  };
}

// Dados estruturados do produto (Google: preço, disponibilidade, fotos).
function jsonLdProduto(p) {
  const base = urlSite();
  const fotos = p.cores.flatMap((c) => c.imagens).slice(0, 6).map((src) => (src.startsWith('/') ? base + src : src));
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: p.nome,
    description: p.descricao || p.nome,
    image: fotos,
    sku: p.handle,
    brand: { '@type': 'Brand', name: 'Dred Stil' },
    ...(p.preco ? {
      offers: {
        '@type': 'Offer',
        url: base + urlProduto(p.handle),
        priceCurrency: 'BRL',
        price: p.preco.toFixed(2),
        availability: p.esgotado ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock',
        itemCondition: 'https://schema.org/NewCondition',
      },
    } : {}),
  };
}

const PAGINAS = {
  '/': async () => {
    const loja = await publico.dadosLoja();
    const config = await publico.config();
    const parcelas = loja.config.parcelas;
    const destaques = htmlDestaques({ destaques: loja.destaques, produtos: loja.produtos, parcelas });
    return {
      view: 'inicio',
      pagina: 'inicio',
      publica: true,
      loja,
      seo: { imagem: loja.config.banners?.[0]?.imagem || '/img/logo-dredstil-oficial.webp', jsonLd: [jsonLdLoja(config)] },
      dados: {
        banners: await htmlBanners(loja.config.banners),
        promo: htmlPromo(config.mensagemPromocional),
        faq: htmlFaq(loja.faq),
        faqOculto: loja.faq.length ? '' : ' hidden',
        destaquesAbas: destaques.abas,
        destaquesGrade: destaques.grade,
        destaquesOculto: destaques.vazio ? ' hidden' : '',
        catalogo: htmlCatalogo({ produtos: loja.produtos, categorias: loja.categorias, parcelas }),
      },
    };
  },
  '/catalogo': async () => {
    const loja = await publico.dadosLoja();
    return {
      view: 'catalogo',
      pagina: 'catalogo',
      titulo: 'Catálogo',
      descricao: 'Catálogo Dred Stil: camisetas oversized e moda street feminina e masculina.',
      publica: true,
      loja,
      dados: { catalogo: htmlCatalogo({ produtos: loja.produtos, categorias: loja.categorias, parcelas: loja.config.parcelas, completo: true }) },
    };
  },
  '/favoritos': () => ({ view: 'favoritos', pagina: 'favoritos', titulo: 'Meus favoritos' }),
  '/atacado': async () => {
    const loja = await publico.dadosLoja();
    const { percentualAtacado } = require('./pedidos');
    const faixas = [...Array.from({ length: 9 }, (_, i) => [i + 2, `${i + 2} peças`]), [11, '11 ou 12 peças'], [13, 'Acima de 12 peças']];
    return {
      view: 'atacado', pagina: 'atacado', titulo: 'Preço de atacado', publica: true, loja,
      descricao: 'Descontos por quantidade na categoria Atacado Dred Stil. A partir de 2 peças e 30% de desconto acima de 12 peças.',
      dados: {
        faixasAtacado: faixas.map(([n, texto]) => `<tr><th scope="row">${texto}</th><td>${percentualAtacado(n)}%</td></tr>`).join(''),
        catalogo: htmlCatalogo({ produtos: loja.produtos, categorias: loja.categorias, parcelas: loja.config.parcelas, completo: true, categoriaInicial: 'atacado', categoriaFixa: 'atacado' }),
      },
    };
  },
  '/conta': () => ({ view: 'conta', pagina: 'conta', titulo: 'Minha conta' }),
  '/checkout': () => ({ view: 'checkout', pagina: 'checkout', titulo: 'Finalizar compra' }),
  '/admin': async (req) => {
    const usuario = await usuarioDaSessao(req);
    if (adminVerificado(usuario)) return { view: 'admin', pagina: 'admin', titulo: 'Administração' };
    return { redirecionar: usuario ? '/conta' : '/conta?voltar=/admin' };
  },
};

// Páginas de texto (Quem somos, Trocas e devoluções...) editadas no admin.
// "Onde estamos" usa uma view própria, com o mapa abaixo do texto.
async function paginaDeTexto(endereco) {
  const pagina = (await publico.paginas())[endereco];
  if (!pagina) return null;
  return {
    view: endereco === 'onde-estamos' ? 'onde-estamos' : 'texto',
    titulo: pagina.titulo,
    publica: true,
    dados: { titulo: pagina.titulo, texto: textoParaHtml(pagina.texto) },
  };
}

async function paginaDeProduto(handle, url) {
  const loja = await publico.dadosLoja();
  const produto = loja.produtos.find((p) => p.handle === handle);
  if (!produto) return null;
  const cor = produto.cores.find((c) => c.nome === url.searchParams.get('cor')) || produto.cores[0];
  return {
    view: 'produto',
    pagina: 'produto',
    titulo: produto.nome,
    descricao: (produto.descricao || `${produto.nome} — Dred Stil Street Style`).slice(0, 160),
    publica: true,
    loja,
    seo: { tipo: 'product', imagem: cor.imagens[0], jsonLd: [jsonLdProduto(produto)] },
    dados: { handle, produto: htmlProduto(produto, { categorias: loja.categorias, parcelas: loja.config.parcelas, corNome: cor.nome }) },
  };
}

async function tratarPagina(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    return res.end();
  }
  const caminho = url.pathname.length > 1 ? url.pathname.replace(/\/+$/, '') : '/';
  let destino;

  if (PAGINAS[caminho]) destino = await PAGINAS[caminho](req);
  else if (PAGINAS_DE_TEXTO.includes(caminho.slice(1))) destino = await paginaDeTexto(caminho.slice(1));
  else {
    const handle = /^\/produto\/([\w-]+)$/.exec(caminho)?.[1];
    if (handle) destino = await paginaDeProduto(handle, url);
  }

  if (destino?.redirecionar) return redirecionar(res, destino.redirecionar);
  if (!destino) destino = { view: '404', titulo: 'Página não encontrada', status: 404 };
  await renderizar(res, destino.view, { ...destino, url });
}

module.exports = { tratarPagina };
