// Validação e limpeza de tudo que chega do navegador. Cada função devolve o
// dado já normalizado ou lança ErroHttp 400 com uma mensagem amigável.
const { ErroHttp } = require('./http');
const { fotos } = require('./db');

const falha = (mensagem) => {
  throw new ErroHttp(400, mensagem);
};

// Remove caracteres de controle (exceto quebra de linha) e espaços nas pontas.
function texto(valor, campo, { min = 0, max = 200 } = {}) {
  if (valor === undefined || valor === null) valor = '';
  if (typeof valor !== 'string') falha(`${campo}: valor inválido.`);
  const limpo = valor.replace(/[\u0000-\u0009\u000B-\u001F\u007F]/g, '').trim();
  if (limpo.length < min) falha(min === 1 ? `${campo} é obrigatório.` : `${campo} precisa ter pelo menos ${min} caracteres.`);
  if (limpo.length > max) falha(`${campo} pode ter no máximo ${max} caracteres.`);
  return limpo;
}

function numero(valor, campo, { min = 0, max = 1e6, inteiro = false } = {}) {
  const n = Number(valor);
  if (!Number.isFinite(n) || n < min || n > max || (inteiro && !Number.isInteger(n))) falha(`${campo}: número inválido.`);
  return inteiro ? n : Math.round(n * 100) / 100;
}

function lista(valor, campo, item, { max = 50 } = {}) {
  if (!Array.isArray(valor)) falha(`${campo}: lista inválida.`);
  if (valor.length > max) falha(`${campo}: no máximo ${max} itens.`);
  return valor.map(item);
}

function email(valor) {
  const e = texto(valor, 'E-mail', { min: 1, max: 160 }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) falha('E-mail inválido.');
  return e;
}

function senha(valor, campo = 'Senha') {
  if (typeof valor !== 'string' || valor.length < 8) falha(`${campo} precisa ter pelo menos 8 caracteres.`);
  if (valor.length > 200) falha(`${campo} longa demais.`);
  return valor;
}

function url(valor, campo) {
  const u = texto(valor, campo, { max: 300 });
  if (u && !/^https:\/\/[^\s<>"']+$/.test(u)) falha(`${campo} precisa começar com https://`);
  return u;
}

// Imagem da própria loja (ex.: /img/produtos/foto.webp) ou foto enviada pelo admin ao Storage.
function imagem(valor, campo = 'Imagem') {
  const c = texto(valor, campo, { min: 1, max: 300 });
  const arquivo = c.startsWith(fotos.PREFIXO) ? `/${c.slice(fotos.PREFIXO.length)}` : c.startsWith('/img/') ? c : '';
  if (!/^\/[\w\-/]+\.(webp|jpe?g|png|avif|gif)$/i.test(arquivo) || arquivo.includes('..')) falha(`${campo}: caminho inválido.`);
  return c;
}

// Link interno da loja (ex.: /catalogo?categoria=Camisetas).
function linkInterno(valor, campo) {
  const l = texto(valor, campo, { max: 200 });
  if (l && !/^\/(?!\/)[^\s<>"']*$/.test(l)) falha(`${campo} precisa ser um endereço da loja, começando com /`);
  return l;
}

function slug(valor) {
  return String(valor)
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

/* ---------------- esquemas ---------------- */
// Nome completo (obrigatório): pelo menos nome e sobrenome.
function nomeCompleto(valor) {
  const n = texto(valor, 'Nome completo', { min: 5, max: 100 }).replace(/\s+/g, ' ');
  if (n.split(' ').length < 2) falha('Informe seu nome completo (nome e sobrenome).');
  if (/[<>{}]/.test(n)) falha('Nome completo: caracteres inválidos.');
  return n;
}

// Apelido da conta (nick): letras minúsculas, números, ponto e sublinhado. Único entre as contas.
function apelido(valor) {
  const a = texto(valor, 'Apelido', { min: 1, max: 30 }).toLowerCase();
  if (!/^[a-z0-9_.]{3,30}$/.test(a)) falha('Apelido: use de 3 a 30 letras sem acento, números, ponto ou sublinhado.');
  return a;
}

// Celular ou fixo com DDD (obrigatório em toda conta).
function telefoneObrigatorio(valor) {
  const t = String(valor ?? '').replace(/\D/g, '');
  if (t.length < 10 || t.length > 11) falha('Informe um telefone com DDD.');
  return t;
}

// CPF opcional na conta; quando informado, precisa ser válido (e não pode estar em outra conta).
const cpfOpcional = (valor) => (String(valor ?? '').replace(/\D/g, '') ? cpf(valor) : null);

function cadastro(d) {
  return {
    nome: nomeCompleto(d.nome),
    apelido: apelido(d.apelido),
    email: email(d.email),
    telefone: telefoneObrigatorio(d.telefone),
    cpf: cpfOpcional(d.cpf),
    senha: senhaNova(d.senha),
  };
}

// Entrar com e-mail ou apelido.
function login(d) {
  const identificador = texto(d.identificador ?? d.email, 'E-mail ou apelido', { min: 3, max: 160 }).toLowerCase();
  return { identificador, senha: texto(d.senha, 'Senha', { min: 1, max: 200 }) };
}

// Recuperação de senha por e-mail, apelido ou nome completo.
function recuperacao(d) {
  const valor = texto(d.identificador ?? d.email, 'E-mail, apelido ou nome completo', { min: 3, max: 160 }).replace(/\s+/g, ' ');
  if (/[<>{}]/.test(valor)) falha('Informe seu e-mail, apelido ou nome completo.');
  return { identificador: valor };
}

// Senhas muito usadas são recusadas no cadastro e na troca de senha.
const SENHAS_COMUNS = new Set(['12345678', '123456789', '1234567890', 'password', 'senha123', 'senha1234', '11111111',
  '00000000', 'qwertyui', 'abcdefgh', 'iloveyou', 'brasil123', 'admin123', 'dredstil', '87654321', '12341234']);

function senhaNova(valor, campo = 'Senha') {
  const s = senha(valor, campo);
  if (SENHAS_COMUNS.has(s.toLowerCase())) falha(`${campo}: essa senha é muito comum. Escolha outra.`);
  return s;
}

const tokenTexto = (valor) => {
  if (typeof valor !== 'string' || !/^[\w-]{20,100}$/.test(valor)) falha('Link inválido ou expirado.');
  return valor;
};

function codigo(d) {
  const c = String(d.codigo ?? '').replace(/\D/g, '');
  if (c.length !== 6) falha('Digite o código de 6 dígitos.');
  return { desafio: tokenTexto(d.desafio), codigo: c };
}

const emailApenas = (d) => ({ email: email(d.email) });
const token = (d) => ({ token: tokenTexto(d.token) });
const redefinicao = (d) => ({ token: tokenTexto(d.token), senha: senhaNova(d.senha, 'Nova senha') });

function doisFatores(d) {
  if (typeof d.ativar !== 'boolean') falha('Opção inválida.');
  return { ativar: d.ativar, senha: texto(d.senha, 'Senha', { min: 1, max: 200 }) };
}

// CPF com dígitos verificadores (exigido para nota fiscal e envio).
function cpf(valor) {
  const d = String(valor ?? '').replace(/\D/g, '');
  const dv = (n) => {
    let soma = 0;
    for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
    const r = (soma * 10) % 11;
    return r === 10 ? 0 : r;
  };
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d) || dv(9) !== Number(d[9]) || dv(10) !== Number(d[10])) falha('CPF inválido.');
  return d;
}

function cep(valor) {
  const c = String(valor ?? '').replace(/\D/g, '');
  if (c.length !== 8) falha('CEP inválido.');
  return c;
}

// Sem HTML nos dados de entrega (vão para etiqueta, nota e painel admin).
const semHtml = (valor, campo, opcoes) => {
  const t = texto(valor, campo, opcoes);
  if (/[<>{}]/.test(t)) falha(`${campo}: caracteres inválidos.`);
  return t;
};

function checkout(d) {
  const cliente = d.cliente || {};
  const end = d.endereco || {};
  const tipoEntrega = String(d.tipoEntrega || 'melhor-envio');
  const telefone = String(cliente.telefone ?? '').replace(/\D/g, '');
  if (telefone.length < 10 || telefone.length > 11) falha('Celular inválido.');
  const chave = String(d.chaveIdempotencia ?? '');
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(chave)) falha('Recarregue a página e tente de novo.');
  const servico = String(d.freteServico ?? '');
  if (!['melhor-envio', 'retirada-loja'].includes(tipoEntrega)) falha('Escolha uma forma de entrega válida.');
  if (!/^[\w-]{1,40}$/.test(servico)) falha('Escolha o frete.');
  if (tipoEntrega === 'retirada-loja' && servico !== 'retirada-loja') falha('Escolha a retirada na loja.');
  const integrado = require('./ambiente').provedorPagamento() === 'getnet-global';
  if (d.pagamento !== (integrado ? 'getnet-checkout' : 'pix')) falha('Forma de pagamento inválida.');
  if (integrado && (typeof cliente.nome !== 'string' || cliente.nome.trim().split(/\s+/).length < 2)) falha('Informe o nome completo.');
  if (integrado) {
    const nomes = cliente.nome.trim().split(/\s+/);
    if (nomes[0].length > 40 || nomes.slice(1).join(' ').length > 80) falha('Nome excede o limite aceito pelo pagamento.');
  }
  let endereco = null;
  if (tipoEntrega === 'melhor-envio' || integrado) {
    const uf = texto(end.uf, 'Estado', { min: 2, max: 2 }).toUpperCase();
    if (!/^[A-Z]{2}$/.test(uf)) falha('Estado inválido.');
    endereco = {
      cep: cep(end.cep),
      rua: semHtml(end.rua, 'Rua', { min: 2, max: 120 }),
      numero: semHtml(end.numero, 'Número', { min: 1, max: 20 }),
      complemento: semHtml(end.complemento, 'Complemento', { max: 80 }),
      bairro: semHtml(end.bairro, 'Bairro', { min: 2, max: 80 }),
      cidade: semHtml(end.cidade, 'Cidade', { min: 2, max: 80 }),
      uf,
    };
  }
  return {
    itens: itensPedido(d),
    tipoEntrega,
    freteServico: servico,
    cliente: { nome: semHtml(cliente.nome, 'Nome', { min: 3, max: 100 }), cpf: cpf(cliente.cpf), telefone },
    endereco: tipoEntrega === 'melhor-envio' ? endereco : null,
    ...(integrado ? { cobranca: endereco } : {}),
    pagamento: integrado ? 'getnet-checkout' : 'pix',
    chave: chave.toLowerCase(),
  };
}

const cotacao = (d) => ({ cep: cep(d.cep), itens: itensPedido(d) });

function rastreio(valor) {
  const r = texto(valor, 'Código de rastreio', { max: 40 });
  if (r && !/^[A-Za-z0-9-]{5,40}$/.test(r)) falha('Código de rastreio inválido.');
  return r;
}

// NCM da nota fiscal: 8 números (padrão: camiseta de malha de algodão — confirmar com o contador).
function ncm(valor) {
  const n = String(valor ?? '61091000').replace(/\D/g, '');
  if (!/^\d{8}$/.test(n)) falha('NCM: informe os 8 números (ex.: 6109.10.00).');
  return n;
}

function perfil(d) {
  return { nome: nomeCompleto(d.nome), apelido: apelido(d.apelido), telefone: telefoneObrigatorio(d.telefone), cpf: cpfOpcional(d.cpf) };
}

function trocaSenha(d) {
  return { senhaAtual: texto(d.senhaAtual, 'Senha atual', { min: 1, max: 200 }), senhaNova: senhaNova(d.senhaNova, 'Nova senha') };
}

// Grupo de estoque: nome, peças disponíveis e os produtos que fazem parte dele.
function estoque(d) {
  return {
    nome: texto(d.nome, 'Nome do estoque', { min: 2, max: 60 }),
    cor: d.cor == null ? null : texto(d.cor, 'Cor do estoque', { min: 1, max: 40 }),
    quantidade: numero(d.quantidade, 'Quantidade de peças', { min: 0, max: 100000, inteiro: true }),
    produtos: [...new Set(lista(d.produtos || [], 'Produtos', (h) => slug(h), { max: 500 }))].filter(Boolean),
  };
}

function produto(d) {
  const nome = texto(d.nome, 'Nome', { min: 2, max: 120 });
  const handle = slug(d.handle || nome);
  if (!handle) falha('Endereço do produto inválido.');
  const preco = numero(d.preco, 'Preço');
  const precoDe = numero(d.precoDe || 0, 'Preço "de"');
  if (precoDe && precoDe <= preco) falha('O preço "de" precisa ser maior que o preço de venda.');
  const cores = lista(d.cores, 'Cores', (c, i) => ({
    nome: texto(c.nome, `Cor ${i + 1}`, { min: 1, max: 40 }),
    hex: /^#[0-9a-f]{6}$/i.test(c.hex) ? c.hex.toUpperCase() : falha(`Cor ${i + 1}: código de cor inválido.`),
    imagens: lista(c.imagens, `Fotos da cor ${i + 1}`, (img) => imagem(img), { max: 12 }),
  }), { max: 20 });
  if (!cores.length) falha('Cadastre pelo menos uma cor.');
  cores.forEach((c) => c.imagens.length || falha(`A cor ${c.nome} precisa de pelo menos uma foto.`));
  const tamanhos = lista(d.tamanhos, 'Tamanhos', (t) => texto(t, 'Tamanho', { min: 1, max: 10 }), { max: 15 });
  if (!tamanhos.length) falha('Cadastre pelo menos um tamanho.');
  const categoria = slug(d.categoria || '');
  if (!categoria) falha('Escolha a categoria do produto.');
  return {
    handle,
    nome,
    categoria,
    preco,
    precoDe,
    descricao: texto(d.descricao, 'Descrição', { max: 2000 }),
    tamanhos,
    cores,
    ativo: d.ativo !== false,
    pesoKg: numero(d.pesoKg ?? 0.3, 'Peso (kg)', { min: 0.01, max: 30 }),
    larguraCm: numero(d.larguraCm ?? 20, 'Largura (cm)', { min: 1, max: 100, inteiro: true }),
    alturaCm: numero(d.alturaCm ?? 4, 'Altura (cm)', { min: 1, max: 100, inteiro: true }),
    comprimentoCm: numero(d.comprimentoCm ?? 28, 'Comprimento (cm)', { min: 1, max: 100, inteiro: true }),
    codigoNcm: ncm(d.codigoNcm),
  };
}

function categoria(d) {
  const nome = texto(d.nome, 'Nome da categoria', { min: 2, max: 40 });
  const endereco = slug(nome);
  if (!endereco) falha('Nome da categoria inválido.');
  return { slug: endereco, nome, pai: d.pai ? slug(d.pai) : null };
}

function edicaoCategoria(d) {
  let pai;
  if (d.pai !== undefined) {
    if (d.pai === null || d.pai === '') pai = null;
    else {
      pai = slug(texto(d.pai, 'Categoria principal', { min: 1, max: 80 }));
      if (!pai) falha('Categoria principal inválida.');
    }
  }
  return {
    nome: d.nome === undefined ? undefined : texto(d.nome, 'Nome da categoria', { min: 2, max: 40 }),
    noMenu: d.noMenu === undefined ? undefined : d.noMenu === true,
    ordem: d.ordem === undefined ? undefined : numero(d.ordem, 'Ordem', { min: 0, max: 1000, inteiro: true }),
    pai,
  };
}

// Abas da seção Destaques da página inicial, cada uma com os produtos escolhidos (em ordem).
function destaques(d) {
  return lista(d, 'Abas de destaques', (aba, i) => ({
    nome: texto(aba.nome, `Nome da aba ${i + 1}`, { min: 2, max: 40 }),
    produtos: [...new Set(lista(aba.produtos, `Produtos da aba ${i + 1}`, (h) => slug(h), { max: 24 }))].filter(Boolean),
  }), { max: 10 });
}

const TIPOS_MENU = ['link', 'catalogo', 'categoria', 'pagina'];

// Itens do menu principal. O link Admin é fixo (só aparece para o admin) e não entra aqui.
function menu(d, paginasValidas) {
  return lista(d, 'Menu', (item, i) => {
    const campo = `Item ${i + 1} do menu`;
    if (!TIPOS_MENU.includes(item.tipo)) falha(`${campo}: tipo inválido.`);
    const base = { tipo: item.tipo, rotulo: texto(item.rotulo, `${campo}: nome`, { min: 1, max: 30 }), visivel: item.visivel !== false };
    if (item.tipo === 'link') return { ...base, link: linkInterno(item.link, `${campo}: endereço`) || falha(`${campo}: informe o endereço.`) };
    if (item.tipo === 'categoria') return { ...base, categoria: slug(item.categoria || '') || falha(`${campo}: escolha a categoria.`) };
    if (item.tipo === 'pagina') {
      if (!paginasValidas.includes(item.pagina)) falha(`${campo}: escolha a página.`);
      return { ...base, pagina: item.pagina };
    }
    return base;
  }, { max: 12 });
}

function textoPagina(d) {
  return { texto: texto(d.texto, 'Texto da página', { min: 1, max: 20000 }) };
}

// Itens enviados pelo carrinho; preço e nome vêm sempre do banco, nunca do navegador.
function itensPedido(d) {
  const itens = lista(d.itens, 'Itens do pedido', (item, i) => ({
    handle: slug(item.handle || '') || falha(`Item ${i + 1}: produto inválido.`),
    cor: texto(item.cor, `Item ${i + 1}: cor`, { min: 1, max: 40 }),
    tamanho: texto(item.tamanho, `Item ${i + 1}: tamanho`, { min: 1, max: 10 }),
    qtd: numero(item.qtd, `Item ${i + 1}: quantidade`, { min: 1, max: 99, inteiro: true }),
  }), { max: 50 });
  if (!itens.length) falha('O carrinho está vazio.');
  return itens;
}

const STATUS_PEDIDO = ['aguardando', 'pago', 'enviado', 'entregue', 'cancelado', 'expirado', 'revisar'];

function statusPedido(valor) {
  if (!STATUS_PEDIDO.includes(valor)) falha('Situação do pedido inválida.');
  return valor;
}

function perguntas(d) {
  return lista(d, 'Perguntas', (p, i) => ({
    pergunta: texto(p.pergunta, `Pergunta ${i + 1}`, { min: 3, max: 200 }),
    resposta: texto(p.resposta, `Resposta ${i + 1}`, { min: 1, max: 2000 }),
  }), { max: 40 });
}

function configuracoes(d) {
  const whatsapp = texto(d.whatsapp, 'WhatsApp', { max: 20 }).replace(/\D/g, '');
  if (whatsapp && !/^55\d{10,11}$/.test(whatsapp)) falha('WhatsApp: use DDI 55 + DDD + número (ex.: 5541999999999).');
  const redes = d.redesSociais || {};
  return {
    whatsapp,
    telefone: texto(d.telefone, 'Telefone', { max: 20 }),
    emailResposta: d.emailResposta ? email(d.emailResposta) : '',
    parcelas: numero(d.parcelas, 'Parcelas', { min: 1, max: 12, inteiro: true }),
    mensagemPromocional: texto(d.mensagemPromocional, 'Mensagem promocional', { max: 120 }),
    redesSociais: {
      instagram: url(redes.instagram, 'Instagram'),
      facebook: url(redes.facebook, 'Facebook'),
      tiktok: url(redes.tiktok, 'TikTok'),
      youtube: url(redes.youtube, 'YouTube'),
    },
    banners: lista(d.banners, 'Banners', (b, i) => ({
      imagem: imagem(b.imagem, `Banner ${i + 1}`),
      alt: texto(b.alt, `Descrição do banner ${i + 1}`, { max: 120 }),
      link: linkInterno(b.link, `Link do banner ${i + 1}`),
      focoX: numero(b.focoX ?? 50, `Enquadramento horizontal do banner ${i + 1}`, { min: 0, max: 100 }),
      focoY: numero(b.focoY ?? 50, `Enquadramento vertical do banner ${i + 1}`, { min: 0, max: 100 }),
      zoom: numero(b.zoom ?? 100, `Zoom do banner ${i + 1}`, { min: 100, max: 180 }),
      focoMobileX: numero(b.focoMobileX ?? b.focoX ?? 50, `Enquadramento horizontal no celular ${i + 1}`, { min: 0, max: 100 }),
      focoMobileY: numero(b.focoMobileY ?? b.focoY ?? 50, `Enquadramento vertical no celular ${i + 1}`, { min: 0, max: 100 }),
      zoomMobile: numero(b.zoomMobile ?? b.zoom ?? 100, `Zoom no celular ${i + 1}`, { min: 100, max: 180 }),
      ...(b.largura && b.altura ? {
        largura: numero(b.largura, `Largura do banner ${i + 1}`, { min: 1, max: 16000, inteiro: true }),
        altura: numero(b.altura, `Altura do banner ${i + 1}`, { min: 1, max: 16000, inteiro: true }),
      } : {}),
    }), { max: 8 }),
  };
}

module.exports = {
  recuperacao,
  trocaSenha,
  estoque,
  apelido,
  codigo,
  emailApenas,
  token,
  redefinicao,
  doisFatores,
  checkout,
  cotacao,
  rastreio,
  cadastro,
  login,
  perfil,
  produto,
  categoria,
  edicaoCategoria,
  destaques,
  menu,
  textoPagina,
  itensPedido,
  statusPedido,
  perguntas,
  configuracoes,
  slug,
};
