// Notas fiscais das vendas: emissão (botão do admin), acompanhamento e envio por e-mail ao cliente.
// Cada nota fica salva no pedido e na conta do cliente (tabela notas_fiscais).
const crypto = require('crypto');
const db = require('../db');
const { ErroHttp } = require('../http');
const { provedorNfe } = require('../ambiente');

function emissor() {
  const nome = provedorNfe();
  if (nome === 'focus') return require('./focus');
  if (nome === 'simulado') return require('./simulado');
  throw new ErroHttp(503, 'Emissão de nota fiscal não configurada. Cadastre os dados do emissor (veja o README).');
}

// Quando a nota fica autorizada, manda para o e-mail do cliente (uma vez).
async function enviarSeAutorizada(nota, email) {
  if (nota.status !== 'autorizada' || nota.emailEnviadoEm || !email) return nota;
  try {
    await emissor().enviarEmail(nota.ref, [email]);
    return db.notas.atualizar(nota.id, { emailEnviadoEm: new Date().toISOString() });
  } catch (erro) {
    console.error(`nota ${nota.ref}: e-mail não enviado: ${erro.message}`);
    return nota;
  }
}

async function emitir(pedidoId, admin) {
  const pedido = await db.pedidos.porId(pedidoId);
  if (!pedido) throw new ErroHttp(404, 'Pedido não encontrado.');
  if (!db.pedidos.STATUS_VENDA.includes(pedido.status)) throw new ErroHttp(409, 'Só dá para emitir nota de pedido pago, enviado ou entregue.');
  if (!pedido.entrega) throw new ErroHttp(409, 'Pedido combinado pelo WhatsApp não tem CPF e endereço do cliente. Emita a nota pelo painel do emissor.');
  const em = emissor();
  const ref = `pedido-${pedido.numero}-${crypto.randomBytes(3).toString('hex')}`;
  const nota = await db.notas.criar({ pedidoId: pedido.id, usuarioId: pedido.usuarioId, ref, provedor: em.nome });
  if (!nota) throw new ErroHttp(409, 'Este pedido já tem uma nota emitida ou em processamento.');

  const produtos = await db.produtos.buscarVarios([...new Set(pedido.itens.map((i) => i.handle))]);
  let resposta;
  try {
    resposta = await em.emitir(ref, pedido, Object.fromEntries(produtos.map((p) => [p.handle, p])));
  } catch (erro) {
    console.error(`nota ${ref}: falha ao enviar ao emissor: ${erro.message}`);
    resposta = { status: 'erro', mensagem: 'Emissor indisponível. Tente de novo em instantes.' };
  }
  const atualizada = await db.notas.atualizar(nota.id, resposta);
  await db.seguranca.auditar('nota_emitida', { usuarioId: admin.id, detalhe: { pedido: pedido.numero, ref, status: atualizada.status } });
  return enviarSeAutorizada(atualizada, pedido.cliente?.email);
}

// Consulta o emissor (nota em processamento) e envia ao cliente quando autorizar.
async function atualizar(notaId) {
  const nota = await db.notas.porId(notaId);
  if (!nota) throw new ErroHttp(404, 'Nota não encontrada.');
  const pedido = await db.pedidos.porId(nota.pedidoId);
  let atual = nota;
  if (nota.status === 'processando') atual = await db.notas.atualizar(nota.id, await emissor().consultar(nota.ref));
  return enviarSeAutorizada(atual, pedido?.cliente?.email);
}

async function reenviarEmail(notaId) {
  const nota = await db.notas.porId(notaId);
  if (!nota) throw new ErroHttp(404, 'Nota não encontrada.');
  if (nota.status !== 'autorizada') throw new ErroHttp(409, 'A nota ainda não foi autorizada.');
  const pedido = await db.pedidos.porId(nota.pedidoId);
  if (!pedido?.cliente?.email) throw new ErroHttp(409, 'O pedido não tem e-mail de cliente.');
  await emissor().enviarEmail(nota.ref, [pedido.cliente.email]);
  return db.notas.atualizar(nota.id, { emailEnviadoEm: new Date().toISOString() });
}

// Tarefa agendada: confere notas que ficaram em processamento.
async function atualizarPendentes() {
  if (!provedorNfe()) return 0;
  let n = 0;
  for (const nota of await db.notas.processando()) {
    await atualizar(nota.id).then(() => n++).catch((e) => console.error(`nota ${nota.ref}: ${e.message}`));
  }
  return n;
}

// Formato para o navegador (cliente ou admin).
const notaPublica = (n) => n && {
  id: n.id, pedidoId: n.pedidoId, status: n.status, numero: n.numero, serie: n.serie, chave: n.chave,
  urlDanfe: n.urlDanfe, urlXml: n.urlXml, mensagem: n.mensagem, emailEnviadoEm: n.emailEnviadoEm, criadoEm: n.criadoEm,
};

module.exports = { emitir, atualizar, reenviarEmail, atualizarPendentes, notaPublica };
