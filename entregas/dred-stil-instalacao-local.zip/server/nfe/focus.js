// Focus NFe (API v2) — emissão de NF-e modelo 55. Documentação: https://doc.focusnfe.com.br
// Emissão assíncrona: POST /v2/nfe?ref=REF responde 202 (processando) e a nota é consultada depois.
//
// CONFIRMAR COM O CONTADOR antes de produção: NCM de cada produto, CFOP (5102/6102),
// situação tributária de ICMS/PIS/COFINS (padrões para Simples Nacional abaixo) e natureza da operação.
// CONFIRMAR COM A FOCUS: como montar o link completo de caminho_danfe/caminho_xml_nota_fiscal
// (a API devolve caminhos relativos; usamos o domínio da própria API como base).

const HOSTS = { homologacao: 'https://homologacao.focusnfe.com.br', producao: 'https://api.focusnfe.com.br' };
const host = () => HOSTS[process.env.FOCUS_NFE_AMBIENTE === 'producao' ? 'producao' : 'homologacao'];

async function chamar(metodo, caminho, corpo) {
  const resposta = await fetch(`${host()}/v2${caminho}`, {
    method: metodo,
    headers: {
      Authorization: `Basic ${Buffer.from(`${process.env.FOCUS_NFE_TOKEN}:`).toString('base64')}`,
      'Content-Type': 'application/json',
    },
    body: corpo ? JSON.stringify(corpo) : undefined,
    signal: AbortSignal.timeout(20_000),
  });
  const json = await resposta.json().catch(() => ({}));
  return { status: resposta.status, json };
}

const linkCompleto = (caminho) => (caminho ? (/^https?:\/\//.test(caminho) ? caminho : `${host()}${caminho}`) : null);

// Resposta da Focus -> formato da loja.
function resultado(json) {
  const mapa = { processando_autorizacao: 'processando', autorizado: 'autorizada', cancelado: 'cancelada', erro_autorizacao: 'erro' };
  const status = mapa[json.status] || 'erro';
  return {
    status,
    numero: json.numero ? String(json.numero) : null,
    serie: json.serie ? String(json.serie) : null,
    chave: json.chave_nfe || null,
    urlDanfe: linkCompleto(json.caminho_danfe),
    urlXml: linkCompleto(json.caminho_xml_nota_fiscal),
    mensagem: status === 'erro' ? String(json.mensagem_sefaz || json.mensagem || 'Erro na autorização').slice(0, 500) : null,
  };
}

// Dados fiscais da loja (variáveis de ambiente) + pedido -> corpo da NF-e.
function montar(pedido, produtosPorHandle) {
  const uf = process.env.NFE_UF_EMITENTE.toUpperCase();
  const { cliente, endereco } = pedido.entrega;
  const interna = endereco.uf === uf;
  const icms = process.env.NFE_ICMS_SITUACAO || '102'; // Simples Nacional sem permissão de crédito
  const pisCofins = process.env.NFE_PIS_COFINS_SITUACAO || '07'; // operação isenta da contribuição
  const valorProdutos = pedido.itens.reduce((t, i) => t + i.preco * i.qtd, 0);
  return {
    natureza_operacao: process.env.NFE_NATUREZA_OPERACAO || 'Venda de mercadoria',
    data_emissao: new Date().toISOString(),
    tipo_documento: 1,
    finalidade_emissao: 1,
    local_destino: interna ? 1 : 2,
    consumidor_final: 1,
    presenca_comprador: 2, // operação pela internet
    modalidade_frete: pedido.frete > 0 ? 0 : 9,
    cnpj_emitente: process.env.NFE_CNPJ_EMITENTE.replace(/\D/g, ''),
    nome_destinatario: cliente.nome,
    cpf_destinatario: cliente.cpf,
    telefone_destinatario: cliente.telefone,
    indicador_inscricao_estadual_destinatario: 9,
    logradouro_destinatario: endereco.rua,
    numero_destinatario: endereco.numero,
    complemento_destinatario: endereco.complemento || undefined,
    bairro_destinatario: endereco.bairro,
    municipio_destinatario: endereco.cidade,
    uf_destinatario: endereco.uf,
    cep_destinatario: endereco.cep,
    pais_destinatario: 'Brasil',
    valor_frete: pedido.frete,
    valor_produtos: Math.round(valorProdutos * 100) / 100,
    valor_total: pedido.total,
    items: pedido.itens.map((i, n) => ({
      numero_item: n + 1,
      codigo_produto: i.handle,
      descricao: `${i.nome} - ${i.cor} / ${i.tamanho}`.slice(0, 120),
      cfop: interna ? '5102' : '6102',
      unidade_comercial: 'UN',
      quantidade_comercial: i.qtd,
      valor_unitario_comercial: i.preco,
      unidade_tributavel: 'UN',
      quantidade_tributavel: i.qtd,
      valor_unitario_tributavel: i.preco,
      valor_bruto: Math.round(i.preco * i.qtd * 100) / 100,
      codigo_ncm: produtosPorHandle[i.handle]?.codigoNcm || '61091000',
      icms_origem: 0,
      icms_situacao_tributaria: icms,
      pis_situacao_tributaria: pisCofins,
      cofins_situacao_tributaria: pisCofins,
    })),
  };
}

module.exports = {
  nome: 'focus',
  async emitir(ref, pedido, produtosPorHandle) {
    const r = await chamar('POST', `/nfe?ref=${encodeURIComponent(ref)}`, montar(pedido, produtosPorHandle));
    if (r.status === 202 || r.status === 201) return resultado(r.json);
    // Dados recusados pela Focus/SEFAZ: guarda a mensagem para o admin corrigir.
    const erros = Array.isArray(r.json.erros) ? r.json.erros.map((e) => e.mensagem).join('; ') : '';
    return { status: 'erro', mensagem: `${r.json.mensagem || `HTTP ${r.status}`}${erros ? `: ${erros}` : ''}`.slice(0, 500) };
  },
  async consultar(ref) {
    const r = await chamar('GET', `/nfe/${encodeURIComponent(ref)}`);
    if (r.status !== 200) throw new Error(`Focus NFe consulta HTTP ${r.status}`);
    return resultado(r.json);
  },
  // A Focus envia o DANFE e o XML para os e-mails (máx. 10 por pedido).
  async enviarEmail(ref, emails) {
    const r = await chamar('POST', `/nfe/${encodeURIComponent(ref)}/email`, { emails: emails.slice(0, 10) });
    if (r.status !== 200) throw new Error(`Focus NFe e-mail HTTP ${r.status}`);
  },
};
