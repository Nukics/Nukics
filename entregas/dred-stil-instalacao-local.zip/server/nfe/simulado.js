// Emissor falso para testes e demonstração local. Nunca é usado em produção (ver ambiente.js).
const notas = (globalThis.__notasSimuladas ??= new Map());
let numero = 1000;

module.exports = {
  nome: 'simulado',
  // Fica "processando" até ser consultada uma vez (imita a fila da SEFAZ).
  async emitir(ref, pedido) {
    notas.set(ref, { consultas: 0, numero: String(++numero), total: pedido.total, emails: [] });
    return { status: 'processando' };
  },
  async consultar(ref) {
    const n = notas.get(ref);
    if (!n) return { status: 'erro', mensagem: 'Nota não encontrada no emissor simulado.' };
    n.consultas++;
    return {
      status: 'autorizada',
      numero: n.numero,
      serie: '1',
      chave: `4126${ref.replace(/\D/g, '').padEnd(40, '0')}`.slice(0, 44),
      urlDanfe: `https://emissor.simulado/danfe/${encodeURIComponent(ref)}.pdf`,
      urlXml: `https://emissor.simulado/xml/${encodeURIComponent(ref)}.xml`,
      mensagem: null,
    };
  },
  async enviarEmail(ref, emails) {
    notas.get(ref)?.emails.push(...emails);
  },
  emailsEnviados: (ref) => notas.get(ref)?.emails || [],
};
