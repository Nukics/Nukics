// Cotação de frete por produto no Melhor Envio (POST /api/v2/me/shipment/calculate).
// Sempre calculada no servidor: o valor do frete nunca vem do navegador.
const { ErroHttp } = require('./http');
const { provedorFrete } = require('./ambiente');
const { tokenDeAcesso } = require('./melhor-envio');

const BASES = { sandbox: 'https://sandbox.melhorenvio.com.br', producao: 'https://melhorenvio.com.br' };

const reais = (v) => Math.round(Number.parseFloat(String(v)) * 100) / 100;

// As medidas cadastradas são de UMA peça dobrada. Junta as peças em volumes
// reais para não cobrar uma caixa por camiseta. Os limites são conservadores
// para continuar dentro do que as transportadoras aceitam normalmente.
function montarVolumes(itens) {
  const unidades = itens.flatMap(({ produto, qtd }) => Array.from({ length: qtd }, () => produto));
  const lotes = [];
  let lote = [];
  let peso = 0;
  let altura = 0;
  for (const produto of unidades) {
    const proximoPeso = peso + Number(produto.pesoKg);
    const proximaAltura = altura + Number(produto.alturaCm);
    if (lote.length && (proximoPeso > 30 || proximaAltura > 100)) {
      lotes.push(lote);
      lote = [];
      peso = 0;
      altura = 0;
    }
    lote.push(produto);
    peso += Number(produto.pesoKg);
    altura += Number(produto.alturaCm);
  }
  if (lote.length) lotes.push(lote);
  return lotes.map((pecas, indice) => ({
    id: `volume-${indice + 1}`,
    width: Math.max(...pecas.map((p) => Number(p.larguraCm))),
    height: Math.max(1, Math.ceil(pecas.reduce((t, p) => t + Number(p.alturaCm), 0))),
    length: Math.max(...pecas.map((p) => Number(p.comprimentoCm))),
    weight: reais(pecas.reduce((t, p) => t + Number(p.pesoKg), 0)),
    insurance_value: reais(pecas.reduce((t, p) => t + Number(p.preco), 0)),
    quantity: 1,
  }));
}

// itens: [{ produto, qtd }] com produto vindo do banco (preço e embalagem)
async function cotar(cepDestino, itens) {
  const provedor = provedorFrete();
  if (!provedor) throw new ErroHttp(503, 'Cálculo de frete indisponível no momento.');
  if (provedor === 'simulado') return simulado(itens);

  const resposta = await fetch(`${BASES[process.env.MELHOR_ENVIO_AMBIENTE === 'producao' ? 'producao' : 'sandbox']}/api/v2/me/shipment/calculate`, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${await tokenDeAcesso()}`,
      'User-Agent': process.env.MELHOR_ENVIO_USER_AGENT || 'Dred Stil (contato@dredstil.com.br)',
    },
    body: JSON.stringify({
      from: { postal_code: process.env.MELHOR_ENVIO_CEP_ORIGEM },
      to: { postal_code: cepDestino },
      products: montarVolumes(itens),
      options: { receipt: false, own_hand: false },
    }),
    signal: AbortSignal.timeout(10_000),
  });
  if (resposta.status === 422) throw new ErroHttp(422, 'Não foi possível calcular o frete para esse CEP.');
  if (!resposta.ok) throw new Error(`Melhor Envio respondeu HTTP ${resposta.status}`);
  const lista = await resposta.json();
  const opcoes = (Array.isArray(lista) ? lista : [])
    .filter((o) => !o.error && (o.custom_price ?? o.price) != null)
    .map((o) => ({
      id: String(o.id),
      nome: `${o.company?.name || ''} ${o.name || 'Entrega'}`.trim(),
      preco: reais(o.custom_price ?? o.price),
      prazoDias: Number.isFinite(Number(o.custom_delivery_time)) ? Number(o.custom_delivery_time) : null,
    }))
    .filter((o) => Number.isFinite(o.preco) && o.preco >= 0)
    .sort((a, b) => a.preco - b.preco);
  if (!opcoes.length) throw new ErroHttp(422, 'Nenhuma opção de entrega para esse CEP.');
  return opcoes;
}

// Só fora de produção, sem token do Melhor Envio.
function simulado(itens) {
  const peso = itens.reduce((t, { produto, qtd }) => t + produto.pesoKg * qtd, 0);
  return [
    { id: '1', nome: 'Correios PAC (simulado)', preco: reais(18.9 + peso * 4), prazoDias: 8 },
    { id: '2', nome: 'Correios SEDEX (simulado)', preco: reais(32.9 + peso * 7), prazoDias: 3 },
  ];
}

module.exports = { cotar, montarVolumes };
