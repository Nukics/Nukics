// Converte o texto das páginas editado no admin em HTML seguro.
// Formato (separe os blocos com uma linha em branco):
//   ## Subtítulo
//   - item de lista        1. item numerado
//   **negrito**            [texto do link](/endereco)
// Qualquer outra coisa vira parágrafo; quebras de linha simples são mantidas.
function esc(valor) {
  return String(valor ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

// Negrito e links (só internos, começando com /, ou https://).
function emLinha(texto) {
  return esc(texto)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\(((?:\/(?!\/)|https:\/\/)[^\s)]*)\)/g, (_, rotulo, href) => {
      const externo = href.startsWith('https://');
      return `<a href="${href}"${externo ? ' target="_blank" rel="noopener noreferrer"' : ''}>${rotulo}</a>`;
    });
}

function bloco(linhas) {
  if (linhas[0].startsWith('## ')) {
    const titulo = `<h2>${emLinha(linhas[0].slice(3))}</h2>`;
    return linhas.length > 1 ? titulo + bloco(linhas.slice(1)) : titulo;
  }
  if (linhas.every((l) => l.startsWith('- '))) return `<ul>${linhas.map((l) => `<li>${emLinha(l.slice(2))}</li>`).join('')}</ul>`;
  if (linhas.every((l) => /^\d+\. /.test(l))) return `<ol>${linhas.map((l) => `<li>${emLinha(l.replace(/^\d+\. /, ''))}</li>`).join('')}</ol>`;
  return `<p>${linhas.map(emLinha).join('<br>')}</p>`;
}

function textoParaHtml(texto) {
  return String(texto || '')
    .replace(/\r/g, '')
    .split(/\n\s*\n/)
    .map((b) => b.split('\n').map((l) => l.trim()).filter(Boolean))
    .filter((linhas) => linhas.length)
    .map(bloco)
    .join('\n');
}

module.exports = { textoParaHtml, esc };
