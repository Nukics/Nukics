// Configuração lida das variáveis de ambiente (veja .env.example).
// Regra: em produção nada é simulado; o que não estiver configurado fica desligado.
const EM_PRODUCAO = process.env.NODE_ENV === 'production';

// Endereço público do site, usado nos links dos e-mails.
function urlSite() {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/+$/, '');
  if (process.env.VERCEL_PROJECT_PRODUCTION_URL) return `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`;
  return `http://localhost:${process.env.PORT || 5173}`;
}

// 'getnet', 'simulado' (só fora de produção) ou null (checkout desligado: segue o fluxo pelo WhatsApp).
function provedorPagamento() {
  const escolhido = process.env.PAGAMENTO_PROVEDOR;
  if (escolhido === 'getnet-global') return require('./pagamento/getnet-global').configurado() ? 'getnet-global' : null;
  if (escolhido === 'getnet') {
    const ok = process.env.GETNET_CLIENT_ID && process.env.GETNET_CLIENT_SECRET && process.env.GETNET_SELLER_ID && process.env.GETNET_WEBHOOK_TOKEN;
    return ok ? 'getnet' : null;
  }
  if (escolhido === 'simulado' && !EM_PRODUCAO) return 'simulado';
  return null;
}

// Frete real (Melhor Envio), simulado (só fora de produção) ou null.
function provedorFrete() {
  const acessoDireto = process.env.MELHOR_ENVIO_TOKEN;
  const oauth = process.env.MELHOR_ENVIO_CLIENT_ID && process.env.MELHOR_ENVIO_CLIENT_SECRET;
  if (process.env.MELHOR_ENVIO_CEP_ORIGEM && (acessoDireto || oauth)) return 'melhor-envio';
  return EM_PRODUCAO ? null : 'simulado';
}

// Emissor de nota fiscal: 'focus' (Focus NFe), 'simulado' (só fora de produção) ou null (botão desligado).
function provedorNfe() {
  if (process.env.FOCUS_NFE_TOKEN && process.env.NFE_CNPJ_EMITENTE && process.env.NFE_UF_EMITENTE) return 'focus';
  if (process.env.NFE_PROVEDOR === 'simulado' && !EM_PRODUCAO) return 'simulado';
  return null;
}

// O checkout só liga com pagamento e frete configurados.
const checkoutAtivo = () => Boolean(provedorPagamento() && provedorFrete());

// E-mail disponível (em produção, só com Resend configurado).
const emailAtivo = () => Boolean(process.env.RESEND_API_KEY) || !EM_PRODUCAO;

// A verificação em duas etapas do admin depende de e-mail. Enquanto o envio não estiver
// configurado em produção ela não é exigida (senão o admin ficaria trancado para fora).
const exigir2faAdmin = () => emailAtivo();

module.exports = { EM_PRODUCAO, urlSite, provedorPagamento, provedorFrete, provedorNfe, checkoutAtivo, emailAtivo, exigir2faAdmin };
