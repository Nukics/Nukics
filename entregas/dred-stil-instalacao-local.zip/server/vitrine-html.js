// HTML da vitrine gerado no servidor: a página já chega pronta (rápida e legível pelo Google)
// e o JavaScript do navegador assume depois com a MESMA marcação (sem "pulo" na tela).
// Espelha public/js/cartao.js, public/js/catalogo.js e public/js/paginas/produto.js:
// ao mudar a marcação lá, mude aqui também.
const { esc } = require('./texto');

const brl = (v) => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const urlProduto = (handle, cor) => `/produto/${encodeURIComponent(handle)}${cor ? `?cor=${encodeURIComponent(cor)}` : ''}`;
const CORACAO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/></svg>';

function htmlPreco(produto, parcelas) {
  if (!produto.preco) return '<div class="preco"><strong>Preço sob consulta</strong></div>';
  const promo = produto.precoDe > produto.preco;
  return '<div class="preco">' +
    (promo ? `<s>${brl(produto.precoDe)}</s>` : '') +
    `<strong>${brl(produto.preco)}</strong>` +
    (produto.atacado || produto.categoria === 'atacado' ? '<span class="preco__atacado">Preço de atacado · desconto por quantidade</span>' : '') +
    (parcelas > 1 ? `<span class="preco__parcelas">em até ${parcelas}x de ${brl(produto.preco / parcelas)} sem juros</span>` : '') +
    '</div>';
}

const desconto = (p) => (p.precoDe > p.preco && p.preco ? Math.round((1 - p.preco / p.precoDe) * 100) : 0);

// Sem usuário no servidor: o estado "curtido" é aplicado no navegador depois.
const botaoCurtir = (p) =>
  `<button type="button" class="curtir" data-curtir="${esc(p.handle)}" aria-pressed="false" aria-label="Curtir ${esc(p.nome)}">` +
  `${CORACAO}<span data-total>${p.curtidas || 0}</span></button>`;

function cartaoProduto(produto, parcelas) {
  const cor = produto.cores[0];
  const off = desconto(produto);
  const url = urlProduto(produto.handle, cor.nome);
  const fotos = cor.imagens.slice(0, 2)
    .map((src, i) => `<img ${i ? `data-foto-alternativa="${esc(src)}"` : `src="${esc(src)}"`} alt="${i ? '' : esc(`${produto.nome} — ${cor.nome}`)}" loading="lazy" decoding="async">`).join('');
  const cores = produto.cores.length > 1
    ? `<div class="cartao__cores">${produto.cores.map((c, i) =>
      `<button type="button" class="cor" style="--c:${esc(c.hex)}" aria-label="Cor ${esc(c.nome)}" aria-pressed="${i === 0}" data-cor-cartao="${esc(c.nome)}"></button>`).join('')}</div>`
    : '';
  const selo = produto.esgotado
    ? '<span class="cartao__selo cartao__selo--esgotado">Esgotado</span>'
    : off ? `<span class="cartao__selo">-${off}%</span>` : '';
  return `<article class="cartao" data-handle="${esc(produto.handle)}">
    <a class="cartao__midia" href="${url}" tabindex="-1" aria-hidden="true">${fotos}</a>
    ${selo}
    ${botaoCurtir(produto)}
    ${cores}
    <h3 class="cartao__nome"><a href="${url}">${esc(produto.nome)}</a></h3>
    ${htmlPreco(produto, parcelas)}
  </article>`;
}

/* ---------------- página inicial: destaques ---------------- */
function htmlDestaques({ destaques, produtos, parcelas }) {
  const abas = destaques
    .map((aba) => ({ nome: aba.nome, produtos: aba.produtos.map((h) => produtos.find((p) => p.handle === h)).filter(Boolean) }))
    .filter((aba) => aba.produtos.length);
  if (!abas.length) return { abas: '', grade: '', vazio: true };
  return {
    abas: abas.map((aba, i) =>
      `<button type="button" role="tab" id="aba-destaque-${i}" aria-controls="grade-destaques" aria-selected="${i === 0}" data-aba="${i}">${esc(aba.nome)}</button>`).join(''),
    grade: abas[0].produtos.map((p) => cartaoProduto(p, parcelas)).join(''),
    vazio: false,
  };
}

/* ---------------- catálogo (estado inicial: todos, mais recentes) ---------------- */
const POR_PAGINA = 12;
const ORDENS = [['recentes', 'Mais recentes'], ['curtidos', 'Mais curtidos'], ['menor-preco', 'Menor preço'], ['maior-preco', 'Maior preço']];
const chip = (slug, rotulo, ativo) => `<button type="button" data-categoria="${esc(slug)}" aria-pressed="${ativo}">${esc(rotulo)}</button>`;

function htmlCatalogo({ produtos, categorias, parcelas, completo = false, categoriaInicial = '', categoriaFixa = '' }) {
  const aceitas = new Set([categoriaInicial, ...categorias.filter((c) => c.pai === categoriaInicial).map((c) => c.slug)]);
  const lista = produtos.filter((p) => !categoriaInicial || aceitas.has(p.categoria)).sort((a, b) => String(b.criadoEm).localeCompare(String(a.criadoEm)));
  const principais = categoriaFixa ? [{ slug: categoriaFixa, nome: 'Todos do atacado' }] : categorias.filter((c) => !c.pai);
  return `
    ${completo ? `<form class="catalogo__busca" role="search" data-busca>
      <input type="search" name="q" placeholder="Buscar no catálogo" aria-label="Buscar no catálogo" maxlength="80" value="">
      <button class="botao" type="submit">Buscar</button>
    </form>` : ''}
    <div class="catalogo__barra" data-estado-catalogo="${esc(JSON.stringify({ categoria: categoriaInicial, termo: '', ordem: 'recentes' }))}">
      <div class="catalogo__filtros">
        <div class="chips" role="group" aria-label="Filtrar por categoria">
          ${categoriaFixa ? '' : chip('', 'Todos', !categoriaInicial)}${principais.map((c) => chip(c.slug, c.nome, c.slug === categoriaInicial)).join('')}
        </div>
        <div class="chips chips--sub" role="group" aria-label="Filtrar por subcategoria" data-subcategorias hidden></div>
      </div>
      <div class="catalogo__ferramentas">
        <p class="catalogo__total" aria-live="polite" data-total>${lista.length} ${lista.length === 1 ? 'produto' : 'produtos'}</p>
        <select class="catalogo__ordem" aria-label="Ordenar produtos" data-ordem>
          ${ORDENS.map(([valor, rotulo]) => `<option value="${valor}"${valor === 'recentes' ? ' selected' : ''}>${rotulo}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="atacado__aviso" data-aviso-atacado${categoriaInicial === 'atacado' && !categoriaFixa ? '' : ' hidden'}><strong>Descontos na categoria Atacado</strong><p>Combine peças e tenha até 30% de desconto por quantidade.</p><a href="/atacado">Ver tabela de preços de atacado</a></div>
    <div class="grade" data-grade>${lista.slice(0, POR_PAGINA).map((p) => cartaoProduto(p, parcelas)).join('')}</div>
    <p class="vazio" data-vazio${lista.length ? ' hidden' : ''}>Nenhum produto encontrado.</p>
    <div class="catalogo__mais"><button class="botao botao--sec" type="button" data-mais${lista.length > POR_PAGINA ? '' : ' hidden'}>Ver mais</button></div>`;
}

/* ---------------- página de produto ---------------- */
function trilhaCategoria(categorias, slug) {
  const categoria = categorias.find((c) => c.slug === slug);
  if (!categoria) return '';
  const pai = categoria.pai && categorias.find((c) => c.slug === categoria.pai);
  const link = (c) => `<a href="/catalogo?categoria=${encodeURIComponent(c.slug)}">${esc(c.nome)}</a> / `;
  return (pai ? link(pai) : '') + link(categoria);
}

function htmlProduto(produto, { categorias, parcelas, corNome }) {
  const cor = produto.cores.find((c) => c.nome === corNome) || produto.cores[0];
  const corEsgotada = (c) => Boolean(c.esgotado ?? produto.esgotado);
  const tamanho = produto.tamanhos.length === 1 ? produto.tamanhos[0] : null;
  const off = desconto(produto);
  return `
    <div class="produto">
      <nav class="trilha" aria-label="Você está em">
        <a href="/">Início</a> / ${trilhaCategoria(categorias, produto.categoria)}<span aria-current="page">${esc(produto.nome)}</span>
      </nav>
      <div class="produto__grade">
        <div>
          <div class="produto__principal"><img alt="${esc(`${produto.nome} — ${cor.nome}`)}" src="${esc(cor.imagens[0])}" fetchpriority="high" data-foto-principal>${botaoCurtir(produto)}</div>
          <div class="produto__miniaturas" data-miniaturas>${cor.imagens.map((src, i) =>
            `<button type="button" aria-label="Ver foto ${i + 1}" data-foto="${i}" aria-current="${i === 0}"><img src="${esc(src)}" alt=""></button>`).join('')}</div>
        </div>
        <div class="produto__info">
          <h1 class="produto__nome">${esc(produto.nome)}</h1>
          ${produto.atacado || produto.categoria === 'atacado' ? '<div class="atacado__aviso"><strong>Esta peça participa do preço de atacado.</strong><p>O desconto considera todas as peças de Atacado do carrinho.</p><a href="/atacado">Consultar descontos por quantidade</a></div>' : ''}
          <div class="preco-linha">${htmlPreco(produto, parcelas)}${off ? `<span class="produto__desconto">-${off}%</span>` : ''}</div>
          <div>
            <p class="opcao__rotulo">Cor: <strong data-nome-cor>${esc(cor.nome)}</strong></p>
            <div class="opcao__lista" data-cores>${produto.cores.map((c) =>
              `<button type="button" class="cor" style="--c:${esc(c.hex)}" aria-label="${esc(c.nome)}${corEsgotada(c) ? ' — esgotado' : ''}" title="${esc(c.nome)}${corEsgotada(c) ? ' — esgotado' : ''}" data-cor="${esc(c.nome)}" data-esgotado="${corEsgotada(c)}" aria-pressed="${c === cor}"></button>`).join('')}</div>
          </div>
          <div>
            <p class="opcao__rotulo">Tamanho: <strong data-nome-tamanho>${esc(tamanho || 'selecione')}</strong></p>
            <div class="opcao__lista" data-tamanhos>${produto.tamanhos.map((t) =>
              `<button type="button" class="tamanho" data-tamanho="${esc(t)}" aria-pressed="${t === tamanho}">${esc(t)}</button>`).join('')}</div>
            <p class="erro-form" role="alert" data-erro-tamanho hidden>Selecione um tamanho.</p>
          </div>
          <div class="produto__comprar">
            <div class="qtd qtd--grande">
              <button type="button" aria-label="Diminuir quantidade" data-mudar-qtd="-1">−</button>
              <span data-qtd>1</span>
              <button type="button" aria-label="Aumentar quantidade" data-mudar-qtd="1">+</button>
            </div>
            <button type="button" class="botao" data-adicionar${corEsgotada(cor) ? ' disabled' : ''}>${corEsgotada(cor) ? 'Cor esgotada' : 'Adicionar ao carrinho'}</button>
          </div>
          <p class="produto__esgotado" data-disponibilidade aria-live="polite"${corEsgotada(cor) ? '' : ' hidden'}>Esta cor está esgotada no momento. Fale com a loja pelo WhatsApp para saber quando volta.</p>
          <button type="button" class="botao botao--sec botao--largo" data-comprar${corEsgotada(cor) ? ' disabled' : ''}>Comprar agora</button>
          <ul class="selos"><li>Compra segura</li><li>Troca garantida</li>${parcelas > 1 ? `<li>Parcele em até ${parcelas}x sem juros</li>` : ''}</ul>
          ${produto.descricao ? `<details class="produto__desc" open><summary>Descrição</summary><p>${esc(produto.descricao)}</p></details>` : ''}
        </div>
      </div>
    </div>`;
}

module.exports = { htmlDestaques, htmlCatalogo, htmlProduto, urlProduto };
