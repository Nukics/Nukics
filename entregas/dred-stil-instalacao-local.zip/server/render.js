// Monta as páginas: um único layout (cabeçalho, rodapé, barra mobile) em volta
// do conteúdo de cada página em views/. Assim o rodapé, o menu e o botão
// "Início" são idênticos em todo o site.
const fs = require('fs');
const path = require('path');
const publico = require('./publico');
const { dimensoes } = require('./imagens');
const { urlSite } = require('./ambiente');
const { esc } = require('./texto');
const { menuParaExibir } = require('./vitrine');

const VIEWS = path.join(__dirname, '..', 'views');
const EM_PRODUCAO = process.env.NODE_ENV === 'production';
const cacheViews = new Map();

function view(nome) {
  if (!EM_PRODUCAO || !cacheViews.has(nome)) cacheViews.set(nome, fs.readFileSync(path.join(VIEWS, nome + '.html'), 'utf8'));
  return cacheViews.get(nome);
}

// {{campo}} é escapado; {{{campo}}} entra como HTML já montado.
// Uma passada só, para não reprocessar o que acabou de ser inserido.
function preencher(modelo, dados) {
  return modelo.replace(/\{\{\{(\w+)\}\}\}|\{\{(\w+)\}\}/g, (_, html, textoPuro) => (html ? dados[html] ?? '' : esc(dados[textoPuro])));
}

const REDES = {
  instagram: ['Instagram', '<path d="M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0 8.2a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4ZM17.3 5.5a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4ZM12 2c-2.7 0-3.1 0-4.1.1-4 .2-5.6 1.8-5.8 5.8C2 8.9 2 9.3 2 12s0 3.1.1 4.1c.2 4 1.8 5.6 5.8 5.8 1 .1 1.4.1 4.1.1s3.1 0 4.1-.1c4-.2 5.6-1.8 5.8-5.8.1-1 .1-1.4.1-4.1s0-3.1-.1-4.1c-.2-4-1.8-5.6-5.8-5.8C15.1 2 14.7 2 12 2Zm0 1.8c2.7 0 3 0 4 .1 2.8.1 3.9 1.3 4 4 .1 1 .1 1.3.1 4s0 3-.1 4c-.1 2.7-1.2 3.9-4 4-1 .1-1.3.1-4 .1s-3 0-4-.1c-2.8-.1-3.9-1.3-4-4-.1-1-.1-1.3-.1-4s0-3 .1-4c.1-2.7 1.2-3.9 4-4 1-.1 1.3-.1 4-.1Z"/>'],
  facebook: ['Facebook', '<path d="M13.5 22v-8.2h2.8l.4-3.2h-3.2V8.6c0-.9.3-1.6 1.6-1.6h1.7V4.1c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.3H7.3v3.2h2.8V22h3.4Z"/>'],
  tiktok: ['TikTok', '<path d="M16.6 2h-3.3v13.4a2.9 2.9 0 1 1-2.9-2.9c.3 0 .6 0 .9.1V9.2a6.3 6.3 0 1 0 5.3 6.2V8.6a7.9 7.9 0 0 0 4.4 1.3V6.6a4.5 4.5 0 0 1-4.4-4.6Z"/>'],
  youtube: ['YouTube', '<path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4a2.5 2.5 0 0 0-1.8 1.8C2 8.8 2 12 2 12s0 3.2.4 4.8a2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8c.4-1.6.4-4.8.4-4.8s0-3.2-.4-4.8ZM10 15V9l5.2 3L10 15Z"/>'],
};

function htmlRedes(redes = {}) {
  return Object.entries(REDES)
    .filter(([chave]) => redes[chave])
    .map(([chave, [nome, icone]]) =>
      `<li><a href="${esc(redes[chave])}" target="_blank" rel="noopener noreferrer" aria-label="${nome} da Dred Stil"><svg viewBox="0 0 24 24" aria-hidden="true">${icone}</svg></a></li>`)
    .join('');
}

const SETA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';

// Menu principal (configurado no admin). Itens com categorias ganham submenu:
// abre ao passar o mouse no computador e pela setinha no celular.
function htmlMenu(itens, caminhoAtual, categoriaAtual) {
  const ehAtual = (item) =>
    item.categoria ? item.categoria === categoriaAtual || item.href === caminhoAtual : !categoriaAtual && item.href.split('?')[0] === caminhoAtual;
  const link = (item) => `<a href="${esc(item.href)}"${ehAtual(item) ? ' aria-current="page"' : ''}>${esc(item.rotulo)}</a>`;
  const lista = (filhos) =>
    filhos.map((f) => `<li>${link(f)}${f.filhos?.length ? `<ul class="submenu__sub">${lista(f.filhos)}</ul>` : ''}</li>`).join('');

  return itens
    .map((item) => {
      if (!item.filhos?.length) return `<li>${link(item)}</li>`;
      return `<li class="menu__item--sub">${link(item)}` +
        `<button type="button" class="menu__seta" aria-expanded="false" aria-label="Mostrar opções de ${esc(item.rotulo)}" data-submenu>${SETA}</button>` +
        `<ul class="submenu">${lista(item.filhos)}</ul></li>`;
    })
    .join('');
}

function htmlFaq(perguntas) {
  return perguntas
    .map((p) => `<details class="faq__item"><summary>${esc(p.pergunta)}</summary><p>${esc(p.resposta).replace(/\n/g, '<br>')}</p></details>`)
    .join('');
}

// Com largura/altura no <img>, o espaço do banner fica reservado antes da imagem chegar.
async function htmlBanners(banners = []) {
  // A proporção é reservada pelo CSS. Não atrasar o HTML com consultas HTTP ao Storage.
  const medidas = await Promise.all(banners.map((b) => b.largura && b.altura
    ? { largura: b.largura, altura: b.altura }
    : b.imagem.startsWith('/img/') ? dimensoes(b.imagem) : null));
  return banners
    .map((b, i) => {
      const m = medidas[i];
      const tamanho = m ? ` width="${m.largura}" height="${m.altura}"` : ' width="1800" height="600"';
      const focoX = Number.isFinite(Number(b.focoX)) ? Number(b.focoX) : 50;
      const focoY = Number.isFinite(Number(b.focoY)) ? Number(b.focoY) : 50;
      const zoom = Math.max(100, Math.min(180, Number(b.zoom) || 100)) / 100;
      const mx = Math.max(0, Math.min(100, Number(b.focoMobileX ?? focoX)));
      const my = Math.max(0, Math.min(100, Number(b.focoMobileY ?? focoY)));
      const mz = Math.max(100, Math.min(180, Number(b.zoomMobile ?? b.zoom) || 100)) / 100;
      const estilo = `--banner-x:${focoX}%;--banner-y:${focoY}%;--banner-zoom:${zoom};--banner-mx:${mx}%;--banner-my:${my}%;--banner-mzoom:${mz}`;
      const img = `<img src="${esc(b.imagem)}" alt="${esc(b.alt)}" decoding="async"${tamanho} ${i ? 'loading="lazy"' : 'loading="eager" fetchpriority="high"'}>`;
      return `<div class="banners__slide${i ? '' : ' is-ativo'}" style="${estilo}">${b.link ? `<a href="${esc(b.link)}">${img}</a>` : img}</div>`;
    })
    .join('');
}

// JSON dentro de <script>: escapa "<" para nenhum texto conseguir fechar a tag (XSS).
// U+2028 e U+2029 (separadores de linha) também são escapados.
const SEPARADORES = new RegExp('[' + String.fromCharCode(0x2028, 0x2029) + ']', 'g');
const jsonSeguro = (dados) => JSON.stringify(dados).replace(/</g, '\\u003c').replace(SEPARADORES, (c) => '\\u' + c.charCodeAt(0).toString(16));

// Tags de SEO e compartilhamento: canonical, Open Graph, Twitter e dados estruturados (JSON-LD).
function htmlCabecalho({ titulo, descricao, caminho, imagem, tipo = 'website', jsonLd = [], indexar = true }) {
  const base = urlSite();
  const absoluta = (u) => (u && u.startsWith('/') ? base + u : u);
  return [
    indexar ? `<link rel="canonical" href="${esc(base + caminho)}">` : '<meta name="robots" content="noindex, nofollow">',
    `<meta property="og:site_name" content="Dred Stil">`,
    `<meta property="og:locale" content="pt_BR">`,
    `<meta property="og:type" content="${esc(tipo)}">`,
    `<meta property="og:title" content="${esc(titulo)}">`,
    `<meta property="og:description" content="${esc(descricao)}">`,
    `<meta property="og:url" content="${esc(base + caminho)}">`,
    imagem ? `<meta property="og:image" content="${esc(absoluta(imagem))}">` : '',
    `<meta name="twitter:card" content="${imagem ? 'summary_large_image' : 'summary'}">`,
    ...jsonLd.map((d) => `<script type="application/ld+json">${jsonSeguro(d)}</script>`),
  ].filter(Boolean).join('');
}

// Faixa preta com a mensagem rolando, logo abaixo do banner da página inicial.
function htmlPromo(mensagem) {
  if (!mensagem) return '';
  const item = `<span>${esc(mensagem)}</span>`;
  return `<div class="promo"><p class="so-leitor">${esc(mensagem)}</p><div class="promo__trilho" aria-hidden="true">${item.repeat(8)}</div></div>`;
}

// Versão dos arquivos estáticos: muda a cada deploy (o navegador pode guardar o CSS por muito tempo).
const VERSAO = (process.env.VERCEL_DEPLOYMENT_ID || process.env.VERCEL_GIT_COMMIT_SHA || String(Date.now())).slice(-12);
const CACHE_PUBLICO = 'public, max-age=0, s-maxage=60, must-revalidate';

/**
 * Renderiza views/<nome>.html dentro do layout.
 * opcoes: titulo, descricao, pagina (módulo JS da página), dados (para a view), url, status,
 *   publica (página igual para todos: a CDN guarda), seo ({ imagem, tipo, jsonLd, indexar }), loja (dados embutidos)
 * O HTML não depende de quem está logado (o link Admin é colocado pelo navegador).
 */
async function renderizar(res, nome, { titulo, descricao, pagina = '', dados = {}, url, status = 200, publica = false, seo = {}, loja = null }) {
  const [config, menu, categorias, paginas] = await Promise.all([publico.config(), publico.menu(), publico.categorias(), publico.paginas()]);
  const itensMenu = menuParaExibir(menu, categorias, paginas);
  const tituloCompleto = titulo ? `${titulo} | Dred Stil` : 'Dred Stil — Street Style';
  const descricaoFinal = descricao || 'Dred Stil Street Style: moda feminina e masculina. Loja em Pinhais/PR.';
  const html = preencher(view('layout'), {
    titulo: tituloCompleto,
    descricao: descricaoFinal,
    versao: VERSAO,
    cabecalho: htmlCabecalho({ titulo: tituloCompleto, descricao: descricaoFinal, caminho: url.pathname, indexar: publica && status === 200, ...seo }),
    dadosLoja: loja ? `<script type="application/json" id="dados-loja">${jsonSeguro(loja)}</script>` : '',
    pagina,
    menu: htmlMenu(itensMenu, url.pathname, url.searchParams.get('categoria')),
    redes: htmlRedes(config.redesSociais),
    whatsapp: config.whatsapp,
    telefone: config.telefone,
    telefoneLink: (config.telefone || '').replace(/\D/g, ''),
    ano: new Date().getFullYear(),
    conteudo: preencher(view(nome), dados),
  });
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': publica ? CACHE_PUBLICO : 'no-store' });
  res.end(html);
}

module.exports = { renderizar, htmlFaq, htmlBanners, htmlPromo, jsonSeguro };
