// Checkout (Pix), frete, acompanhamento do pedido, notificação da Getnet e tarefa de expiração.
const db = require('../db');
const validar = require('../validar');
const pedidos = require('../pedidos');
const nfe = require('../nfe');
const { ErroHttp, lerJson, ipDe } = require('../http');
const { limitar, MINUTO } = require('../limites');
const { iguais } = require('../cripto');
const { EM_PRODUCAO, checkoutAtivo } = require('../ambiente');

function exigirCheckout() {
  if (!checkoutAtivo()) throw new ErroHttp(503, 'Pagamento online indisponível no momento. Finalize pelo WhatsApp.');
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

module.exports = [
  {
    metodo: 'POST',
    caminho: '/api/frete',
    acao: async ({ req }) => {
      exigirCheckout();
      await limitar(`frete:ip:${ipDe(req)}`, 30, 10 * MINUTO);
      const { cep, itens } = validar.cotacao(await lerJson(req));
      return { opcoes: await pedidos.cotarFrete(cep, await pedidos.conferirItens(itens)) };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/checkout',
    acesso: 'cliente',
    acao: async ({ req, usuario }) => {
      exigirCheckout();
      await limitar(`checkout:${usuario.id}`, 10, 15 * MINUTO);
      const dados = validar.checkout(await lerJson(req));
      const pedido = await pedidos.criarCheckout(usuario, dados);
      return { pedido };
    },
  },
  {
    // Só o dono vê o pedido (o id de outra pessoa responde como inexistente).
    metodo: 'GET',
    caminho: '/api/pedidos/:id',
    acesso: 'cliente',
    acao: async ({ params, usuario }) => {
      if (!UUID.test(params.id)) throw new ErroHttp(404, 'Pedido não encontrado.');
      const pedido = await db.pedidos.doUsuarioPorId(usuario.id, params.id);
      if (!pedido) throw new ErroHttp(404, 'Pedido não encontrado.');
      return { pedido };
    },
  },
  ...['POST', 'GET'].map((metodo) => ({
    // Notificação da Getnet. Protegida por segredo na URL; o conteúdo não é confiável:
    // só o id do pagamento é usado, e o status é consultado na própria Getnet.
    metodo,
    caminho: '/api/webhooks/getnet',
    acao: async ({ req, url }) => {
      const esperado = process.env.GETNET_WEBHOOK_TOKEN;
      if (!esperado || !iguais(url.searchParams.get('token') || '', esperado)) throw new ErroHttp(401, 'Não autorizado.');
      await limitar(`webhook:ip:${ipDe(req)}`, 300, MINUTO);
      let pagamentoId = url.searchParams.get('payment_id');
      if (!pagamentoId && metodo === 'POST') pagamentoId = (await lerJson(req).catch(() => ({}))).payment_id;
      if (typeof pagamentoId !== 'string' || !/^[\w-]{6,80}$/.test(pagamentoId)) throw new ErroHttp(400, 'payment_id ausente.');
      return { resultado: await pedidos.confirmarPagamento(pagamentoId) };
    },
  })),
  {
    metodo: 'POST',
    caminho: '/api/pedidos/:id/consultar-pagamento',
    acesso: 'cliente',
    acao: async ({ req, params, usuario }) => {
      if (!UUID.test(params.id)) throw new ErroHttp(404, 'Pedido não encontrado.');
      const pedido = await db.pedidos.doUsuarioPorId(usuario.id, params.id);
      if (!pedido) throw new ErroHttp(404, 'Pedido não encontrado.');
      await limitar(`consulta-pagamento:${usuario.id}`, 12, MINUTO);
      if (pedido.pagamentoMetodo === 'getnet-checkout' && pedido.pagamentoId && ['aguardando', 'expirado', 'cancelado'].includes(pedido.status)) {
        await pedidos.confirmarPagamentoGlobal(pedido.pagamentoId);
      }
      return { pedido: await db.pedidos.doUsuarioPorId(usuario.id, pedido.id) };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/webhooks/getnet-global',
    acao: async ({ req }) => {
      const user = process.env.GETNET_GLOBAL_WEBHOOK_USER;
      const password = process.env.GETNET_GLOBAL_WEBHOOK_PASSWORD;
      const esperado = `Basic ${Buffer.from(`${user}:${password}`).toString('base64')}`;
      if (!user || !password || !iguais(req.headers.authorization || '', esperado)) throw new ErroHttp(401, 'Não autorizado.');
      await limitar(`webhook-global:ip:${ipDe(req)}`, 300, MINUTO);
      const aviso = (await lerJson(req)) || {};
      if (!UUID.test(aviso.payment_intent_id || '') || !UUID.test(aviso.order_id || '')) throw new ErroHttp(400, 'Notificação inválida.');
      const pedido = await db.pedidos.porPagamentoId(aviso.payment_intent_id);
      if (!pedido) {
        // Uma notificação pode chegar durante a persistência inicial. Solicitar retentativa.
        const emCriacao = await db.pedidos.porId(aviso.order_id);
        if (emCriacao?.pagamentoMetodo === 'getnet-checkout' && !emCriacao.pagamentoId) throw new ErroHttp(503, 'Pagamento em conciliação.');
        return { resultado: 'ignorado' };
      }
      if (pedido.id !== aviso.order_id || aviso.seller?.id !== process.env.GETNET_GLOBAL_SELLER_ID) throw new ErroHttp(400, 'Referência inválida.');
      // Ignorar status/valor do aviso. Consultar o recurso autenticado e validar pedido, seller e moeda.
      return { resultado: await pedidos.confirmarPagamentoGlobal(aviso.payment_intent_id) };
    },
  },
  {
    // Vercel Cron envia "Authorization: Bearer <CRON_SECRET>".
    metodo: 'GET',
    caminho: '/api/cron/expirar-pedidos',
    acao: async ({ req }) => {
      const segredo = process.env.CRON_SECRET;
      if (!segredo || !iguais(req.headers.authorization || '', `Bearer ${segredo}`)) throw new ErroHttp(401, 'Não autorizado.');
      const expirados = checkoutAtivo() ? await pedidos.expirarVencidos() : 0;
      return { expirados, notasAtualizadas: await nfe.atualizarPendentes() };
    },
  },
  {
    // Só em desenvolvimento: simula o pagamento do Pix no provedor falso.
    metodo: 'POST',
    caminho: '/api/dev/pagar-pix',
    acao: async ({ req }) => {
      if (EM_PRODUCAO) throw new ErroHttp(404, 'Rota não encontrada.');
      const { pagamentoId, status } = await lerJson(req);
      if (!/^sim_[\w-]+$/.test(String(pagamentoId)) || !['aprovado', 'negado'].includes(status)) throw new ErroHttp(400, 'Dados inválidos.');
      require('../pagamento/simulado').definirStatus(pagamentoId, status);
      return { resultado: await pedidos.confirmarPagamento(pagamentoId) };
    },
  },
];
