// Dados públicos da loja, curtidas e registro de pedidos pelo WhatsApp.
const db = require('../db');
const validar = require('../validar');
const { conferirItens, paraGravar, aplicarDescontoAtacado } = require('../pedidos');
const { ErroHttp, lerJson, ipDe } = require('../http');
const { limitar, MINUTO } = require('../limites');
const publico = require('../publico');

module.exports = [
  {
    // Dados públicos da vitrine (também vão embutidos no HTML das páginas). Cache na CDN por 60 s.
    metodo: 'GET',
    caminho: '/api/loja',
    cache: 'publico',
    acao: () => publico.dadosLoja(),
  },
  {
    metodo: 'POST',
    caminho: '/api/curtidas/:handle',
    acesso: 'cliente',
    acao: async ({ params, usuario }) => {
      const produto = await db.produtos.buscar(params.handle);
      if (!produto || !produto.ativo) throw new ErroHttp(404, 'Produto não encontrado.');
      const curtido = await db.curtidas.alternar(usuario.id, produto.handle);
      const totais = await db.curtidas.totais();
      return { curtido, total: totais[produto.handle] || 0 };
    },
  },
  {
    // Registra o pedido do carrinho antes de abrir o WhatsApp (quando o pagamento online está desligado).
    // Nome e preço vêm do banco; se o cliente estiver logado, o pedido fica na conta dele.
    metodo: 'POST',
    caminho: '/api/pedidos',
    acao: async ({ req, usuario }) => {
      await limitar(`pedido-whatsapp:ip:${ipDe(req)}`, 20, 60 * MINUTO);
      const conferidos = paraGravar(aplicarDescontoAtacado(await conferirItens(validar.itensPedido(await lerJson(req)))));
      const total = Math.round(conferidos.reduce((t, i) => t + i.preco * i.qtd, 0) * 100) / 100;
      const pedido = await db.pedidos.criar({ usuarioId: usuario?.id || null, itens: conferidos, total });
      return { pedido: { numero: pedido.numero, itens: pedido.itens, total: pedido.total } };
    },
  },
];
