const { redirecionar, lerCookies, ErroHttp } = require('../http');
const { tokenAleatorio, hmac, iguais } = require('../cripto');
const melhorEnvio = require('../melhor-envio');

const COOKIE = 'dred_me_oauth';
const seguro = () => (process.env.NODE_ENV === 'production' ? '; Secure' : '');
const cookieState = (valor, idade) => `${COOKIE}=${encodeURIComponent(valor)}; Path=/api/melhor-envio; HttpOnly; SameSite=Lax; Max-Age=${idade}${seguro()}`;

function pagina(res, status, titulo, mensagem) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>${titulo}</title><main style="font-family:system-ui;max-width:34rem;margin:12vh auto;padding:1.5rem"><h1>${titulo}</h1><p>${mensagem}</p><p><a href="/admin">Voltar ao painel</a></p></main>`);
}

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/melhor-envio/conectar',
    acesso: 'admin',
    acao: async ({ res }) => {
      const { clientId } = melhorEnvio.credenciais();
      const state = tokenAleatorio();
      res.setHeader('Set-Cookie', cookieState(`${state}.${hmac(state)}`, 600));
      const params = new URLSearchParams({
        client_id: clientId,
        redirect_uri: melhorEnvio.callback(),
        response_type: 'code',
        state,
        scope: 'shipping-calculate',
      });
      redirecionar(res, `${melhorEnvio.base()}/oauth/authorize?${params}`);
    },
  },
  {
    metodo: 'GET',
    caminho: '/api/melhor-envio/callback',
    acesso: 'admin',
    acao: async ({ req, res, url }) => {
      const erro = url.searchParams.get('error');
      if (erro) return pagina(res, 400, 'Autorização não concluída', 'O Melhor Envio não liberou o acesso. Tente conectar novamente.');
      const code = url.searchParams.get('code');
      const state = url.searchParams.get('state') || '';
      const esperado = lerCookies(req)[COOKIE] || '';
      if (!code || !state || !iguais(esperado, `${state}.${hmac(state)}`)) throw new ErroHttp(400, 'Retorno de autorização inválido. Tente conectar novamente.');
      res.setHeader('Set-Cookie', cookieState('', 0));
      await melhorEnvio.concluirAutorizacao(code);
      return pagina(res, 200, 'Melhor Envio conectado', 'A cotação de frete está pronta para uso. Os tokens serão renovados automaticamente.');
    },
  },
];
