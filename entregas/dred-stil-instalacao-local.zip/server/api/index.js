// Roteador da API JSON (/api/...).
const { ErroHttp, enviarJson } = require('../http');
const publico = require('../publico');
const { usuarioDaSessao, adminVerificado } = require('../auth');

const rotas = [...require('./loja'), ...require('./conta'), ...require('./checkout'), ...require('./melhor-envio'), ...require('./admin')].map((r) => ({
  ...r,
  // '/api/x/:handle' -> regex com grupos nomeados
  padrao: new RegExp('^' + r.caminho.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'),
}));

// Requisições que alteram dados só são aceitas vindas do próprio site.
function conferirOrigem(req) {
  const origem = req.headers.origin;
  if (!origem) return;
  let host = null;
  try {
    host = new URL(origem).host;
  } catch {}
  if (host !== req.headers.host) throw new ErroHttp(403, 'Origem não permitida.');
}

async function tratarApi(req, res, url) {
  try {
    const candidatas = rotas.filter((r) => r.padrao.test(url.pathname));
    if (!candidatas.length) throw new ErroHttp(404, 'Rota não encontrada.');
    const rota = candidatas.find((r) => r.metodo === req.method);
    if (!rota) throw new ErroHttp(405, 'Método não permitido.');
    if (req.method !== 'GET') conferirOrigem(req);

    const usuario = await usuarioDaSessao(req);
    if (rota.acesso && !usuario) throw new ErroHttp(401, 'Entre na sua conta para continuar.');
    if (rota.acesso === 'admin' && usuario.papel !== 'admin') throw new ErroHttp(403, 'Acesso restrito à administração.');
    if (rota.acesso === 'admin' && !adminVerificado(usuario)) {
      throw new ErroHttp(403, 'Ative a verificação em duas etapas em Minha conta e entre de novo para usar o painel.');
    }

    const params = Object.fromEntries(
      Object.entries(url.pathname.match(rota.padrao).groups || {}).map(([k, v]) => [k, decodeURIComponent(v)])
    );
    const resposta = await rota.acao({ req, res, url, params, usuario });
    // OAuth responde com redirect/HTML; não acrescente uma resposta JSON depois.
    if (res.writableEnded) return;
    // Alteração feita no admin: a vitrine passa a mostrar o novo conteúdo na hora (nesta instância).
    if (rota.acesso === 'admin' && req.method !== 'GET') publico.limpar();
    // Dados públicos (iguais para todos): a CDN da Vercel guarda por 60 s.
    if (rota.cache === 'publico') res.setHeader('Cache-Control', 'public, max-age=0, s-maxage=60, must-revalidate');
    enviarJson(res, 200, resposta ?? { ok: true });
  } catch (erro) {
    if (!(erro instanceof ErroHttp)) console.error(erro);
    const status = erro instanceof ErroHttp ? erro.status : 500;
    enviarJson(res, status, { erro: status === 500 ? 'Erro interno. Tente novamente.' : erro.message });
  }
}

module.exports = { tratarApi };
