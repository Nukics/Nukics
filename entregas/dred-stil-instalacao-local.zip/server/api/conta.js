// Contas: cadastro, login (com verificação em duas etapas por e-mail), recuperação de senha,
// confirmação de e-mail, perfil e logout.
const db = require('../db');
const validar = require('../validar');
const email = require('../email');
const { ErroHttp, lerJson, ipDe } = require('../http');
const { hashSenha, conferirSenha, iniciarSessao, encerrarSessao, usuarioPublico } = require('../auth');
const { limitar, zerarLimite, MINUTO } = require('../limites');
const { tokenAleatorio, sha256, codigo6, hmac, iguais } = require('../cripto');
const { urlSite, emailAtivo, exigir2faAdmin } = require('../ambiente');
const { COMPRAS_BOM_CLIENTE } = require('../vitrine');
const { notaPublica } = require('../nfe');

const HASH_FICTICIO = hashSenha('senha-que-nao-existe');
const HORA = 60 * MINUTO;
// Links dos e-mails levam o token no fragmento (#), que não vai para servidores nem logs.
const link = (ancora, token) => `${urlSite()}/conta#${ancora}=${token}`;

async function enviarConfirmacao(usuario) {
  const token = tokenAleatorio();
  await db.seguranca.criarToken(usuario.id, 'verificar_email', sha256(token), 24 * HORA);
  await email.enviar(email.montar(usuario.email, 'Confirme seu e-mail — Dred Stil',
    [`Olá, ${usuario.nome}!`, 'Confirme seu e-mail para proteger sua conta. O link vale por 24 horas.'],
    { texto: 'Confirmar e-mail', url: link('verificar', token) }));
}

// Conta(s) que combinam com o que a pessoa digitou: e-mail, apelido ou nome completo.
// Nome completo pode bater com mais de uma conta: cada uma recebe o link no próprio e-mail.
async function contasPara(identificador) {
  if (identificador.includes('@')) return [await db.usuarios.porEmail(identificador.toLowerCase())].filter(Boolean);
  const porApelido = /^[a-z0-9_.]{3,30}$/i.test(identificador) && (await db.usuarios.porApelido(identificador.toLowerCase()));
  if (porApelido) return [porApelido];
  return identificador.includes(' ') ? db.usuarios.porNome(identificador, 3) : [];
}

// Avisos de segurança não podem impedir a operação principal.
async function avisar(para, assunto, paragrafos) {
  try {
    await email.enviar(email.montar(para, assunto, paragrafos));
  } catch (erro) {
    console.error(`aviso por e-mail não enviado: ${erro.message}`);
  }
}

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/eu',
    acao: ({ usuario }) => ({ usuario: usuarioPublico(usuario) }),
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/cadastro',
    acao: async ({ req, res }) => {
      await limitar(`cadastro:ip:${ipDe(req)}`, 10, HORA);
      const dados = validar.cadastro(await lerJson(req));
      const { usuario, mensagem } = await db.usuarios.criar({ ...dados, senha: hashSenha(dados.senha) });
      if (!usuario) throw new ErroHttp(409, mensagem);
      await db.seguranca.auditar('conta_criada', { usuarioId: usuario.id, ip: ipDe(req) });
      if (emailAtivo()) await enviarConfirmacao(usuario).catch((e) => console.error(`confirmação não enviada: ${e.message}`));
      iniciarSessao(res, usuario);
      return { usuario: usuarioPublico(usuario) };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/entrar',
    acao: async ({ req, res }) => {
      const ip = ipDe(req);
      const { identificador, senha } = validar.login(await lerJson(req));
      // credential stuffing: limite por IP e por conta
      await limitar(`login:ip:${ip}`, 20, 15 * MINUTO);
      await limitar(`login:conta:${identificador}`, 8, 15 * MINUTO);
      const usuario = await (identificador.includes('@') ? db.usuarios.porEmail(identificador) : db.usuarios.porApelido(identificador));
      // confere contra um hash fictício quando o e-mail não existe, para o tempo de resposta ser o mesmo
      if (!conferirSenha(senha, usuario?.senha || HASH_FICTICIO) || !usuario) {
        await db.seguranca.auditar('login_falhou', { usuarioId: usuario?.id, ip });
        throw new ErroHttp(401, 'E-mail ou senha incorretos.');
      }
      await zerarLimite(`login:conta:${identificador}`);
      if (usuario.doisFatores) {
        await limitar(`2fa:envio:${usuario.id}`, 5, 15 * MINUTO);
        const desafio = tokenAleatorio();
        const codigo = codigo6();
        await db.seguranca.criarDesafio(usuario.id, sha256(desafio), hmac(`${desafio}:${codigo}`), 10 * MINUTO);
        await email.enviar(email.montar(usuario.email, `${codigo} é seu código de acesso — Dred Stil`, [
          `Seu código de verificação é: ${codigo}`,
          'Ele vale por 10 minutos. Nunca compartilhe este código com ninguém.',
        ]));
        return { etapa: 'codigo', desafio };
      }
      await db.seguranca.auditar('login', { usuarioId: usuario.id, ip });
      iniciarSessao(res, usuario);
      return { etapa: 'ok', usuario: usuarioPublico(usuario) };
    },
  },
  {
    // Segunda etapa do login: código de 6 dígitos enviado por e-mail.
    metodo: 'POST',
    caminho: '/api/conta/codigo',
    acao: async ({ req, res }) => {
      const ip = ipDe(req);
      await limitar(`2fa:ip:${ip}`, 30, 15 * MINUTO);
      const { desafio, codigo } = validar.codigo(await lerJson(req));
      const idHash = sha256(desafio);
      const tentativa = await db.seguranca.tentarDesafio(idHash); // conta a tentativa antes de comparar
      if (!tentativa) throw new ErroHttp(400, 'Código expirado. Entre de novo para receber outro.');
      if (!iguais(tentativa.codigoHash, hmac(`${desafio}:${codigo}`))) {
        await db.seguranca.auditar('2fa_falhou', { usuarioId: tentativa.usuarioId, ip });
        throw new ErroHttp(401, 'Código incorreto.');
      }
      if (!(await db.seguranca.consumirDesafio(idHash))) throw new ErroHttp(400, 'Código expirado. Entre de novo para receber outro.');
      const usuario = await db.usuarios.porId(tentativa.usuarioId);
      if (!usuario) throw new ErroHttp(400, 'Conta não encontrada.');
      await db.seguranca.auditar('login', { usuarioId: usuario.id, ip, detalhe: { duasEtapas: true } });
      iniciarSessao(res, usuario, { mfa: true });
      return { etapa: 'ok', usuario: usuarioPublico(usuario) };
    },
  },
  {
    // Mesma resposta exista ou não a conta (não revela quem é cliente).
    metodo: 'POST',
    caminho: '/api/conta/esqueci-senha',
    acao: async ({ req }) => {
      if (!emailAtivo()) throw new ErroHttp(503, 'Recuperação por e-mail indisponível no momento. Fale com a loja pelo WhatsApp.');
      const ip = ipDe(req);
      const { identificador } = validar.recuperacao(await lerJson(req));
      await limitar(`esqueci:ip:${ip}`, 5, 15 * MINUTO);
      await limitar(`esqueci:id:${identificador.toLowerCase()}`, 3, HORA);
      // O link vai sempre para o e-mail cadastrado na conta encontrada (nunca para outro endereço).
      for (const usuario of await contasPara(identificador)) {
        const token = tokenAleatorio();
        await db.seguranca.criarToken(usuario.id, 'redefinir_senha', sha256(token), 30 * MINUTO);
        await email.enviar(email.montar(usuario.email, 'Redefinição de senha — Dred Stil', [
          `Olá, ${usuario.nome}.`,
          'Recebemos um pedido para trocar a senha da sua conta. O link vale por 30 minutos e só pode ser usado uma vez.',
        ], { texto: 'Criar nova senha', url: link('redefinir', token) }));
        await db.seguranca.auditar('senha_reset_solicitado', { usuarioId: usuario.id, ip });
      }
      return { mensagem: 'Se encontrarmos uma conta com esses dados, enviamos um link para o e-mail cadastrado nela.' };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/redefinir-senha',
    acao: async ({ req, res }) => {
      const ip = ipDe(req);
      await limitar(`redefinir:ip:${ip}`, 10, 15 * MINUTO);
      const { token, senha } = validar.redefinicao(await lerJson(req));
      const usuarioId = await db.seguranca.consumirToken(sha256(token), 'redefinir_senha');
      if (!usuarioId) throw new ErroHttp(400, 'Link inválido ou expirado. Peça um novo em "Esqueci minha senha".');
      const usuario = await db.usuarios.porId(usuarioId);
      // nova versão de sessão derruba todos os aparelhos; quem recebeu o link provou o e-mail
      await db.usuarios.atualizar(usuarioId, {
        senha: hashSenha(senha),
        versaoSessao: usuario.versaoSessao + 1,
        emailVerificadoEm: usuario.emailVerificadoEm || new Date().toISOString(),
      });
      await db.seguranca.apagarTokens(usuarioId, 'redefinir_senha');
      await db.seguranca.apagarDesafios(usuarioId);
      await db.seguranca.auditar('senha_redefinida', { usuarioId, ip });
      await avisar(usuario.email, 'Sua senha foi alterada — Dred Stil', [
        'A senha da sua conta acabou de ser alterada e todos os aparelhos foram desconectados.',
        'Se não foi você, use "Esqueci minha senha" agora e fale com a loja.',
      ]);
      encerrarSessao(res);
      return { mensagem: 'Senha alterada! Entre com a nova senha.' };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/verificar-email/enviar',
    acesso: 'cliente',
    acao: async ({ usuario }) => {
      if (usuario.emailVerificadoEm) return { mensagem: 'Seu e-mail já está confirmado.' };
      if (!emailAtivo()) throw new ErroHttp(503, 'Envio de e-mail indisponível no momento.');
      await limitar(`confirmar:${usuario.id}`, 3, HORA);
      await enviarConfirmacao(usuario);
      return { mensagem: `Enviamos o link de confirmação para ${usuario.email}.` };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/verificar-email',
    acao: async ({ req }) => {
      const ip = ipDe(req);
      await limitar(`verificar:ip:${ip}`, 20, 15 * MINUTO);
      const { token } = validar.token(await lerJson(req));
      const usuarioId = await db.seguranca.consumirToken(sha256(token), 'verificar_email');
      if (!usuarioId) throw new ErroHttp(400, 'Link inválido ou expirado. Peça um novo em Minha conta.');
      const usuario = await db.usuarios.porId(usuarioId);
      if (!usuario.emailVerificadoEm) await db.usuarios.atualizar(usuarioId, { emailVerificadoEm: new Date().toISOString() });
      await db.seguranca.auditar('email_verificado', { usuarioId, ip });
      return { mensagem: 'E-mail confirmado!' };
    },
  },
  {
    // Liga/desliga a verificação em duas etapas. Exige a senha e e-mail confirmado.
    metodo: 'POST',
    caminho: '/api/conta/dois-fatores',
    acesso: 'cliente',
    acao: async ({ req, res, usuario }) => {
      await limitar(`2fa:alterar:${usuario.id}`, 5, 15 * MINUTO);
      const { ativar, senha } = validar.doisFatores(await lerJson(req));
      if (!conferirSenha(senha, usuario.senha)) throw new ErroHttp(401, 'Senha incorreta.');
      if (ativar && !usuario.emailVerificadoEm) throw new ErroHttp(400, 'Confirme seu e-mail antes de ativar a verificação em duas etapas.');
      if (!ativar && usuario.papel === 'admin' && exigir2faAdmin()) {
        throw new ErroHttp(403, 'A conta admin precisa manter a verificação em duas etapas.');
      }
      const campos = { doisFatores: ativar };
      if (ativar) campos.versaoSessao = usuario.versaoSessao + 1; // derruba os outros aparelhos
      const atualizado = await db.usuarios.atualizar(usuario.id, campos);
      if (ativar) iniciarSessao(res, atualizado, { mfa: true });
      await db.seguranca.auditar(ativar ? '2fa_ativado' : '2fa_desativado', { usuarioId: usuario.id, ip: ipDe(req) });
      await avisar(usuario.email, 'Verificação em duas etapas — Dred Stil', [ativar
        ? 'A verificação em duas etapas foi ATIVADA. A cada login pediremos um código enviado para este e-mail.'
        : 'A verificação em duas etapas foi DESATIVADA. Se não foi você, troque sua senha agora.']);
      return { usuario: usuarioPublico({ ...atualizado, sessaoMfa: ativar || usuario.sessaoMfa }) };
    },
  },
  {
    metodo: 'GET',
    caminho: '/api/conta/pedidos',
    acesso: 'cliente',
    acao: async ({ usuario }) => {
      const [pedidos, notas] = await Promise.all([db.pedidos.doUsuario(usuario.id), db.notas.doUsuario(usuario.id)]);
      const compras = pedidos.filter((p) => db.pedidos.STATUS_VENDA.includes(p.status)).length;
      return { pedidos, notas: notas.map(notaPublica), compras, bomCliente: compras >= COMPRAS_BOM_CLIENTE };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/sair',
    acao: ({ res }) => encerrarSessao(res),
  },
  {
    // Nova versão de sessão invalida o cookie em todos os aparelhos.
    metodo: 'POST',
    caminho: '/api/conta/sair-de-todos',
    acesso: 'cliente',
    acao: async ({ req, res, usuario }) => {
      await db.usuarios.atualizar(usuario.id, { versaoSessao: usuario.versaoSessao + 1 });
      await db.seguranca.auditar('sair_de_todos', { usuarioId: usuario.id, ip: ipDe(req) });
      encerrarSessao(res);
    },
  },
  {
    metodo: 'PATCH',
    caminho: '/api/conta',
    acesso: 'cliente',
    acao: async ({ req, res, usuario }) => {
      // Nome completo, apelido e telefone obrigatórios; CPF opcional (único entre as contas).
      const atualizado = await db.usuarios.atualizar(usuario.id, validar.perfil(await lerJson(req)));
      return { usuario: usuarioPublico({ ...atualizado, sessaoMfa: usuario.sessaoMfa }) };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/conta/senha',
    acesso: 'cliente',
    acao: async ({ req, res, usuario }) => {
      await limitar(`senha:trocar:${usuario.id}`, 5, 15 * MINUTO);
      const { senhaAtual, senhaNova } = validar.trocaSenha(await lerJson(req));
      if (!conferirSenha(senhaAtual, usuario.senha)) throw new ErroHttp(400, 'Senha atual incorreta.');
      // nova versão de sessão desconecta os outros aparelhos
      const atualizado = await db.usuarios.atualizar(usuario.id, { senha: hashSenha(senhaNova), versaoSessao: usuario.versaoSessao + 1 });
      iniciarSessao(res, atualizado, { mfa: usuario.sessaoMfa });
      await db.seguranca.auditar('senha_trocada', { usuarioId: usuario.id, ip: ipDe(req) });
    },
  },
];
