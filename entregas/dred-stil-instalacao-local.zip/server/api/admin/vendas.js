// Admin > Vendas (painel de faturamento) e Pedidos.
const db = require('../../db');
const validar = require('../../validar');
const { ErroHttp, lerJson, ipDe } = require('../../http');
const { notaPublica } = require('../../nfe');
const { provedorNfe } = require('../../ambiente');

const PEDIDOS_POR_PAGINA = 20;

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/admin/vendas',
    acesso: 'admin',
    acao: async () => {
      const [resumo, porDia, produtos, clientes] = await Promise.all([
        db.pedidos.resumo(),
        db.pedidos.porDia(),
        db.produtos.listar({ incluirInativos: true }).then(db.produtos.comCurtidas),
        db.usuarios.contar(),
      ]);
      return {
        resumo,
        porDia,
        clientes,
        produtos: produtos.length,
        produtosAtivos: produtos.filter((p) => p.ativo).length,
        maisCurtidos: [...produtos]
          .sort((a, b) => b.curtidas - a.curtidas)
          .slice(0, 5)
          .map(({ handle, nome, curtidas }) => ({ handle, nome, curtidas })),
      };
    },
  },
  {
    metodo: 'GET',
    caminho: '/api/admin/pedidos',
    acesso: 'admin',
    acao: async ({ url }) => {
      const status = url.searchParams.get('status') || '';
      if (status) validar.statusPedido(status);
      const pedida = Math.max(1, Number(url.searchParams.get('pagina')) || 1);
      const r = await db.pedidos.listarPagina({ status, pagina: pedida, porPagina: PEDIDOS_POR_PAGINA });
      const paginas = Math.max(1, Math.ceil(r.total / PEDIDOS_POR_PAGINA));
      // nota fiscal mais recente de cada pedido
      const notas = await db.notas.dosPedidos(r.pedidos.map((p) => p.id));
      const pedidos = r.pedidos.map((p) => ({ ...p, nota: notaPublica(notas.find((n) => n.pedidoId === p.id)) || null }));
      return { pedidos, total: r.total, pagina: Math.min(pedida, paginas), paginas, notasAtivas: Boolean(provedorNfe()) };
    },
  },
  {
    metodo: 'PATCH',
    caminho: '/api/admin/pedidos/:id',
    acesso: 'admin',
    acao: async ({ req, params, usuario }) => {
      const corpo = await lerJson(req);
      let pedido;
      if (corpo.rastreio !== undefined) pedido = await db.pedidos.definirRastreio(params.id, validar.rastreio(corpo.rastreio));
      if (corpo.status !== undefined) pedido = await db.pedidos.mudarStatus(params.id, validar.statusPedido(corpo.status));
      if (!pedido) throw new ErroHttp(404, 'Pedido não encontrado.');
      await db.seguranca.auditar('admin_pedido', { usuarioId: usuario.id, ip: ipDe(req), detalhe: { pedido: pedido.numero, status: corpo.status, rastreio: corpo.rastreio !== undefined } });
      return { pedido };
    },
  },
];
