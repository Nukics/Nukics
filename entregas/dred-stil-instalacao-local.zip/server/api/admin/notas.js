// Admin > notas fiscais: emitir (botão no pedido), atualizar a situação, reenviar por e-mail
// e ver as notas de um cliente.
const db = require('../../db');
const nfe = require('../../nfe');
const { ErroHttp } = require('../../http');
const { provedorNfe } = require('../../ambiente');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const exigirId = (id, oque) => {
  if (!UUID.test(id)) throw new ErroHttp(404, `${oque} não encontrado.`);
  return id;
};

module.exports = [
  {
    metodo: 'POST',
    caminho: '/api/admin/pedidos/:id/nota',
    acesso: 'admin',
    acao: async ({ params, usuario }) => ({ nota: nfe.notaPublica(await nfe.emitir(exigirId(params.id, 'Pedido'), usuario)) }),
  },
  {
    metodo: 'POST',
    caminho: '/api/admin/notas/:id/atualizar',
    acesso: 'admin',
    acao: async ({ params }) => ({ nota: nfe.notaPublica(await nfe.atualizar(exigirId(params.id, 'Nota'))) }),
  },
  {
    metodo: 'POST',
    caminho: '/api/admin/notas/:id/email',
    acesso: 'admin',
    acao: async ({ params }) => ({ nota: nfe.notaPublica(await nfe.reenviarEmail(exigirId(params.id, 'Nota'))) }),
  },
  {
    metodo: 'GET',
    caminho: '/api/admin/clientes/:id/notas',
    acesso: 'admin',
    acao: async ({ params }) => ({ notas: (await db.notas.doUsuario(exigirId(params.id, 'Cliente'))).map(nfe.notaPublica) }),
  },
  {
    // Para o painel saber se mostra o botão de emitir.
    metodo: 'GET',
    caminho: '/api/admin/notas/config',
    acesso: 'admin',
    acao: async () => ({ ativa: Boolean(provedorNfe()) }),
  },
];
