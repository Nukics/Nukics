// Rotas exclusivas da conta admin, separadas por assunto.
module.exports = [
  ...require('./vendas'),
  ...require('./produtos'),
  ...require('./categorias'),
  ...require('./clientes'),
  ...require('./conteudo'),
  ...require('./estoque'),
  ...require('./notas'),
];
