// Admin > conteúdo editável: menu, destaques, páginas de texto, perguntas frequentes e configurações.
const db = require('../../db');
const validar = require('../../validar');
const { ErroHttp, lerJson } = require('../../http');
const { PAGINAS_DE_TEXTO } = require('../../vitrine');

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/admin/conteudo',
    acesso: 'admin',
    acao: async () => {
      const [faq, config, menu, destaques, paginas] = await Promise.all([
        db.faq.ler(),
        db.config.ler(),
        db.menu.ler(),
        db.destaques.ler(),
        db.paginas.ler(),
      ]);
      // páginas em lista, na ordem do site (o banco não guarda a ordem das chaves)
      const listaPaginas = PAGINAS_DE_TEXTO.filter((e) => paginas[e]).map((endereco) => ({ endereco, ...paginas[endereco] }));
      return { faq, config, menu, destaques, paginas: listaPaginas };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/menu',
    acesso: 'admin',
    acao: async ({ req }) => {
      const menu = validar.menu(await lerJson(req), PAGINAS_DE_TEXTO);
      const categorias = await db.categorias.listar();
      const semCategoria = menu.find((i) => i.tipo === 'categoria' && !categorias.some((c) => c.slug === i.categoria));
      if (semCategoria) throw new ErroHttp(400, `A categoria do item "${semCategoria.rotulo}" não existe mais.`);
      await db.menu.gravar(menu);
      return { menu };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/destaques',
    acesso: 'admin',
    acao: async ({ req }) => {
      const abas = validar.destaques(await lerJson(req));
      const existentes = new Set((await db.produtos.listar({ incluirInativos: true })).map((p) => p.handle));
      const destaques = abas.map((aba) => ({ ...aba, produtos: aba.produtos.filter((h) => existentes.has(h)) }));
      await db.destaques.gravar(destaques);
      return { destaques };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/paginas/:pagina',
    acesso: 'admin',
    acao: async ({ req, params }) => {
      if (!PAGINAS_DE_TEXTO.includes(params.pagina)) throw new ErroHttp(404, 'Página não encontrada.');
      const { texto } = validar.textoPagina(await lerJson(req));
      const paginas = await db.paginas.ler();
      paginas[params.pagina] = { ...paginas[params.pagina], texto };
      await db.paginas.gravar(paginas);
      return { pagina: paginas[params.pagina] };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/faq',
    acesso: 'admin',
    acao: async ({ req }) => {
      const faq = validar.perguntas(await lerJson(req));
      await db.faq.gravar(faq);
      return { faq };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/config',
    acesso: 'admin',
    acao: async ({ req }) => {
      const config = validar.configuracoes(await lerJson(req));
      await db.config.gravar(config);
      return { config };
    },
  },
];
