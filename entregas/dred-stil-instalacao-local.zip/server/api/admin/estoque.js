// Admin > Estoque: saldos por tipo de peça e cor; grupos antigos são preservados.
// Cada venda confirmada desce o total do grupo (regra no banco: pedidos_estoque).
const db = require('../../db');
const validar = require('../../validar');
const { ErroHttp, lerJson, ipDe } = require('../../http');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const exigirId = (id) => (UUID.test(id) ? id : (() => { throw new ErroHttp(404, 'Estoque não encontrado.'); })());

async function conferirProdutos(handles, cor) {
  if (!handles.length) return;
  const existentes = await db.produtos.buscarVarios(handles);
  if (existentes.length !== handles.length) throw new ErroHttp(400, 'Algum produto selecionado não existe mais. Recarregue a página.');
  if (cor && existentes.some((p) => !p.cores.some((c) => c.nome.trim().toLowerCase() === cor.trim().toLowerCase()))) {
    throw new ErroHttp(400, 'Selecione apenas produtos que possuem essa cor.');
  }
}

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/admin/estoques',
    acesso: 'admin',
    acao: async () => {
      const [estoques, produtos] = await Promise.all([db.estoques.listar(), db.produtos.listar({ incluirInativos: true })]);
      return { estoques, produtos: produtos.map((p) => ({ handle: p.handle, nome: p.nome, estoqueId: p.estoqueId, ativo: p.ativo, cores: p.cores.map(({ nome, hex }) => ({ nome, hex })) })) };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/admin/estoques',
    acesso: 'admin',
    acao: async ({ req, usuario }) => {
      const dados = validar.estoque(await lerJson(req));
      await conferirProdutos(dados.produtos, dados.cor);
      const criado = await db.estoques.salvar(null, dados, usuario.id);
      await db.seguranca.auditar('estoque_criado', { usuarioId: usuario.id, ip: ipDe(req), detalhe: { nome: dados.nome, cor: dados.cor, quantidade: dados.quantidade } });
      return { estoque: criado };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/estoques/:id',
    acesso: 'admin',
    acao: async ({ req, params, usuario }) => {
      const id = exigirId(params.id);
      const anterior = await db.estoques.porId(id);
      if (!anterior) throw new ErroHttp(404, 'Estoque não encontrado.');
      const dados = validar.estoque(await lerJson(req));
      // Clientes anteriores não enviavam o campo cor nos grupos antigos.
      if (dados.cor !== anterior.cor && (dados.cor || '').toLowerCase() !== (anterior.cor || '').toLowerCase()) {
        throw new ErroHttp(409, 'A cor de um saldo existente não pode ser alterada. Crie um novo saldo por cor.');
      }
      await conferirProdutos(dados.produtos, dados.cor);
      const r = await db.estoques.salvar(id, dados, usuario.id);
      if (!r) throw new ErroHttp(404, 'Estoque não encontrado.');
      await db.seguranca.auditar('estoque_alterado', { usuarioId: usuario.id, ip: ipDe(req), detalhe: { nome: dados.nome, cor: dados.cor, de: anterior.quantidade, para: dados.quantidade } });
      return { estoque: r };
    },
  },
  {
    metodo: 'DELETE',
    caminho: '/api/admin/estoques/:id',
    acesso: 'admin',
    acao: async ({ req, params, usuario }) => {
      const id = exigirId(params.id);
      if (!(await db.estoques.remover(id))) throw new ErroHttp(404, 'Estoque não encontrado.');
      await db.seguranca.auditar('estoque_removido', { usuarioId: usuario.id, ip: ipDe(req), detalhe: { id } });
    },
  },
  {
    metodo: 'GET',
    caminho: '/api/admin/estoques/:id/movimentos',
    acesso: 'admin',
    acao: async ({ params }) => ({ movimentos: await db.estoques.movimentos(exigirId(params.id)) }),
  },
];
