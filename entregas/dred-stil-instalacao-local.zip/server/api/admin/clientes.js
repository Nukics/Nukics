// Admin > Clientes: lista com número de compras, selo de bom cliente e link de nova senha.
const crypto = require('crypto');
const db = require('../../db');
const email = require('../../email');
const { ErroHttp, ipDe } = require('../../http');
const { tokenAleatorio, sha256 } = require('../../cripto');
const { urlSite, emailAtivo } = require('../../ambiente');
const { usuarioPublico, hashSenha } = require('../../auth');
const { COMPRAS_BOM_CLIENTE } = require('../../vitrine');

const CLIENTES_POR_PAGINA = 20;

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/admin/clientes',
    acesso: 'admin',
    acao: async ({ url }) => {
      const busca = (url.searchParams.get('busca') || '').trim().slice(0, 80);
      const pedida = Math.max(1, Number(url.searchParams.get('pagina')) || 1);
      let r = await db.usuarios.listarPagina({ busca, pagina: pedida, porPagina: CLIENTES_POR_PAGINA });
      const paginas = Math.max(1, Math.ceil(r.total / CLIENTES_POR_PAGINA));
      const pagina = Math.min(pedida, paginas);
      if (pagina !== pedida) r = await db.usuarios.listarPagina({ busca, pagina, porPagina: CLIENTES_POR_PAGINA });
      const compras = await db.pedidos.comprasPorUsuario(r.clientes.map((c) => c.id));
      const clientes = r.clientes.map((c) => {
        const total = compras[c.id] || 0;
        return { ...usuarioPublico(c), compras: total, bomCliente: total >= COMPRAS_BOM_CLIENTE };
      });
      return { clientes, total: r.total, pagina, paginas, comprasBomCliente: COMPRAS_BOM_CLIENTE };
    },
  },
  {
    // Envia ao cliente o link de redefinição de senha (o admin nunca vê a senha).
    metodo: 'POST',
    caminho: '/api/admin/clientes/:id/redefinir',
    acesso: 'admin',
    acao: async ({ req, params, usuario }) => {
      if (params.id === usuario.id) throw new ErroHttp(400, 'Troque a sua senha em Minha conta.');
      if (!emailAtivo()) throw new ErroHttp(503, 'Envio de e-mail não configurado. Use a senha temporária.');
      const cliente = await db.usuarios.porId(params.id);
      if (!cliente) throw new ErroHttp(404, 'Cliente não encontrado.');
      const token = tokenAleatorio();
      await db.seguranca.criarToken(cliente.id, 'redefinir_senha', sha256(token), 60 * 60);
      await email.enviar(email.montar(cliente.email, 'Redefinição de senha — Dred Stil', [
        `Olá, ${cliente.nome}.`,
        'A loja enviou este link para você criar uma nova senha. Ele vale por 1 hora e só pode ser usado uma vez.',
      ], { texto: 'Criar nova senha', url: `${urlSite()}/conta#redefinir=${token}` }));
      await db.seguranca.auditar('admin_enviou_redefinicao', { usuarioId: usuario.id, ip: ipDe(req), detalhe: { cliente: cliente.id } });
      return { mensagem: `Link de redefinição enviado para ${cliente.email}.` };
    },
  },
  {
    // Reserva enquanto o envio de e-mail não estiver configurado: senha temporária para repassar.
    metodo: 'POST',
    caminho: '/api/admin/clientes/:id/senha',
    acesso: 'admin',
    acao: async ({ req, params, usuario }) => {
      if (emailAtivo()) throw new ErroHttp(410, 'Use "Enviar link de nova senha": o cliente cria a senha pelo e-mail.');
      if (params.id === usuario.id) throw new ErroHttp(400, 'Troque a sua senha em Minha conta.');
      const cliente = await db.usuarios.porId(params.id);
      if (!cliente) throw new ErroHttp(404, 'Cliente não encontrado.');
      const senha = crypto.randomBytes(9).toString('base64url');
      await db.usuarios.atualizar(cliente.id, { senha: hashSenha(senha), versaoSessao: cliente.versaoSessao + 1 });
      await db.seguranca.auditar('admin_gerou_senha_temporaria', { usuarioId: usuario.id, ip: ipDe(req), detalhe: { cliente: cliente.id } });
      return { senha };
    },
  },
];
