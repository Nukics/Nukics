// Admin > Categorias do catálogo (com um nível de subcategoria).
const db = require('../../db');
const validar = require('../../validar');
const { ErroHttp, lerJson } = require('../../http');

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/admin/categorias',
    acesso: 'admin',
    acao: async () => {
      const [categorias, produtos] = await Promise.all([db.categorias.listar(), db.produtos.listar({ incluirInativos: true })]);
      const contagem = (slug) => produtos.filter((p) => p.categoria === slug).length;
      return { categorias: categorias.map((c) => ({ ...c, produtos: contagem(c.slug) })) };
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/admin/categorias',
    acesso: 'admin',
    acao: async ({ req }) => {
      const nova = validar.categoria(await lerJson(req));
      const categorias = await db.categorias.listar();
      if (nova.pai) {
        const pai = categorias.find((c) => c.slug === nova.pai);
        if (!pai) throw new ErroHttp(400, 'Categoria principal não encontrada.');
        if (pai.pai) throw new ErroHttp(400, 'Subcategorias só podem ficar dentro de uma categoria principal.');
      }
      const irmas = categorias.filter((c) => c.pai === nova.pai);
      const ordem = irmas.length ? Math.max(...irmas.map((c) => c.ordem)) + 1 : 0;
      if (!(await db.categorias.criar({ ...nova, ordem }))) throw new ErroHttp(409, 'Já existe uma categoria com esse nome.');
      return { categoria: nova };
    },
  },
  {
    // Ordem das categorias que têm o mesmo pai, na sequência enviada.
    metodo: 'PUT',
    caminho: '/api/admin/categorias/ordem',
    acesso: 'admin',
    acao: async ({ req }) => {
      const { slugs } = await lerJson(req);
      if (!Array.isArray(slugs) || slugs.length > 100) throw new ErroHttp(400, 'Ordem inválida.');
      await Promise.all(slugs.map((slug, ordem) => db.categorias.atualizar(validar.slug(slug), { ordem })));
    },
  },
  {
    metodo: 'PATCH',
    caminho: '/api/admin/categorias/:slug',
    acesso: 'admin',
    acao: async ({ req, params }) => {
      const campos = validar.edicaoCategoria(await lerJson(req));
      if (campos.pai !== undefined) {
        const categorias = await db.categorias.listar();
        const atual = categorias.find((c) => c.slug === params.slug);
        if (!atual) throw new ErroHttp(404, 'Categoria não encontrada.');
        if (campos.pai === atual.slug) throw new ErroHttp(400, 'Uma categoria não pode ficar dentro dela mesma.');
        if (campos.pai) {
          const pai = categorias.find((c) => c.slug === campos.pai);
          if (!pai) throw new ErroHttp(400, 'Categoria principal não encontrada.');
          if (pai.pai) throw new ErroHttp(400, 'Subcategorias só podem ficar dentro de uma categoria principal.');
          if (categorias.some((c) => c.pai === atual.slug)) {
            throw new ErroHttp(409, 'Esta categoria tem subcategorias. Mova as subcategorias primeiro para manter apenas um nível.');
          }
        }
        // Acrescenta no fim do novo grupo sem mudar o endereço, os produtos ou a opção de menu.
        if (campos.pai !== atual.pai) {
          const irmas = categorias.filter((c) => c.pai === campos.pai && c.slug !== atual.slug);
          campos.ordem = irmas.length ? Math.max(...irmas.map((c) => c.ordem)) + 1 : 0;
        }
      }
      if (!(await db.categorias.atualizar(params.slug, campos))) throw new ErroHttp(404, 'Categoria não encontrada.');
    },
  },
  {
    metodo: 'DELETE',
    caminho: '/api/admin/categorias/:slug',
    acesso: 'admin',
    acao: async ({ params }) => {
      const resultado = await db.categorias.remover(params.slug);
      if (resultado === 'em-uso') throw new ErroHttp(409, 'Essa categoria tem produtos ou subcategorias. Mude-os de categoria antes de excluir.');
      if (!resultado) throw new ErroHttp(404, 'Categoria não encontrada.');
    },
  },
];
