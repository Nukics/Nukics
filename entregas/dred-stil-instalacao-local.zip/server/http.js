// Utilitários HTTP compartilhados pelo servidor (sem dependências externas).

class ErroHttp extends Error {
  constructor(status, mensagem) {
    super(mensagem);
    this.status = status;
  }
}

function enviarJson(res, status, dados) {
  if (!res.hasHeader('Cache-Control')) res.setHeader('Cache-Control', 'no-store');
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(dados));
}

function redirecionar(res, destino) {
  res.writeHead(303, { Location: destino });
  res.end();
}

// Lê o corpo JSON com limite de tamanho. Exigir JSON também barra envios de
// formulários de outros sites (CSRF), que não conseguem mandar esse content-type.
function lerJson(req, limite = 100 * 1024) {
  if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) {
    return Promise.reject(new ErroHttp(415, 'Envie os dados em JSON.'));
  }
  return new Promise((resolve, reject) => {
    let tamanho = 0;
    let estourou = false;
    const partes = [];
    req.on('data', (parte) => {
      if (estourou) return; // descarta o resto sem guardar na memória
      tamanho += parte.length;
      if (tamanho > limite) {
        estourou = true;
        partes.length = 0;
        reject(new ErroHttp(413, 'Envio grande demais.'));
      } else partes.push(parte);
    });
    req.on('end', () => {
      if (estourou) return;
      try {
        resolve(partes.length ? JSON.parse(Buffer.concat(partes).toString('utf8')) : {});
      } catch {
        reject(new ErroHttp(400, 'JSON inválido.'));
      }
    });
    req.on('error', reject);
  });
}

function lerCookies(req) {
  return Object.fromEntries(
    (req.headers.cookie || '')
      .split(';')
      .map((c) => c.trim().split('='))
      .filter(([nome, valor]) => nome && valor !== undefined)
      .map(([nome, ...resto]) => [nome, decodeURIComponent(resto.join('='))])
  );
}

// IP do cliente. Na Vercel o socket é o proxy da plataforma; o IP real vem em
// x-forwarded-for, preenchido pela própria Vercel (por isso só confiamos nele lá).
function ipDe(req) {
  if (process.env.VERCEL) {
    const encaminhado = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (encaminhado) return encaminhado;
  }
  return req.socket.remoteAddress || 'desconhecido';
}

module.exports = { ErroHttp, enviarJson, redirecionar, lerJson, lerCookies, ipDe };
