// Regras de exibição da loja usadas pelas páginas e pela API.

// Páginas de texto editáveis no admin (endereço -> usadas no rodapé e no menu).
const PAGINAS_DE_TEXTO = ['quem-somos', 'trocas-e-devolucoes', 'onde-estamos', 'seguranca', 'politica-de-privacidade', 'termos-de-uso'];

// A partir de quantas compras o cliente ganha o selo "Bom cliente".
const COMPRAS_BOM_CLIENTE = 5;

const linkCategoria = (slug) => slug === 'atacado' ? '/atacado' : `/catalogo?categoria=${encodeURIComponent(slug)}`;

// Categorias principais com as subcategorias em "filhos" (a lista já vem ordenada).
function arvoreCategorias(lista) {
  return lista.filter((c) => !c.pai).map((c) => ({ ...c, filhos: lista.filter((f) => f.pai === c.slug) }));
}

// Slugs da categoria e de todas as subcategorias dela (para filtrar produtos).
function comSubcategorias(lista, slug) {
  return [slug, ...lista.filter((c) => c.pai === slug).map((c) => c.slug)];
}

const itemCategoria = (c) => ({ rotulo: c.nome, href: linkCategoria(c.slug), categoria: c.slug });

// Menu configurado no admin -> itens prontos para exibir, com submenus de categorias.
// Itens escondidos, categorias apagadas e páginas inexistentes ficam de fora.
function menuParaExibir(itens, categorias, paginas) {
  const visiveis = categorias.filter((c) => c.noMenu);
  return itens
    .filter((item) => item.visivel)
    .map((item) => {
      if (item.tipo === 'catalogo') {
        return {
          rotulo: item.rotulo,
          href: '/catalogo',
          filhos: arvoreCategorias(visiveis).map((c) => ({ ...itemCategoria(c), filhos: c.filhos.map(itemCategoria) })),
        };
      }
      if (item.tipo === 'categoria') {
        const categoria = categorias.find((c) => c.slug === item.categoria);
        if (!categoria) return null;
        return { ...itemCategoria(categoria), rotulo: item.rotulo, filhos: visiveis.filter((c) => c.pai === categoria.slug).map(itemCategoria) };
      }
      if (item.tipo === 'pagina') return paginas[item.pagina] ? { rotulo: item.rotulo, href: `/${item.pagina}` } : null;
      return { rotulo: item.rotulo, href: item.link };
    })
    .filter(Boolean);
}

module.exports = { PAGINAS_DE_TEXTO, COMPRAS_BOM_CLIENTE, arvoreCategorias, comSubcategorias, menuParaExibir };
