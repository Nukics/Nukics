// Envio de e-mails transacionais (Resend). Sem RESEND_API_KEY fora de produção,
// os e-mails ficam em .dev-emails/ para teste; em produção, falta de configuração é erro.
const fs = require('fs');
const path = require('path');
const { esc } = require('./texto');
const { ErroHttp } = require('./http');
const { EM_PRODUCAO } = require('./ambiente');
const db = require('./db');

// Todo texto dinâmico é escapado.
function montar(para, assunto, paragrafos, botao) {
  const html =
    '<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;color:#181a1b">' +
    '<h2 style="margin:0 0 16px">Dred Stil</h2>' +
    paragrafos.map((p) => `<p style="line-height:1.5">${esc(p)}</p>`).join('') +
    (botao
      ? `<p><a href="${esc(botao.url)}" style="display:inline-block;background:#181a1b;color:#fff;padding:12px 20px;border-radius:4px;text-decoration:none">${esc(botao.texto)}</a></p>`
      : '') +
    '<p style="font-size:12px;color:#6b6b6b">Se você não fez esta solicitação, ignore este e-mail.</p></div>';
  const texto = paragrafos.join('\n\n') + (botao ? `\n\n${botao.texto}: ${botao.url}` : '');
  return { para, assunto, texto, html };
}

async function enviar(email) {
  if (process.env.NODE_ENV === 'test') {
    (globalThis.__emailsTeste ??= []).push(email);
    return;
  }
  const chave = process.env.RESEND_API_KEY;
  if (!chave) {
    if (EM_PRODUCAO) throw new ErroHttp(503, 'Envio de e-mail indisponível no momento. Tente mais tarde.');
    const pasta = path.join(__dirname, '..', '.dev-emails');
    fs.mkdirSync(pasta, { recursive: true });
    fs.writeFileSync(path.join(pasta, `${Date.now()}-${crypto.randomUUID()}.json`), JSON.stringify(email, null, 2));
    console.log(`[e-mail de desenvolvimento] ${email.assunto} -> .dev-emails/`);
    return;
  }
  const config = await db.config.ler();
  const resposta = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${chave}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM || 'Dred Stil <nao-responda@dredstil.com.br>',
      to: [email.para],
      subject: email.assunto,
      text: email.texto,
      html: email.html,
      ...(config.emailResposta ? { reply_to: config.emailResposta } : {}),
    }),
    signal: AbortSignal.timeout(10_000),
  });
  if (!resposta.ok) throw new Error(`Resend respondeu HTTP ${resposta.status}`);
}

module.exports = { montar, enviar };
