// OAuth do Melhor Envio. Client Secret fica apenas nas variáveis da Vercel;
// access/refresh tokens são cifrados no banco e renovados automaticamente.
const db = require('./db');
const { ErroHttp } = require('./http');
const { cifrar, decifrar } = require('./cripto');
const { urlSite } = require('./ambiente');

const bases = { sandbox: 'https://sandbox.melhorenvio.com.br', producao: 'https://melhorenvio.com.br' };
const ambiente = () => (process.env.MELHOR_ENVIO_AMBIENTE === 'producao' ? 'producao' : 'sandbox');
const base = () => bases[ambiente()];
const callback = () => `${urlSite()}/api/melhor-envio/callback`;

function credenciais() {
  const clientId = process.env.MELHOR_ENVIO_CLIENT_ID;
  const clientSecret = process.env.MELHOR_ENVIO_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new ErroHttp(503, 'Configure o Client ID e o Client Secret do Melhor Envio na Vercel.');
  return { clientId, clientSecret };
}

async function salvarTokens(resposta) {
  if (!resposta?.access_token || !resposta?.refresh_token) throw new Error('Resposta de autorização do Melhor Envio inválida.');
  const validadeS = Math.max(60, Number(resposta.expires_in) || 60 * 60 * 24 * 30);
  const integracoes = await db.integracoes.ler();
  await db.integracoes.gravar({
    ...integracoes,
    melhorEnvio: cifrar({
      accessToken: resposta.access_token,
      refreshToken: resposta.refresh_token,
      expiraEm: Date.now() + validadeS * 1000 - 60_000,
    }),
  });
}

async function solicitarToken(campos) {
  const { clientId, clientSecret } = credenciais();
  const resposta = await fetch(`${base()}/oauth/token`, {
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ ...campos, client_id: clientId, client_secret: clientSecret }),
    signal: AbortSignal.timeout(10_000),
  });
  const corpo = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw new Error(`Melhor Envio recusou a autorização (HTTP ${resposta.status}).`);
  return corpo;
}

async function concluirAutorizacao(code) {
  const tokens = await solicitarToken({ grant_type: 'authorization_code', redirect_uri: callback(), code });
  await salvarTokens(tokens);
}

async function tokenDeAcesso() {
  // Mantém compatibilidade com instalações que já usam um token de servidor.
  if (process.env.MELHOR_ENVIO_TOKEN) return process.env.MELHOR_ENVIO_TOKEN;
  const integracoes = await db.integracoes.ler();
  if (!integracoes.melhorEnvio) throw new ErroHttp(503, 'Conecte o Melhor Envio no painel administrativo antes de calcular o frete.');
  const dados = decifrar(integracoes.melhorEnvio);
  if (dados.accessToken && dados.expiraEm > Date.now()) return dados.accessToken;
  try {
    const tokens = await solicitarToken({ grant_type: 'refresh_token', refresh_token: dados.refreshToken });
    await salvarTokens(tokens);
    return tokens.access_token;
  } catch (erro) {
    console.error('Não foi possível renovar o token do Melhor Envio:', erro.message);
    throw new ErroHttp(503, 'A conexão com o Melhor Envio expirou. Reconecte a integração no painel.');
  }
}

module.exports = { base, callback, credenciais, concluirAutorizacao, tokenDeAcesso };
