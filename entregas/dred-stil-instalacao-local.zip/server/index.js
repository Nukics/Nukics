// Servidor da loja Dred Stil: arquivos estáticos (public/), API (/api) e páginas.
// Localmente roda com node serve.js; na Vercel, api/index.js usa tratarRequisicao
// (lá os arquivos de public/ são entregues direto pela Vercel).
const http = require('http');
const fs = require('fs');
const path = require('path');
const { tratarApi } = require('./api');
const { tratarPagina } = require('./paginas');
const publico = require('./publico');
const { urlSite } = require('./ambiente');
const { PAGINAS_DE_TEXTO } = require('./vitrine');

const PUBLICO = path.join(__dirname, '..', 'public');
const TIPOS = {
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.gif': 'image/gif',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
};

const CABECALHOS_SEGURANCA = {
  'X-Frame-Options': 'DENY',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':
    "default-src 'self'; img-src 'self' data: https://*.supabase.co; style-src 'self' 'unsafe-inline'; script-src 'self'; " +
    "frame-src https://www.google.com; connect-src 'self' https://viacep.com.br; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'",
  'Cross-Origin-Opener-Policy': 'same-origin',
  // Só em produção (HTTPS): o navegador passa a recusar HTTP para o domínio.
  ...(process.env.NODE_ENV === 'production' ? { 'Strict-Transport-Security': 'max-age=63072000; includeSubDomains' } : {}),
};

function cabecalhosPagamento(url) {
  if (url.pathname !== '/checkout' || process.env.PAGAMENTO_PROVEDOR !== 'getnet-global') return null;
  try {
    const { api, web } = require('./pagamento/getnet-global').configuracao();
    return CABECALHOS_SEGURANCA['Content-Security-Policy']
      .replace("script-src 'self'", `script-src 'self' ${web}`)
      .replace('frame-src https://www.google.com', `frame-src https://www.google.com ${web}`)
      .replace("connect-src 'self'", `connect-src 'self' ${web} ${api}`);
  } catch { return null; }
}

// Serve um arquivo de public/ se existir. Devolve false para seguir adiante.
function tratarEstatico(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  const arquivo = path.join(PUBLICO, path.normalize(decodeURIComponent(url.pathname)));
  const tipo = TIPOS[path.extname(arquivo).toLowerCase()];
  if (!tipo || !arquivo.startsWith(PUBLICO + path.sep) || !fs.existsSync(arquivo)) return false;
  const longoPrazo = /\.(woff2|webp|jpe?g|png|avif|gif)$/.test(arquivo);
  res.writeHead(200, { 'Content-Type': tipo, 'Cache-Control': longoPrazo ? 'public, max-age=604800' : 'no-cache' });
  if (req.method === 'HEAD') res.end();
  else fs.createReadStream(arquivo).pipe(res);
  return true;
}

// Mapa do site para o Google: páginas públicas e todos os produtos à venda.
async function tratarSitemap(res) {
  const base = urlSite();
  const [loja, paginas] = await Promise.all([publico.dadosLoja(), publico.paginas()]);
  const urls = [
    ['/', '1.0'],
    ['/catalogo', '0.9'],
    ['/atacado', '0.9'],
    ...loja.produtos.map((p) => [`/produto/${encodeURIComponent(p.handle)}`, '0.8']),
    ...PAGINAS_DE_TEXTO.filter((e) => paginas[e]).map((e) => [`/${e}`, '0.3']),
  ];
  const xml = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    ...urls.map(([c, prioridade]) => `  <url><loc>${base}${c}</loc><priority>${prioridade}</priority></url>`),
    '</urlset>',
    '',
  ].join(String.fromCharCode(10));
  res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=0, s-maxage=3600' });
  res.end(xml);
}

async function tratarRequisicao(req, res) {
  for (const [nome, valor] of Object.entries(CABECALHOS_SEGURANCA)) res.setHeader(nome, valor);
  let url;
  try {
    url = new URL(req.url, 'http://localhost');
    decodeURIComponent(url.pathname);
  } catch {
    return res.writeHead(400).end('Endereço inválido');
  }
  const cspPagamento = cabecalhosPagamento(url);
  if (cspPagamento) res.setHeader('Content-Security-Policy', cspPagamento);
  if (url.pathname.startsWith('/api/')) return tratarApi(req, res, url);
  if (url.pathname === '/sitemap.xml') return tratarSitemap(res).catch(() => res.writeHead(500).end());
  if (tratarEstatico(req, res, url)) return;
  try {
    await tratarPagina(req, res, url);
  } catch (erro) {
    console.error(erro);
    if (!res.headersSent) res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Erro interno. Tente novamente em instantes.');
  }
}

function iniciar(porta = Number(process.env.PORT) || 5173) {
  const servidor = http.createServer(tratarRequisicao);
  servidor.listen(porta, () => console.log(`Dred Stil rodando em http://localhost:${porta}`));
  return servidor;
}

module.exports = { iniciar, tratarRequisicao };
