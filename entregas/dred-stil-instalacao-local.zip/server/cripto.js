// Tokens, códigos e hashes usados em links de e-mail, verificação em duas etapas e webhooks.
const crypto = require('crypto');

const segredo = () => process.env.SESSION_SECRET || 'segredo-de-desenvolvimento';

// 256 bits aleatórios, seguros para URL.
const tokenAleatorio = () => crypto.randomBytes(32).toString('base64url');

// Hash de tokens de alta entropia (não serve para senhas).
const sha256 = (valor) => crypto.createHash('sha256').update(String(valor)).digest('hex');

// Código numérico de 6 dígitos, distribuição uniforme.
const codigo6 = () => String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');

// HMAC com o segredo do servidor: um código curto vazado do banco não pode ser testado offline.
const hmac = (valor) => crypto.createHmac('sha256', segredo()).update(String(valor)).digest('hex');

function iguais(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// Dados de integração (como os tokens OAuth) ficam cifrados antes de ir para o banco.
// A chave vem do mesmo segredo que protege as sessões e nunca é enviada ao navegador.
function cifrar(valor) {
  const iv = crypto.randomBytes(12);
  const cifra = crypto.createCipheriv('aes-256-gcm', crypto.createHash('sha256').update(segredo()).digest(), iv);
  const corpo = Buffer.concat([cifra.update(JSON.stringify(valor), 'utf8'), cifra.final()]);
  return [iv, cifra.getAuthTag(), corpo].map((parte) => parte.toString('base64url')).join('.');
}

function decifrar(valor) {
  try {
    const [iv, tag, corpo] = String(valor).split('.').map((parte) => Buffer.from(parte, 'base64url'));
    if (!iv || !tag || !corpo || iv.length !== 12 || tag.length !== 16) throw new Error('Formato inválido');
    const decifra = crypto.createDecipheriv('aes-256-gcm', crypto.createHash('sha256').update(segredo()).digest(), iv);
    decifra.setAuthTag(tag);
    return JSON.parse(Buffer.concat([decifra.update(corpo), decifra.final()]).toString('utf8'));
  } catch {
    throw new Error('Não foi possível ler a integração salva. Conecte o Melhor Envio novamente.');
  }
}

module.exports = { tokenAleatorio, sha256, codigo6, hmac, iguais, cifrar, decifrar };
