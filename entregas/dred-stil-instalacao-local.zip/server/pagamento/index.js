// Provedor de pagamento em uso. Dados de cartão NUNCA passam por este servidor.
// Contrato de cada provedor:
//   criarPix({ pedidoId, totalCentavos, clienteId }) -> { pagamentoId, copiaECola, expiraEm }
//   consultar(pagamentoId) -> { status: 'aprovado'|'pendente'|'negado'|'cancelado', valorCentavos|null }
const { provedorPagamento } = require('../ambiente');
const { ErroHttp } = require('../http');

function provedor() {
  const nome = provedorPagamento();
  if (nome === 'getnet-global') return require('./getnet-global');
  if (nome === 'getnet') return require('./getnet');
  if (nome === 'simulado') return require('./simulado');
  throw new ErroHttp(503, 'Pagamento online indisponível no momento.');
}

module.exports = { provedor };
