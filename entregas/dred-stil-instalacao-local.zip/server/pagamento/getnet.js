// Getnet (Santander) — API Digital, Pix.
//
// CONFIRMAR NA DOCUMENTAÇÃO DE LOJISTA (developers.getnet.com.br, exige login) ANTES DE IR PARA PRODUÇÃO:
//  - caminho de consulta do pagamento Pix (consultar());
//  - formato da notificação (webhook) e campo que identifica o pagamento;
//  - valores aceitos em x-qrcode-expiration-time.
// O restante segue o fluxo público: OAuth client_credentials + POST /v1/payments/qrcode/pix.
//
// Cartão: usar o checkout hospedado/iframe da Getnet para o número do cartão nunca passar
// por este servidor (escopo PCI DSS SAQ A). Não implementar tokenização aqui.

const BASES = {
  sandbox: 'https://api-sandbox.getnet.com.br',
  homologacao: 'https://api-homologacao.getnet.com.br',
  producao: 'https://api.getnet.com.br',
};

const base = () => BASES[process.env.GETNET_AMBIENTE] || BASES.sandbox;
let tokenCache = null;

async function accessToken() {
  if (tokenCache && tokenCache.expira > Date.now() + 60_000) return tokenCache.valor;
  const credencial = Buffer.from(`${process.env.GETNET_CLIENT_ID}:${process.env.GETNET_CLIENT_SECRET}`).toString('base64');
  const resposta = await fetch(`${base()}/auth/oauth/v2/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${credencial}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'scope=oob&grant_type=client_credentials',
    signal: AbortSignal.timeout(10_000),
  });
  if (!resposta.ok) throw new Error(`Getnet OAuth HTTP ${resposta.status}`);
  const j = await resposta.json();
  if (!j.access_token) throw new Error('Getnet OAuth sem access_token');
  tokenCache = { valor: j.access_token, expira: Date.now() + (j.expires_in || 3600) * 1000 };
  return j.access_token;
}

async function chamar(caminho, { method, headers = {}, body }) {
  const resposta = await fetch(`${base()}${caminho}`, {
    method,
    headers: {
      Authorization: `Bearer ${await accessToken()}`,
      seller_id: process.env.GETNET_SELLER_ID,
      'Content-Type': 'application/json',
      ...headers,
    },
    body,
    signal: AbortSignal.timeout(15_000),
  });
  // Nunca registrar o corpo da resposta: pode ter dados do cliente.
  if (!resposta.ok) throw new Error(`Getnet ${caminho} HTTP ${resposta.status}`);
  return resposta.json();
}

function mapearStatus(s) {
  const v = String(s || '').toUpperCase();
  if (['APPROVED', 'PAID', 'CONFIRMED'].includes(v)) return 'aprovado';
  if (['DENIED', 'ERROR'].includes(v)) return 'negado';
  if (['CANCELED', 'CANCELLED', 'EXPIRED'].includes(v)) return 'cancelado';
  return 'pendente';
}

module.exports = {
  nome: 'getnet',
  async criarPix({ pedidoId, totalCentavos, clienteId }) {
    const j = await chamar('/v1/payments/qrcode/pix', {
      method: 'POST',
      headers: { 'x-qrcode-expiration-time': '1800' },
      body: JSON.stringify({ amount: totalCentavos, currency: 'BRL', order_id: pedidoId, customer_id: clienteId }),
    });
    const extra = j.additional_data || {};
    if (!j.payment_id || !extra.qr_code) throw new Error('Resposta Pix da Getnet incompleta');
    return { pagamentoId: String(j.payment_id), copiaECola: String(extra.qr_code), expiraEm: extra.expiration_date_qrcode || null };
  },
  async consultar(pagamentoId) {
    // CONFIRMAR o caminho na documentação de lojista.
    const j = await chamar(`/v1/payments/qrcode/${encodeURIComponent(pagamentoId)}`, { method: 'GET' });
    const valor = Number(j.amount);
    return { status: mapearStatus(j.status), valorCentavos: Number.isInteger(valor) ? valor : null };
  },
};
