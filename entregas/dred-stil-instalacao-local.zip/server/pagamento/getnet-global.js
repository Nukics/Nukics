// Contratos oficiais: docs.globalgetnet.com, Global API + Web Checkout v1.
// PAN/CVV são capturados exclusivamente pelo iframe da Getnet.
const { ErroHttp } = require('../http');

function configuracao() {
  const ambiente = process.env.GETNET_GLOBAL_AMBIENTE || 'homologacao';
  if (!['homologacao', 'producao'].includes(ambiente)) throw new ErroHttp(503, 'Ambiente Getnet inválido.');
  if (ambiente === 'producao' && process.env.GETNET_GLOBAL_PRODUCAO_LIBERADA !== 'sim') {
    throw new ErroHttp(503, 'Conclua a homologação antes de liberar a Getnet em produção.');
  }
  return {
    ambiente,
    api: ambiente === 'producao' ? 'https://api.globalgetnet.com' : 'https://api.pre.globalgetnet.com',
    web: ambiente === 'producao' ? 'https://www.globalgetnet.com' : 'https://www.pre.globalgetnet.com',
  };
}

function configurado() {
  try { configuracao(); } catch { return false; }
  return ['CLIENT_ID', 'CLIENT_SECRET', 'SELLER_ID', 'WEBHOOK_USER', 'WEBHOOK_PASSWORD']
    .every((nome) => Boolean(process.env[`GETNET_GLOBAL_${nome}`]))
    && process.env.GETNET_GLOBAL_WEBHOOK_PASSWORD.length >= 16;
}

// Uma instância atende requisições concorrentes com uma única renovação do token.
let cache;
let renovacao;
async function accessToken() {
  const { api } = configuracao();
  const id = process.env.GETNET_GLOBAL_CLIENT_ID;
  const secret = process.env.GETNET_GLOBAL_CLIENT_SECRET;
  if (!id || !secret) throw new ErroHttp(503, 'Credenciais Getnet não configuradas.');
  // Não mantém a senha em logs/erros nem reutiliza o token após troca da configuração.
  const chave = require('crypto').createHash('sha256').update(`${api}\0${id}\0${secret}`).digest('hex');
  if (cache?.chave === chave && cache.expira > Date.now() + 60_000) return cache.token;
  if (renovacao?.chave === chave) return renovacao.promise;
  const promise = (async () => {
    let r;
    try {
      r = await fetch(`${api}/authentication/oauth2/access_token`, {
        method: 'POST', redirect: 'error', signal: AbortSignal.timeout(10_000),
        headers: {
          Authorization: `Basic ${Buffer.from(`${id}:${secret}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json',
        },
        body: new URLSearchParams({ grant_type: 'client_credentials' }).toString(),
      });
    } catch { throw new ErroHttp(502, 'Não foi possível autenticar na Getnet.'); }
    if (!r.ok) throw new ErroHttp(502, `Autenticação Getnet indisponível (HTTP ${r.status}).`);
    const j = await r.json().catch(() => ({}));
    if (typeof j.access_token !== 'string' || !j.access_token || !Number.isFinite(j.expires_in) || j.expires_in <= 0) {
      throw new ErroHttp(502, 'Resposta de autenticação Getnet inválida.');
    }
    cache = { chave, token: j.access_token, expira: Date.now() + j.expires_in * 1000 };
    return cache.token;
  })();
  renovacao = { chave, promise };
  try { return await promise; } finally { if (renovacao?.promise === promise) renovacao = null; }
}

async function chamar(caminho, { method = 'GET', dados } = {}) {
  const { api } = configuracao();
  const token = await accessToken();
  let r;
  try {
    r = await fetch(`${api}/dpy/web-checkout/v1${caminho}`, {
      method, redirect: 'error', signal: AbortSignal.timeout(15_000),
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Accept: 'application/json' },
      body: dados === undefined ? undefined : JSON.stringify(dados),
    });
  } catch { throw new ErroHttp(502, 'A Getnet não respondeu. A operação precisa ser conciliada antes de uma nova tentativa.'); }
  if (r.status === 401) cache = null;
  // Nunca repetir automaticamente POST: o contrato não garante idempotência desta rota.
  if (!r.ok) throw new ErroHttp(502, `Serviço de pagamento Getnet indisponível (HTTP ${r.status}).`);
  if (r.status === 204) return null;
  return r.json().catch(() => { throw new ErroHttp(502, 'Resposta Getnet inválida.'); });
}

const centavos = (n) => Math.round(n * 100);
const enderecoApi = (e) => ({
  street: e.rua, number: e.numero, complement: e.complemento || '', district: e.bairro,
  city: e.cidade, state: e.uf, country: 'BR', postal_code: e.cep,
});

async function criarCheckout({ pedido, usuario, cliente, cobranca }) {
  const nomes = cliente.nome.trim().split(/\s+/);
  if (nomes.length < 2 || nomes[0].length > 40 || nomes.slice(1).join(' ').length > 80) {
    throw new ErroHttp(400, 'Informe o nome completo para o pagamento.');
  }
  const endereco = enderecoApi(cobranca);
  const product = pedido.itens.map((i) => ({ product_type: 'physical_goods', title: i.nome, value: centavos(i.preco), quantity: i.qtd }));
  // O frete integra o total como serviço; não enviar shipping_amount evita somá-lo duas vezes.
  if (pedido.frete) product.push({ product_type: 'service', title: 'Entrega do pedido', value: centavos(pedido.frete), quantity: 1 });
  const dados = {
    order_id: pedido.id, reference_code: pedido.id, expires_at: '30m',
    payment: { currency: 'BRL', amount: centavos(pedido.total) }, product,
    customer: {
      customer_id: cliente.cpf, document_type: 'CPF', document_number: cliente.cpf,
      first_name: nomes[0], last_name: nomes.slice(1).join(' '), name: cliente.nome,
      email: usuario.email, phone_number: `55${cliente.telefone}`, billing_address: endereco,
    },
    pickup_store: !pedido.entrega,
    ...(pedido.entrega ? { shipping: { first_name: nomes[0], last_name: nomes.slice(1).join(' '), address: endereco } } : {}),
  };
  const j = await chamar('/payment-intent', { method: 'POST', dados });
  if (!/^[0-9a-f-]{36}$/i.test(j.payment_intent_id || '')) throw new ErroHttp(502, 'Resposta do checkout Getnet incompleta.');
  return {
    pagamentoId: j.payment_intent_id,
    dadosPagamento: { tipo: 'getnet-global', ambiente: configuracao().ambiente, paymentIntentId: j.payment_intent_id },
  };
}

function mapearStatus(s) {
  if (s === 'paid') return 'aprovado';
  if (s === 'denied') return 'negado';
  if (['cancelled', 'expired'].includes(s)) return 'cancelado';
  // pending/registered/error continuam em conciliação; erro de processamento não prova recusa.
  return 'pendente';
}

async function consultar(id) {
  const j = await chamar(`/payment-intent/${encodeURIComponent(id)}`);
  if (j.payment_intent_id !== id || j.seller_id !== process.env.GETNET_GLOBAL_SELLER_ID || j.country !== 'BR') {
    throw new ErroHttp(502, 'Identificação do pagamento Getnet divergente.');
  }
  const valor = j.payment?.amount;
  const status = mapearStatus(j.status);
  if (status === 'aprovado' && (!Number.isSafeInteger(valor) || valor <= 0 || j.payment?.currency !== 'BRL')) {
    throw new ErroHttp(502, 'Não foi possível conferir o valor do pagamento Getnet.');
  }
  return { status, valorCentavos: Number.isSafeInteger(valor) ? valor : null, pedidoId: j.order_id };
}

async function cancelar(id) {
  await chamar(`/payment-intent/${encodeURIComponent(id)}`, { method: 'PATCH', dados: { status: 'cancelled' } });
}

async function verificarConfiguracao() {
  const seller = await chamar('/sellers');
  const tecnica = await chamar('/technical-configurations');
  const comercial = await chamar('/business-configurations');
  return { seller, tecnica, comercial };
}

async function configurarNotificacao(appUrl) {
  if (configuracao().ambiente !== 'homologacao') throw new ErroHttp(400, 'Este utilitário configura somente homologação.');
  const url = new URL(appUrl);
  if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/' || url.search || url.hash) {
    throw new ErroHttp(400, 'APP_URL deve ser a origem HTTPS pública da loja.');
  }
  if (!configurado()) throw new ErroHttp(503, 'Configure as variáveis Getnet antes de registrar o webhook.');
  // PATCH parcial, conforme Swagger: preserva as opções comerciais e o layout existentes.
  return chamar('/technical-configurations', { method: 'PATCH', dados: {
    success_url: `${url.origin}/checkout`, error_url: `${url.origin}/checkout`,
    notification: {
      url: `${url.origin}/api/webhooks/getnet-global`, authentication_type: 'user_credentials',
      user_credentials: { user: process.env.GETNET_GLOBAL_WEBHOOK_USER, password: process.env.GETNET_GLOBAL_WEBHOOK_PASSWORD },
    },
  } });
}

module.exports = { nome: 'getnet-global', configuracao, configurado, accessToken, criarCheckout, consultar, cancelar, mapearStatus, verificarConfiguracao, configurarNotificacao };
