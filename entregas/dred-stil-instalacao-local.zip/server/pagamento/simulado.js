// Provedor falso para desenvolvimento e testes. Bloqueado em produção (ver ambiente.js).
const crypto = require('crypto');

const pagamentos = (globalThis.__pagamentosSimulados ??= new Map());

module.exports = {
  nome: 'simulado',
  async criarPix({ totalCentavos }) {
    const pagamentoId = `sim_${crypto.randomUUID()}`;
    pagamentos.set(pagamentoId, { status: 'pendente', valor: totalCentavos });
    return {
      pagamentoId,
      copiaECola: `00020126SIMULADO${pagamentoId.slice(4, 16)}5204000053039865802BR6009PINHAIS6304ABCD`,
      expiraEm: new Date(Date.now() + 30 * 60_000).toISOString(),
    };
  },
  async consultar(pagamentoId) {
    const p = pagamentos.get(pagamentoId);
    return p ? { status: p.status, valorCentavos: p.valor } : { status: 'cancelado', valorCentavos: null };
  },
  // Usado pelos testes e pela rota de desenvolvimento para "pagar" o Pix.
  definirStatus(pagamentoId, status, valorCentavos) {
    const p = pagamentos.get(pagamentoId);
    if (p) pagamentos.set(pagamentoId, { status, valor: valorCentavos ?? p.valor });
  },
};
