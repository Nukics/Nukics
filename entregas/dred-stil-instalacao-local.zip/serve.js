// Inicia a loja localmente: node serve.js  (porta padrão 5173; mude com PORT=...)
// As chaves ficam em .env.local (copie de .env.example).
if (Number(process.versions.node.split('.')[0]) < 22) {
  console.error('Use Node.js 22 ou superior (recomendado: Node.js 24 LTS).');
  process.exit(1);
}
try {
  process.loadEnvFile(require('path').join(__dirname, '.env.local'));
} catch (erro) {
  if (erro.code !== 'ENOENT') {
    console.error('Não foi possível ler .env.local. Confira o formato e as permissões do arquivo.');
    process.exit(1);
  }
  console.warn('Arquivo .env.local não encontrado: usando só as variáveis de ambiente do sistema.');
}
const ausentes = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'].filter((nome) => !process.env[nome]);
if (ausentes.length) {
  console.error(`Configure ${ausentes.join(', ')} em .env.local. Para testar sem banco real, use npm run demo. Diagnóstico: npm run verificar.`);
  process.exit(1);
}
require('./server').iniciar();
