// Função da Vercel: recebe tudo que não é arquivo de public/ (páginas e /api/...).
module.exports = require('../server').tratarRequisicao;
