// Cria a conta admin da loja. Só pode existir uma: se já houver admin, o script recusa
// (e o banco também, pelo índice usuarios_admin_unico).
// Uso: node scripts/criar-admin.js email@exemplo.com "Nome Completo" apelido "41999999999" "senha"
try {
  process.loadEnvFile(require('path').join(__dirname, '..', '.env.local'));
} catch (erro) {
  if (erro.code !== 'ENOENT') {
    console.error('Não foi possível ler .env.local. Confira o formato e as permissões do arquivo.');
    process.exit(1);
  }
}

async function principal([email, nome, apelido, telefone, senha]) {
  if (!email || !nome || !apelido || !telefone || !senha) {
    throw new Error('Uso: node scripts/criar-admin.js <email> "<nome completo>" <apelido> <telefone> <senha>');
  }
  const db = require('../server/db');
  const validar = require('../server/validar');
  const { hashSenha } = require('../server/auth');
  const atual = await db.usuarios.admin();
  if (atual) throw new Error(`A loja já tem um admin (${atual.email}). Só pode existir um.`);
  const dados = validar.cadastro({ nome, apelido, email, telefone, senha });
  const { usuario, mensagem } = await db.usuarios.criar({ ...dados, senha: hashSenha(dados.senha), papel: 'admin' });
  if (!usuario) throw new Error(mensagem);
  return `Conta admin criada para ${usuario.email}.`;
}

principal(process.argv.slice(2)).then(console.log, (erro) => {
  console.error(erro.message);
  process.exitCode = 1;
});
