// Diagnóstico somente leitura. Nunca imprime credenciais ou registros do banco.
const path = require('path');
const { validarUrl, validarChave } = require('./configurar-local');

const CONSULTAS = [
  ['produtos', 'handle,categoria,cores,estoque_id,codigo_ncm', '003'],
  ['usuarios', 'id,apelido,cpf,email_verificado_em,dois_fatores', '002 e 003'],
  ['conteudo', 'chave', 'estrutura.sql'],
  ['pedidos', 'id,pagamento_status,estoque_baixado', '002 e 003'],
  ['estoques', 'id,quantidade,cor,arquivado', '005'],
  ['estoque_produtos_cores', 'handle,cor,estoque_id', '005'],
  ['estoque_movimentos', 'id,estoque_id', '003'],
  ['pagamento_eventos', 'pedido_id', '002'],
  ['notas_fiscais', 'id,pedido_id', '003'],
  ['curtidas', 'usuario_id,handle', '002'],
];

async function verificar({ env = process.env, versaoNode = process.versions.node, criarCliente } = {}) {
  const checks = [];
  const adicionar = (nivel, nome, mensagem) => checks.push({ nivel, nome, mensagem });
  const producao = env.NODE_ENV === 'production';
  const presente = (nome) => typeof env[nome] === 'string' && env[nome].trim().length > 0;
  if (Number(versaoNode.split('.')[0]) < 22) {
    adicionar('erro', 'Node.js', 'Use Node.js 22 ou superior. Recomendado: Node.js 24 LTS.');
    return checks;
  }
  adicionar('ok', 'Node.js', `Versão ${versaoNode} compatível.`);
  let urlValida = false;
  let chaveValida = false;
  try { validarUrl(env.SUPABASE_URL); urlValida = true; } catch {}
  try { validarChave(env.SUPABASE_SERVICE_ROLE_KEY); chaveValida = true; } catch {}
  adicionar(urlValida ? 'ok' : 'erro', 'SUPABASE_URL', urlValida
    ? 'Endereço configurado; o valor não é exibido.'
    : 'Configure a URL HTTPS do seu projeto Supabase em .env.local ou nas variáveis da hospedagem.');
  adicionar(chaveValida ? 'ok' : 'erro', 'SUPABASE_SERVICE_ROLE_KEY', chaveValida
    ? 'Chave de servidor em formato válido; o valor não é exibido.'
    : 'Configure a chave Secret/service_role do servidor. A chave anon/publishable não serve e nunca deve substituir a chave do backend.');
  adicionar(presente('SESSION_SECRET') ? 'ok' : producao ? 'erro' : 'aviso', 'SESSION_SECRET', presente('SESSION_SECRET')
    ? 'Segredo de sessão configurado; o valor não é exibido.'
    : 'Configure um segredo fixo. Em desenvolvimento, as sessões temporárias se perdem ao reiniciar.');

  if (producao) {
    adicionar(presente('APP_URL') || presente('VERCEL_PROJECT_PRODUCTION_URL') ? 'ok' : 'erro', 'Endereço público',
      presente('APP_URL') || presente('VERCEL_PROJECT_PRODUCTION_URL') ? 'Origem pública configurada.' : 'Configure APP_URL para os links enviados por e-mail.');
    const email = presente('RESEND_API_KEY') && presente('EMAIL_FROM');
    adicionar(email ? 'ok' : 'erro', 'E-mail', email ? 'Envio configurado; confirme o domínio remetente na Resend.'
      : 'Configure RESEND_API_KEY e EMAIL_FROM para confirmação de conta, recuperação de senha e códigos do admin.');
    adicionar(presente('CRON_SECRET') ? 'ok' : 'aviso', 'Tarefas agendadas', presente('CRON_SECRET')
      ? 'Autenticação do cron configurada.' : 'Configure CRON_SECRET para a conciliação/expiração de pagamentos.');
  } else {
    adicionar('aviso', 'E-mail local', presente('RESEND_API_KEY')
      ? 'Este ambiente está configurado para enviar e-mails reais.'
      : 'Sem Resend, os e-mails de teste são gravados em .dev-emails/.');
  }

  const pagamento = env.PAGAMENTO_PROVEDOR;
  if (pagamento === 'getnet-global') {
    const faltam = ['CLIENT_ID', 'CLIENT_SECRET', 'SELLER_ID', 'WEBHOOK_USER', 'WEBHOOK_PASSWORD']
      .map((n) => `GETNET_GLOBAL_${n}`).filter((n) => !presente(n));
    if (faltam.length) adicionar('erro', 'Getnet Global', `Faltam: ${faltam.join(', ')}.`);
    else if (env.GETNET_GLOBAL_WEBHOOK_PASSWORD.length < 16) adicionar('erro', 'Getnet Global', 'A senha do webhook precisa ter pelo menos 16 caracteres.');
    else adicionar('ok', 'Getnet Global', 'Credenciais presentes. A autenticação e as habilitações reais ainda precisam da verificação de homologação.');
    const ambiente = env.GETNET_GLOBAL_AMBIENTE || 'homologacao';
    if (!['homologacao', 'producao'].includes(ambiente)) adicionar('erro', 'Ambiente Getnet', 'Use homologacao ou producao.');
    else if (ambiente === 'producao' && env.GETNET_GLOBAL_PRODUCAO_LIBERADA !== 'sim') {
      adicionar('erro', 'Ambiente Getnet', 'Produção está bloqueada até a homologação. Consulte docs/GETNET.md.');
    }
  } else if (pagamento === 'getnet') {
    const faltam = ['GETNET_CLIENT_ID', 'GETNET_CLIENT_SECRET', 'GETNET_SELLER_ID', 'GETNET_WEBHOOK_TOKEN'].filter((n) => !presente(n));
    adicionar(faltam.length ? 'erro' : 'ok', 'Getnet Pix', faltam.length ? `Faltam: ${faltam.join(', ')}.` : 'Credenciais do Pix legado presentes.');
  } else if (pagamento === 'simulado') {
    adicionar(producao ? 'erro' : 'aviso', 'Pagamento', producao
      ? 'Pagamento simulado não funciona em produção.' : 'Somente pagamentos simulados; nenhuma cobrança real.');
  } else {
    adicionar(pagamento ? 'erro' : 'aviso', 'Pagamento', pagamento
      ? 'PAGAMENTO_PROVEDOR inválido. Use getnet-global, getnet ou simulado (somente desenvolvimento).'
      : 'Sem provedor configurado, a compra segue pelo WhatsApp.');
  }
  const frete = presente('MELHOR_ENVIO_CEP_ORIGEM') && (presente('MELHOR_ENVIO_TOKEN')
    || (presente('MELHOR_ENVIO_CLIENT_ID') && presente('MELHOR_ENVIO_CLIENT_SECRET')));
  adicionar(frete ? 'ok' : 'aviso', 'Frete', frete
    ? 'Credenciais presentes. Com OAuth, conecte a conta pelo admin antes de calcular entregas.'
    : producao ? 'Sem frete configurado, o checkout online permanece desligado e a loja usa WhatsApp.'
      : 'Sem credenciais de frete, o desenvolvimento usa cotações simuladas.');

  if (!urlValida || !chaveValida) return checks;
  const factory = criarCliente || require('@supabase/supabase-js').createClient;
  let cliente;
  try {
    cliente = factory(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { fetch: (url, init) => fetch(url, { ...init, signal: AbortSignal.timeout(10_000) }) },
    });
  } catch {
    adicionar('erro', 'Supabase', 'Não foi possível iniciar a conexão. Confira a URL e a chave do servidor.');
    return checks;
  }
  async function conferir(tabela, colunas, migracao) {
    try {
      // limit(0) verifica a estrutura sem retornar dados de clientes ou da loja.
      const r = await cliente.from(tabela).select(colunas).limit(0);
      if (!r.error) return { nivel: 'ok', nome: `Banco: ${tabela}`, mensagem: 'Tabela e colunas disponíveis.' };
      const codigo = /^[A-Z0-9_]{1,20}$/.test(r.error.code || '') ? ` (${r.error.code})` : '';
      return { nivel: 'erro', nome: `Banco: ${tabela}`, mensagem: [401, 403].includes(r.status)
        ? 'Acesso recusado. Confira a URL, a chave e as permissões do servidor.'
        : `Não foi possível verificar a estrutura${codigo}. Confira a conexão e a migração ${migracao}; não reimporte dados iniciais em banco existente.` };
    } catch {
      return { nivel: 'erro', nome: `Banco: ${tabela}`, mensagem: 'Não foi possível conectar ao Supabase. Confira a URL e o acesso de rede.' };
    }
  }
  const inicial = await conferir('categorias', 'slug,pai,no_menu', 'estrutura.sql/002');
  checks.push(inicial);
  if (inicial.nivel !== 'ok') return checks;
  checks.push(...await Promise.all(CONSULTAS.map((q) => conferir(...q))));
  if (typeof cliente.storage?.getBucket === 'function') {
    try {
      const bucket = await cliente.storage.getBucket('produtos');
      adicionar(!bucket.error && bucket.data?.public === true ? 'ok' : 'erro', 'Fotos', !bucket.error && bucket.data?.public === true
        ? 'Bucket público produtos disponível.' : 'Confira o bucket público produtos no Supabase Storage (estrutura.sql).');
    } catch { adicionar('erro', 'Fotos', 'Não foi possível verificar o bucket produtos no Supabase Storage.'); }
  }
  adicionar('aviso', 'Migrações e integrações', 'Esta leitura não confirma gatilhos SQL nem realiza pagamentos. Confirme a migração 006 no SQL Editor e siga docs/GETNET.md para homologação real.');
  return checks;
}

if (require.main === module) {
  let podeExecutar = true;
  try { process.loadEnvFile(path.join(__dirname, '..', '.env.local')); }
  catch (erro) {
    if (erro.code !== 'ENOENT') {
      console.error('Não foi possível ler .env.local. Confira o formato e as permissões do arquivo.');
      process.exitCode = 1;
      podeExecutar = false;
    }
  }
  if (podeExecutar) verificar().then((checks) => {
    for (const c of checks) console.log(`[${c.nivel.toUpperCase()}] ${c.nome}: ${c.mensagem}`);
    const erros = checks.filter((c) => c.nivel === 'erro').length;
    console.log(erros ? `Corrija ${erros} pendência(s) e execute npm run verificar novamente.`
      : 'Checagens concluídas. Valide login, fotos e pagamentos em homologação antes de publicar.');
    process.exitCode = erros ? 1 : 0;
  }).catch(() => { console.error('Diagnóstico não concluído. Confira a instalação e execute novamente.'); process.exitCode = 1; });
}

module.exports = { verificar };
