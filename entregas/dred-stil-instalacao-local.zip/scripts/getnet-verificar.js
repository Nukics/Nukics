// Sem argumentos: somente leitura. Nunca imprime tokens, segredos ou dados cadastrais.
try { process.loadEnvFile(require('path').join(__dirname, '..', '.env.local')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
const getnet = require('../server/pagamento/getnet-global');

(async () => {
  if (process.argv.includes('--registrar-webhook-homologacao')) {
    await getnet.configurarNotificacao(process.env.APP_URL);
    console.log('Configuração técnica de homologação atualizada.');
  }
  const { seller, tecnica, comercial } = await getnet.verificarConfiguracao();
  const payments = comercial.payments || comercial;
  const enabled = (v) => Boolean(v?.enable ?? v?.enabled);
  // A resposta completa pode conter dados pessoais e configurações privadas. Relatar só capacidades.
  console.log(JSON.stringify({
    ambiente: getnet.configuracao().ambiente,
    consultaDaConta: Boolean(seller),
    webhookConfigurado: Boolean(tecnica.notification?.url),
    autenticacaoWebhook: tecnica.notification?.authentication_type || null,
    cartaoHabilitadoNaConfiguracao: enabled(payments.credit),
    pixHabilitadoNaConfiguracao: enabled(payments.instant_payment),
    planosDeParcelamento: (payments.credit?.brands || []).map((b) => ({
      bandeira: b.brand, planos: b.supported_installments || b.suported_installments || [],
    })),
  }, null, 2));
})().catch((e) => { console.error(e instanceof require('../server/http').ErroHttp ? e.message : 'Não foi possível verificar a configuração Getnet.'); process.exitCode = 1; });
