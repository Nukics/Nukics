// Cria a configuração privada no computador da pessoa que executa este comando.
// Não envia credenciais à rede e nunca altera uma configuração já existente.
const fs = require('node:fs/promises');
const path = require('node:path');
const { randomBytes } = require('node:crypto');
const readline = require('node:readline');
const { Writable } = require('node:stream');

const RAIZ = path.join(__dirname, '..');

function validarUrl(valor) {
  if (typeof valor !== 'string' || /[\u0000-\u0020\u007f]/.test(valor)) {
    throw new Error('A URL deve ser HTTPS, sem espaços ou quebras de linha.');
  }
  let url;
  try { url = new URL(valor); } catch {}
  if (!url || url.protocol !== 'https:' || url.username || url.password || url.search || url.hash
    || url.port || url.pathname !== '/' || !url.hostname.includes('.')
    || /(?:SEU-PROJETO|placeholder|exemplo|example|localhost)/i.test(url.hostname)
    || /\.(?:local|invalid|test)$/i.test(url.hostname)) {
    throw new Error('Use a Project URL HTTPS do seu projeto Supabase, sem caminhos ou parâmetros.');
  }
  return url.origin;
}

function validarChave(valor) {
  if (typeof valor !== 'string' || !/^[A-Za-z0-9._-]+$/.test(valor)) {
    throw new Error('A chave do servidor está em formato inválido. Cole somente a chave, sem aspas ou espaços.');
  }
  if (/^sb_secret_[A-Za-z0-9_-]{16,}$/.test(valor)) return valor;
  const partes = valor.split('.');
  if (partes.length === 3 && partes.every((p) => /^[A-Za-z0-9_-]+$/.test(p))) {
    try {
      const dados = JSON.parse(Buffer.from(partes[1], 'base64url').toString('utf8'));
      if (dados.role === 'service_role') return valor;
    } catch {}
  }
  throw new Error('Use uma chave Secret (sb_secret_...) ou a chave legada service_role. A chave anon/publishable não serve para o backend.');
}

async function existe(caminho) {
  try { await fs.lstat(caminho); return true; }
  catch (erro) { if (erro.code === 'ENOENT') return false; throw erro; }
}

async function criarConfiguracao({ diretorio = RAIZ, urlSupabase, chaveServidor } = {}) {
  const caminho = path.join(diretorio, '.env.local');
  if (await existe(caminho)) return { criado: false, caminho };

  const url = validarUrl(urlSupabase);
  const chave = validarChave(chaveServidor);
  const exemplo = await fs.readFile(path.join(diretorio, '.env.example'), 'utf8');
  const valores = {
    SUPABASE_URL: url,
    SUPABASE_SERVICE_ROLE_KEY: chave,
    SESSION_SECRET: randomBytes(32).toString('hex'),
    APP_URL: 'http://localhost:5173',
    PAGAMENTO_PROVEDOR: '',
    GETNET_WEBHOOK_TOKEN: randomBytes(32).toString('hex'),
    GETNET_GLOBAL_WEBHOOK_USER: `dredstil_${randomBytes(8).toString('hex')}`,
    GETNET_GLOBAL_WEBHOOK_PASSWORD: randomBytes(32).toString('hex'),
    CRON_SECRET: randomBytes(32).toString('hex'),
  };
  let conteudo = exemplo.replace(/^# Copie para .env.local.*\r?\n# Nunca coloque valores reais.*\r?\n/, [
    '# Configuração privada deste computador. Não envie este arquivo nem publique no GitHub.',
    '# Criado por npm run configurar. Credenciais de integrações ainda precisam ser configuradas.',
    '',
  ].join('\n'));
  for (const [nome, valor] of Object.entries(valores)) {
    const linha = new RegExp(`^${nome}=.*$`, 'm');
    if (!linha.test(conteudo)) throw new Error(`O modelo .env.example está incompleto: falta ${nome}.`);
    conteudo = conteudo.replace(linha, () => `${nome}=${valor}`);
  }
  try { await fs.writeFile(caminho, conteudo, { flag: 'wx', mode: 0o600 }); }
  catch (erro) {
    // O arquivo pode ter sido criado por outra execução entre a consulta e a escrita.
    if (erro.code === 'EEXIST') return { criado: false, caminho };
    throw erro;
  }
  return { criado: true, caminho };
}

function avisarExistente(saida) {
  saida.write('O arquivo .env.local já existe e foi preservado.\n');
  saida.write('Para alterar valores, abra esse arquivo no seu editor. Depois execute npm run verificar.\n');
}

async function configurarInterativo({ diretorio = RAIZ, entrada = process.stdin, saida = process.stdout,
  versaoNode = process.versions.node } = {}) {
  if (Number(versaoNode.split('.')[0]) < 22) throw new Error('Instale Node.js 22 ou superior antes de configurar. Recomendado: Node.js 24 LTS.');
  const caminho = path.join(diretorio, '.env.local');
  if (await existe(caminho)) {
    avisarExistente(saida);
    return { criado: false, caminho };
  }
  saida.write('Configuração local da Dred Stil. Nenhum valor será enviado à rede.\n');
  saida.write('No Supabase, copie a Project URL e a chave Secret ou service_role do servidor.\n');
  saida.write('As entradas ficam ocultas: cole cada valor e pressione Enter. Não compartilhe a chave no chat.\n\n');

  // Mesmo colando várias linhas de uma vez, o readline nunca pode ecoar uma chave.
  const silencioso = new Writable({ write(_texto, _encoding, callback) { callback(); } });
  const rl = readline.createInterface({ input: entrada, output: silencioso, terminal: Boolean(entrada.isTTY) });
  rl.on('SIGINT', () => rl.close());
  const linhas = rl[Symbol.asyncIterator]();
  async function perguntar(pergunta) {
    saida.write(pergunta);
    const proxima = await linhas.next();
    saida.write('\n');
    if (proxima.done) throw new Error('Configuração cancelada. Nenhum arquivo foi criado.');
    return proxima.value;
  }
  let resultado;
  try {
    const urlSupabase = validarUrl(await perguntar('Project URL HTTPS: '));
    const chaveServidor = validarChave(await perguntar('Chave Secret/service_role (oculta): '));
    resultado = await criarConfiguracao({ diretorio, urlSupabase, chaveServidor });
  } finally {
    rl.close();
    silencioso.end();
  }
  if (!resultado.criado) avisarExistente(saida);
  else {
    saida.write('\n.env.local criado com as suas credenciais Supabase e segredos de sessão gerados localmente.\n');
    saida.write('O pagamento online permanece desligado até configurar e homologar a Getnet. A loja usa WhatsApp.\n');
    saida.write('O banco e as integrações ainda precisam ser conferidos. Execute npm run verificar e depois npm start.\n');
    saida.write('Abra http://localhost:5173. Não envie .env.local nem inclua esse arquivo em ZIPs.\n');
  }
  return resultado;
}

if (require.main === module) {
  configurarInterativo().catch((erro) => {
    // Erros próprios não contêm valores informados; erros do sistema não são reproduzidos.
    const conhecidos = [
      'A URL deve ser HTTPS', 'Use a Project URL', 'A chave do servidor', 'Use uma chave Secret',
      'Instale Node.js', 'Configuração cancelada', 'O modelo .env.example está incompleto:',
    ];
    console.error(conhecidos.some((inicio) => erro.message?.startsWith(inicio))
      ? erro.message : 'Não foi possível criar .env.local. Confira as permissões da pasta e tente novamente.');
    process.exitCode = 1;
  });
}

module.exports = { criarConfiguracao, configurarInterativo, validarUrl, validarChave };
