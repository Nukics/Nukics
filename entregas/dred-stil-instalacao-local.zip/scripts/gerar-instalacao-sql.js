// Gera somente um arquivo local; não se conecta ao Supabase nem executa SQL.
const fs = require('node:fs');
const path = require('node:path');

const RAIZ = path.join(__dirname, '..');
const ARQUIVOS = [
  'supabase/estrutura.sql',
  'supabase/migracoes/002-contas-pagamentos-seguranca.sql',
  'supabase/migracoes/003-cadastro-estoque-notas.sql',
  'supabase/migracoes/004-getnet-global.sql',
  'supabase/migracoes/005-estoque-por-cor.sql',
  'supabase/migracoes/006-categorias-mover.sql',
  'supabase/dados-iniciais.sql',
];

// Só remove o par externo, depois de conferir que fora dele há apenas comentários.
// Os BEGIN/END das funções PL/pgSQL permanecem intactos.
function semTransacaoExterna(sql) {
  const linhas = sql.replace(/\r\n/g, '\n').trim().split('\n');
  const inicio = linhas.findIndex((l) => /^\s*begin\s*;\s*$/i.test(l));
  const fim = linhas.findLastIndex((l) => /^\s*commit\s*;\s*$/i.test(l));
  if (inicio < 0 && fim < 0) return linhas.join('\n');
  const soComentarios = (texto) => !texto.replace(/--[^\n]*/g, '').trim();
  if (inicio < 0 || fim <= inicio || !soComentarios(linhas.slice(0, inicio).join('\n')) ||
      !soComentarios(linhas.slice(fim + 1).join('\n'))) {
    throw new Error('Transação externa inesperada: revise o gerador antes de atualizar o SQL.');
  }
  linhas.splice(fim, 1);
  linhas.splice(inicio, 1);
  return linhas.join('\n');
}

function gerarInstalacao(raiz = RAIZ) {
  const partes = ARQUIVOS.map((arquivo) => `-- Fonte: ${arquivo}\n${semTransacaoExterna(fs.readFileSync(path.join(raiz, arquivo), 'utf8'))}`);
  return `-- Dred Stil: instalação completa SOMENTE em projeto Supabase novo.\n` +
    `-- Gerado por npm run sql:instalar. Não edite este arquivo à mão.\n` +
    `-- Abra no SQL Editor e execute inteiro uma única vez como administrador.\n` +
    `-- Banco existente: aplique apenas as migrações pendentes; não execute este arquivo.\n` +
    `-- Não cria conta admin nem inventa saldos por cor. Revise os dados iniciais antes de vender.\n\n` +
    `begin;\n\n` +
    `do $instalacao_nova$\n` +
    `declare v_tabela text;\n` +
    `begin\n` +
    `  foreach v_tabela in array array['categorias', 'produtos', 'usuarios', 'curtidas', 'pedidos', 'conteudo', 'estoques'] loop\n` +
    `    if to_regclass('public.' || v_tabela) is not null then\n` +
    `      raise exception 'Instalação recusada: a tabela public.% já existe. Use somente as migrações pendentes para atualizar a loja; nenhum dado foi alterado.', v_tabela;\n` +
    `    end if;\n` +
    `  end loop;\n` +
    `end;\n` +
    `$instalacao_nova$;\n\n` +
    partes.join('\n\n') +
    `\n\n-- Atualiza o catálogo exposto pela Data API do Supabase após o commit.\n` +
    `notify pgrst, 'reload schema';\n\ncommit;\n`;
}

if (require.main === module) {
  const destino = path.join(RAIZ, 'supabase', 'instalar-loja-nova.sql');
  fs.writeFileSync(destino, gerarInstalacao(), { encoding: 'utf8' });
  console.log('Gerado: supabase/instalar-loja-nova.sql (arquivo local; nenhum banco foi alterado).');
}

module.exports = { ARQUIVOS, gerarInstalacao, semTransacaoExterna };
