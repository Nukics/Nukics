// Contas: login, limites, recuperação de senha e verificação em duas etapas.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, ultimoEmail, tokenDoEmail, codigoDoEmail, contaConfirmada, novoIp, dadosConta } = require('./ajuda');

let loja;
before(async () => (loja = await iniciarLoja()));
after(() => loja.fechar());

const SENHA = 'Senha-Forte-123';
const entrar = (email, senha = SENHA, ipCliente) => loja.chamar('POST', '/api/conta/entrar', { corpo: { email, senha }, ipCliente });
const eu = async (cookie) => (await loja.chamar('GET', '/api/eu', { cookie })).json.usuario;

test('cadastro, login e senha guardada com scrypt', async () => {
  const cookie = await contaConfirmada(loja, 'ana@exemplo.com');
  assert.equal((await eu(cookie)).email, 'ana@exemplo.com');
  const { rows } = await loja.pg.query(`select senha, email_verificado_em from usuarios where email = 'ana@exemplo.com'`);
  assert.match(rows[0].senha, /^scrypt\$/);
  assert.ok(!rows[0].senha.includes(SENHA));
  assert.ok(rows[0].email_verificado_em, 'e-mail confirmado pelo link');
  assert.equal((await entrar('ana@exemplo.com')).status, 200);
});

test('senha comum é recusada no cadastro', async () => {
  const r = await loja.chamar('POST', '/api/conta/cadastro', { corpo: dadosConta('fraca@exemplo.com', '12345678') });
  assert.equal(r.status, 400);
});

test('mesma mensagem para senha errada e e-mail inexistente', async () => {
  await contaConfirmada(loja, 'beto@exemplo.com');
  const errada = await entrar('beto@exemplo.com', 'senha-errada-1');
  const inexistente = await entrar('ninguem@exemplo.com', 'senha-errada-1');
  assert.equal(errada.status, 401);
  assert.equal(inexistente.status, 401);
  assert.equal(errada.json.erro, inexistente.json.erro);
});

test('limite por conta vale mesmo trocando de IP (credential stuffing) e fica no banco', async () => {
  await contaConfirmada(loja, 'alvo@exemplo.com');
  const status = [];
  for (let i = 0; i < 9; i++) status.push((await entrar('alvo@exemplo.com', `chute-${i}-x`, novoIp())).status);
  assert.deepEqual(status.slice(0, 8), Array(8).fill(401));
  assert.equal(status[8], 429);
  assert.equal((await entrar('alvo@exemplo.com', SENHA, novoIp())).status, 429, 'bloqueado mesmo com a senha certa');
  const { rows } = await loja.pg.query(`select contagem from limites where chave = 'login:conta:alvo@exemplo.com'`);
  assert.ok(rows[0].contagem >= 9);
});

test('esqueci a senha: resposta igual exista ou não a conta', async () => {
  await contaConfirmada(loja, 'existe@exemplo.com');
  const a = await loja.chamar('POST', '/api/conta/esqueci-senha', { corpo: { email: 'existe@exemplo.com' } });
  const b = await loja.chamar('POST', '/api/conta/esqueci-senha', { corpo: { email: 'naoexiste@exemplo.com' } });
  assert.equal(a.status, 200);
  assert.deepEqual(a.json, b.json);
  assert.equal(ultimoEmail('naoexiste@exemplo.com'), undefined);
});

test('redefinir senha: link de uso único, derruba as sessões e avisa por e-mail', async () => {
  const sessaoAntiga = await contaConfirmada(loja, 'reset@exemplo.com');
  await loja.chamar('POST', '/api/conta/esqueci-senha', { corpo: { email: 'reset@exemplo.com' } });
  const token = tokenDoEmail(ultimoEmail('reset@exemplo.com'), 'redefinir');
  assert.ok(token.length > 20);
  const { rows } = await loja.pg.query('select token_hash from tokens_conta');
  assert.ok(rows.every((r) => r.token_hash !== token), 'token não fica em texto puro no banco');

  const ok = await loja.chamar('POST', '/api/conta/redefinir-senha', { corpo: { token, senha: 'Nova-Senha-456' } });
  assert.equal(ok.status, 200);
  assert.equal(await eu(sessaoAntiga), null, 'sessão antiga derrubada');
  assert.equal((await entrar('reset@exemplo.com')).status, 401);
  assert.equal((await entrar('reset@exemplo.com', 'Nova-Senha-456')).status, 200);
  const reuso = await loja.chamar('POST', '/api/conta/redefinir-senha', { corpo: { token, senha: 'Outra-Senha-789' } });
  assert.equal(reuso.status, 400);
  assert.match(ultimoEmail('reset@exemplo.com').assunto, /senha foi alterada/);
});

test('link novo invalida o anterior; link expirado é recusado', async () => {
  await contaConfirmada(loja, 'dois@exemplo.com');
  await loja.chamar('POST', '/api/conta/esqueci-senha', { corpo: { email: 'dois@exemplo.com' } });
  const antigo = tokenDoEmail(ultimoEmail('dois@exemplo.com'), 'redefinir');
  await loja.chamar('POST', '/api/conta/esqueci-senha', { corpo: { email: 'dois@exemplo.com' } });
  const novo = tokenDoEmail(ultimoEmail('dois@exemplo.com'), 'redefinir');
  assert.equal((await loja.chamar('POST', '/api/conta/redefinir-senha', { corpo: { token: antigo, senha: 'Nova-Senha-456' } })).status, 400);
  await loja.pg.query(`update tokens_conta set expira_em = now() - interval '1 minute'`);
  assert.equal((await loja.chamar('POST', '/api/conta/redefinir-senha', { corpo: { token: novo, senha: 'Nova-Senha-456' } })).status, 400);
});

test('verificação em duas etapas exige e-mail confirmado e a senha', async () => {
  const r = await loja.chamar('POST', '/api/conta/cadastro', { corpo: dadosConta('semconf@exemplo.com') });
  const ativarSemConfirmar = await loja.chamar('POST', '/api/conta/dois-fatores', { cookie: r.cookie, corpo: { ativar: true, senha: SENHA } });
  assert.equal(ativarSemConfirmar.status, 400);
  const cookie = await contaConfirmada(loja, 'comconf@exemplo.com');
  const senhaErrada = await loja.chamar('POST', '/api/conta/dois-fatores', { cookie, corpo: { ativar: true, senha: 'errada-123' } });
  assert.equal(senhaErrada.status, 401);
});

async function contaCom2fa(endereco) {
  const cookie = await contaConfirmada(loja, endereco);
  const r = await loja.chamar('POST', '/api/conta/dois-fatores', { cookie, corpo: { ativar: true, senha: SENHA } });
  assert.equal(r.status, 200);
  return { antigo: cookie, atual: r.cookie };
}

test('com duas etapas, o login só termina com o código do e-mail', async () => {
  await contaCom2fa('mfa@exemplo.com');
  const etapa1 = await entrar('mfa@exemplo.com');
  assert.equal(etapa1.json.etapa, 'codigo');
  assert.equal(etapa1.setCookie, '', 'nenhuma sessão antes do código');
  const codigo = codigoDoEmail(ultimoEmail('mfa@exemplo.com'));
  const r = await loja.chamar('POST', '/api/conta/codigo', { corpo: { desafio: etapa1.json.desafio, codigo } });
  assert.equal(r.status, 200);
  assert.equal((await eu(r.cookie)).doisFatores, true);
  // código já usado não vale de novo
  assert.equal((await loja.chamar('POST', '/api/conta/codigo', { corpo: { desafio: etapa1.json.desafio, codigo } })).status, 400);
});

test('código errado: no máximo 5 tentativas (contadas no banco)', async () => {
  await contaCom2fa('forca@exemplo.com');
  const { json } = await entrar('forca@exemplo.com');
  const certo = codigoDoEmail(ultimoEmail('forca@exemplo.com'));
  const errado = certo === '000000' ? '111111' : '000000';
  for (let i = 0; i < 5; i++) {
    assert.equal((await loja.chamar('POST', '/api/conta/codigo', { corpo: { desafio: json.desafio, codigo: errado } })).status, 401);
  }
  assert.equal((await loja.chamar('POST', '/api/conta/codigo', { corpo: { desafio: json.desafio, codigo: certo } })).status, 400);
});

test('ativar duas etapas derruba os outros aparelhos', async () => {
  const { antigo, atual } = await contaCom2fa('aparelhos@exemplo.com');
  assert.equal(await eu(antigo), null);
  assert.ok(await eu(atual));
  assert.match(ultimoEmail('aparelhos@exemplo.com').texto, /ATIVADA/);
});

test('sair de todos os aparelhos invalida a sessão', async () => {
  const cookie = await contaConfirmada(loja, 'todos@exemplo.com');
  const r = await loja.chamar('POST', '/api/conta/sair-de-todos', { cookie });
  assert.equal(r.status, 200);
  assert.equal(await eu(cookie), null);
});
