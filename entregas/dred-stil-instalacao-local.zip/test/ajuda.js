// Sobe o servidor real da loja com um Supabase falso (PGlite em memória) para os testes.
// Nunca usa o .env.local: os testes não tocam no banco de verdade.
const http = require('http');
const path = require('path');
const { criarBancoTeste } = require('./banco-teste');
const { criarClienteFalso } = require('./supabase-falso');

Object.assign(process.env, {
  NODE_ENV: 'test',
  VERCEL: '1', // para os testes variarem o IP pelo x-forwarded-for
  SUPABASE_URL: 'https://teste.supabase.co',
  SUPABASE_SERVICE_ROLE_KEY: 'chave-de-teste',
  SESSION_SECRET: 'segredo-de-teste-com-tamanho-suficiente-123',
  PAGAMENTO_PROVEDOR: 'simulado',
  GETNET_WEBHOOK_TOKEN: 'token-webhook-teste-123',
  CRON_SECRET: 'cron-teste',
  NFE_PROVEDOR: 'simulado',
  APP_URL: 'http://loja.teste',
});
delete process.env.RESEND_API_KEY;
delete process.env.MELHOR_ENVIO_TOKEN;

let ip = 0;
const novoIp = () => `10.0.${Math.floor(++ip / 250)}.${ip % 250}`;

async function iniciarLoja() {
  const pg = await criarBancoTeste();
  const caminhoSupabase = require.resolve('@supabase/supabase-js', { paths: [path.join(__dirname, '..', 'server')] });
  require.cache[caminhoSupabase] = { id: caminhoSupabase, filename: caminhoSupabase, loaded: true, exports: { createClient: () => criarClienteFalso(pg) } };
  const { tratarRequisicao } = require('../server');
  const servidor = http.createServer(tratarRequisicao);
  await new Promise((ok) => servidor.listen(0, '127.0.0.1', ok));
  const base = `http://127.0.0.1:${servidor.address().port}`;

  await pg.exec(`
    insert into categorias (slug, nome) values ('camisetas', 'Camisetas');
    insert into produtos (handle, nome, categoria, preco, tamanhos, cores) values
      ('camiseta-teste', 'Camiseta Teste', 'camisetas', 150, '["M","G"]',
       '[{"nome":"Preto","hex":"#000000","imagens":["/img/produtos/preto.webp"]}]'),
      ('sob-consulta', 'Peça Sob Consulta', 'camisetas', 0, '["M"]',
       '[{"nome":"Preto","hex":"#000000","imagens":["/img/produtos/preto.webp"]}]');
    insert into conteudo (chave, valor) values ('config', '{"whatsapp":"5541999999999","parcelas":3,"banners":[]}');
  `);

  // Requisição como o navegador faz: JSON, cookie e Origin do próprio site.
  async function chamar(metodo, caminho, { corpo, cookie, origem = base, ipCliente = novoIp(), headers = {} } = {}) {
    const h = { 'x-forwarded-for': ipCliente, ...headers };
    if (origem) h.origin = origem;
    if (cookie) h.cookie = cookie;
    if (corpo !== undefined) h['content-type'] = 'application/json';
    const r = await fetch(base + caminho, { method: metodo, headers: h, body: corpo === undefined ? undefined : JSON.stringify(corpo), redirect: 'manual' });
    const setCookie = r.headers.get('set-cookie') || '';
    const json = await r.json().catch(() => null);
    return { status: r.status, json, setCookie, cookie: setCookie.split(';')[0], headers: r.headers };
  }

  return { pg, base, chamar, fechar: () => new Promise((ok) => servidor.close(ok)) };
}

const emails = () => globalThis.__emailsTeste || [];
const ultimoEmail = (para) => [...emails()].reverse().find((e) => e.para === para);
const tokenDoEmail = (e, ancora) => e?.texto.match(new RegExp(`#${ancora}=([\\w-]+)`))?.[1] || '';
const codigoDoEmail = (e) => e?.texto.match(/(\d{6})/)?.[1] || '';

// Dados de cadastro válidos (apelido derivado do e-mail).
const dadosConta = (endereco, senha = 'Senha-Forte-123', extra = {}) => ({
  nome: 'Cliente Teste da Silva',
  apelido: endereco.split('@')[0].replace(/[^a-z0-9_.]/gi, '').toLowerCase().padEnd(3, '0').slice(0, 30),
  email: endereco,
  telefone: '(41) 98888-7777',
  senha,
  ...extra,
});

// Cria a conta, confirma o e-mail e devolve o cookie da sessão.
async function contaConfirmada(loja, endereco, senha = 'Senha-Forte-123', extra = {}) {
  const r = await loja.chamar('POST', '/api/conta/cadastro', { corpo: dadosConta(endereco, senha, extra) });
  if (r.status !== 200) throw new Error(`cadastro falhou: ${r.status} ${JSON.stringify(r.json)}`);
  const token = tokenDoEmail(ultimoEmail(endereco), 'verificar');
  await loja.chamar('POST', '/api/conta/verificar-email', { corpo: { token } });
  return r.cookie;
}

module.exports = { dadosConta, iniciarLoja, emails, ultimoEmail, tokenDoEmail, codigoDoEmail, contaConfirmada, novoIp };
