// Postgres em memória (PGlite) com a mesma estrutura do Supabase, para testes.
// Simula os papéis e o schema storage que existem no Supabase.
const fs = require('fs');
const path = require('path');

async function criarBancoTeste() {
  const { PGlite } = await import('@electric-sql/pglite');
  const pg = new PGlite();
  await pg.exec(`
    create role anon; create role authenticated; create role service_role;
    create schema storage;
    create table storage.buckets (id text primary key, name text, public boolean, file_size_limit int, allowed_mime_types text[]);
  `);
  const sql = (arq) => fs.readFileSync(path.join(__dirname, '..', 'supabase', arq), 'utf8');
  await pg.exec(sql('estrutura.sql'));
  for (const m of ['002-contas-pagamentos-seguranca.sql', '003-cadastro-estoque-notas.sql', '004-getnet-global.sql', '005-estoque-por-cor.sql', '006-categorias-mover.sql']) await pg.exec(sql('migracoes/' + m));
  return pg;
}

module.exports = { criarBancoTeste };
