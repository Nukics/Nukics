// Atualização de um banco existente: exercita a estrutura antiga antes da 005.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const sql = (nome) => fs.readFileSync(path.join(__dirname, '..', 'supabase', nome), 'utf8');

test('005 preserva nomes, saldos e pedidos legados, inclusive nomes que só diferem por maiúsculas', async () => {
  const { PGlite } = await import('@electric-sql/pglite');
  const pg = new PGlite();
  try {
    await pg.exec(`create role anon; create role authenticated; create role service_role;
      create schema storage;
      create table storage.buckets (id text primary key, name text, public boolean, file_size_limit int, allowed_mime_types text[]);`);
    await pg.exec(sql('estrutura.sql'));
    await pg.exec(sql('migracoes/002-contas-pagamentos-seguranca.sql'));
    await pg.exec(sql('migracoes/003-cadastro-estoque-notas.sql'));
    await pg.exec(`insert into categorias(slug,nome) values ('camisas','Camisas');
      insert into estoques(nome,quantidade) values ('Camisas',10),('camisas',8);
      insert into produtos(handle,nome,categoria,preco,tamanhos,cores,estoque_id)
        select 'legacy','Camisa antiga','camisas',100,'["M"]',
          '[{"nome":"Preto","hex":"#000000","imagens":["/img/preto.webp"]}]',id
          from estoques where nome='Camisas';
      insert into pedidos(itens,total) values ('[{"handle":"legacy","cor":"Preto","tamanho":"M","qtd":3,"preco":100,"nome":"Camisa antiga"}]',300);
      update pedidos set status='pago';`);
    const antes = (await pg.query('select id,nome,quantidade from estoques order by nome')).rows;
    const movimentos = (await pg.query('select * from estoque_movimentos order by id')).rows;
    await pg.exec(sql('migracoes/004-getnet-global.sql'));
    await pg.exec(sql('migracoes/005-estoque-por-cor.sql'));
    assert.deepEqual((await pg.query('select id,nome,quantidade from estoques order by nome')).rows, antes);
    assert.deepEqual((await pg.query('select * from estoque_movimentos order by id')).rows, movimentos);
    assert.deepEqual((await pg.query('select cor,arquivado from estoques')).rows,
      [{ cor: null, arquivado: false }, { cor: null, arquivado: false }]);
    // Depois da atualização, mudar o vínculo não muda o destino da devolução histórica.
    await pg.exec(`update produtos set estoque_id=(select id from estoques where nome='camisas');
      update pedidos set status='cancelado';`);
    assert.deepEqual((await pg.query('select nome,quantidade from estoques order by nome')).rows,
      [{ nome: 'Camisas', quantidade: 10 }, { nome: 'camisas', quantidade: 8 }]);
    await pg.exec(sql('migracoes/005-estoque-por-cor.sql'));
    assert.equal((await pg.query('select count(*)::int as total from estoques')).rows[0].total, 2);
  } finally { await pg.close(); }
});
