const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { iniciarLoja, contaConfirmada } = require('./ajuda');

let loja;
let navegador;
before(async () => {
  loja = await iniciarLoja();
  await loja.pg.exec(`
    insert into categorias (slug, nome) values ('atacado', 'Atacado');
    insert into categorias (slug, nome, pai) values ('atacado-camisetas', 'Camisetas no atacado', 'atacado');
    insert into produtos (handle, nome, categoria, preco, tamanhos, cores) values
      ('atacado-a', 'Peça Atacado A', 'atacado', 100, '["M"]', '[{"nome":"Preto","hex":"#000000","imagens":["/img/produtos/preto-frente.webp"]}]'),
      ('atacado-b', 'Peça Atacado B', 'atacado-camisetas', 100, '["M"]', '[{"nome":"Preto","hex":"#000000","imagens":["/img/produtos/preto-frente.webp"]}]'),
      ('atacado-centavos', 'Peça Atacado Centavos', 'atacado', 19.99, '["M"]', '[{"nome":"Preto","hex":"#000000","imagens":["/img/produtos/preto-frente.webp"]}]');
  `);
  require('../server/publico').limpar();
  const codigo = fs.readFileSync(path.join(__dirname, '../public/js/atacado.js'), 'utf8');
  navegador = await import(`data:text/javascript;base64,${Buffer.from(codigo).toString('base64')}`);
});
after(() => loja.fechar());

const item = (handle, qtd) => ({ handle, cor: 'Preto', tamanho: 'M', qtd });

test('faixas solicitadas são cobradas no WhatsApp e coincidem com a prévia do navegador', async () => {
  const faixas = [[1, 0], [2, 6], [3, 7], [4, 8], [5, 9], [6, 10], [7, 11], [8, 12], [9, 11], [10, 12], [11, 12], [12, 12], [13, 30], [20, 30]];
  for (const [qtd, percentual] of faixas) {
    const r = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: [{ ...item('atacado-a', qtd), preco: 0.01 }], total: 1 } });
    assert.equal(r.status, 200, JSON.stringify(r.json));
    assert.equal(r.json.pedido.total, qtd * (100 - percentual), `Quantidade ${qtd}`);
    assert.equal(navegador.percentualAtacado(qtd), percentual);
  }
});

test('modelos e subcategorias de Atacado somam juntos sem descontar produtos de varejo', async () => {
  const r = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: [item('atacado-a', 1), item('atacado-b', 1), item('camiseta-teste', 11)] } });
  assert.equal(r.status, 200);
  assert.deepEqual(r.json.pedido.itens.map((i) => i.preco), [94, 94, 150]);
  assert.equal(r.json.pedido.total, 1838);
  const lojaPublica = (await loja.chamar('GET', '/api/loja')).json;
  assert.equal(lojaPublica.produtos.find((p) => p.handle === 'atacado-b').atacado, true);
});

test('checkout Pix aplica a mesma regra para 13 peças e preços não vêm do navegador', async () => {
  const cookie = await contaConfirmada(loja, 'atacado-checkout@exemplo.com');
  const r = await loja.chamar('POST', '/api/checkout', { cookie, corpo: {
    itens: [item('atacado-a', 6), item('atacado-b', 7)], total: 0.01,
    tipoEntrega: 'retirada-loja', freteServico: 'retirada-loja', pagamento: 'pix', chaveIdempotencia: crypto.randomUUID(),
    cliente: { nome: 'Cliente Atacado', cpf: '52998224725', telefone: '41988887777' },
  } });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.pedido.subtotal, 910);
  assert.equal(r.json.pedido.total, 910);
});

test('economia exibida respeita o arredondamento por unidade realmente cobrado', async () => {
  const itens = [{ qtd: 13, produto: { categoria: 'atacado', preco: 19.99 } }];
  const resumo = navegador.resumoAtacado(itens);
  const r = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: [item('atacado-centavos', 13)] } });
  assert.equal(r.json.pedido.total, 181.87);
  assert.equal(navegador.precoAtacado(itens[0], resumo), 13.99);
  assert.equal(resumo.desconto, 78);
});

test('página Atacado tem tabela e somente peças elegíveis já no HTML, além de sitemap', async () => {
  const r = await fetch(loja.base + '/atacado');
  const html = await r.text();
  assert.equal(r.status, 200);
  assert.match(r.headers.get('cache-control'), /s-maxage=60/);
  assert.match(html, /Preço de atacado/);
  assert.match(html, /Acima de 12 peças<\/th><td>30%/);
  assert.match(html, /11 ou 12 peças<\/th><td>12%/);
  assert.match(html, /data-handle="atacado-b"/);
  assert.doesNotMatch(html, /<article class="cartao" data-handle="camiseta-teste"/);
  assert.match(await (await fetch(loja.base + '/sitemap.xml')).text(), /\/atacado<\/loc>/);
});

test('banner antigo herda os ajustes no celular e limites inválidos são recusados', () => {
  const validar = require('../server/validar');
  const base = { whatsapp: '', telefone: '', parcelas: 3, banners: [{ imagem: '/img/banners/linha-de-frente.webp', focoX: 25, focoY: 70 }] };
  const b = validar.configuracoes(base).banners[0];
  assert.equal(b.zoom, 100);
  assert.equal(b.focoMobileX, 25);
  assert.equal(b.focoMobileY, 70);
  for (const extra of [{ zoom: 99 }, { zoomMobile: 181 }, { focoX: 101 }, { focoMobileY: -1 }]) {
    assert.throws(() => validar.configuracoes({ ...base, banners: [{ ...base.banners[0], ...extra }] }));
  }
});

test('HTML do banner remoto não aguarda consulta ao Storage e preserva ajustes por dispositivo', async () => {
  const original = global.fetch;
  let chamadas = 0;
  global.fetch = async () => { chamadas++; throw new Error('Não deveria buscar o arquivo antes de renderizar'); };
  try {
    const html = await require('../server/render').htmlBanners([
      { imagem: 'https://loja.supabase.co/storage/v1/object/public/produtos/banner.webp', focoX: 25, focoY: 70, zoom: 120, focoMobileX: 80, focoMobileY: 30, zoomMobile: 140 },
    ]);
    assert.equal(chamadas, 0);
    assert.match(html, /--banner-x:25%;--banner-y:70%;--banner-zoom:1.2/);
    assert.match(html, /--banner-mx:80%;--banner-my:30%;--banner-mzoom:1.4/);
    assert.match(html, /fetchpriority="high"/);
  } finally { global.fetch = original; }
});
