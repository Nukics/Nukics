// Estoque real por tipo de peça + cor, exercitado pela API e pelo PostgreSQL local.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { iniciarLoja, contaConfirmada, codigoDoEmail, ultimoEmail } = require('./ajuda');

let loja;
let admin;
let cliente;
let sequencia = 0;

before(async () => {
  loja = await iniciarLoja();
  const email = 'dono.cores@exemplo.com';
  const cookie = await contaConfirmada(loja, email, 'Senha-Forte-123', { apelido: 'donocores' });
  await loja.pg.query('update usuarios set papel = $1 where email = $2', ['admin', email]);
  assert.equal((await loja.chamar('POST', '/api/conta/dois-fatores', {
    cookie, corpo: { ativar: true, senha: 'Senha-Forte-123' },
  })).status, 200);
  const etapa = await loja.chamar('POST', '/api/conta/entrar', {
    corpo: { identificador: 'donocores', senha: 'Senha-Forte-123' },
  });
  const entrada = await loja.chamar('POST', '/api/conta/codigo', {
    corpo: { desafio: etapa.json.desafio, codigo: codigoDoEmail(ultimoEmail(email)) },
  });
  assert.equal(entrada.status, 200);
  admin = entrada.cookie;
  cliente = await contaConfirmada(loja, 'cliente.cores@exemplo.com');
});
after(() => loja.fechar());

const item = (handle, cor = 'Preto', qtd = 1, tamanho = 'M') => ({ handle, cor, qtd, tamanho });
const saldo = async (id) => (await loja.pg.query('select quantidade from estoques where id = $1', [id])).rows[0].quantidade;
const listar = () => loja.chamar('GET', '/api/admin/estoques', { cookie: admin });

async function produto(handle, cores = ['Preto', 'Branco']) {
  await loja.pg.query(`insert into produtos (handle, nome, categoria, preco, tamanhos, cores)
    values ($1, $2, 'camisetas', 100, '["M","G"]', $3)`, [
    handle, `Camisa ${handle}`,
    JSON.stringify(cores.map((nome) => ({ nome, hex: nome === 'Branco' ? '#FFFFFF' : '#000000', imagens: ['/img/produtos/preto.webp'] }))),
  ]);
  return handle;
}

async function produtosNovos(quantidade = 3) {
  const prefixo = `cores-${++sequencia}`;
  const handles = [];
  for (let i = 0; i < quantidade; i++) handles.push(await produto(`${prefixo}-${i + 1}`));
  return { nome: `Camisa Oversized ${sequencia}`, handles };
}

async function criar(nome, cor, quantidade, produtos) {
  const r = await loja.chamar('POST', '/api/admin/estoques', {
    cookie: admin, corpo: { nome, cor, quantidade, produtos },
  });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r.json.estoque;
}

async function whatsapp(itens) {
  const r = await loja.chamar('POST', '/api/pedidos', { corpo: { itens } });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return (await loja.pg.query('select * from pedidos where numero = $1', [r.json.pedido.numero])).rows[0];
}

async function status(id, valor) {
  const r = await loja.chamar('PATCH', `/api/admin/pedidos/${id}`, { cookie: admin, corpo: { status: valor } });
  assert.equal(r.status, 200, JSON.stringify(r.json));
}

function checkout(itens, cookie = cliente) {
  return loja.chamar('POST', '/api/checkout', {
    cookie, corpo: {
      itens, freteServico: '1', pagamento: 'pix', chaveIdempotencia: crypto.randomUUID(),
      cliente: { nome: 'Cliente Teste', cpf: '529.982.247-25', telefone: '41988887777' },
      endereco: { cep: '83320000', rua: 'Rua A', numero: '1', complemento: '', bairro: 'Centro', cidade: 'Pinhais', uf: 'PR' },
    },
  });
}

test('saldo da mesma categoria pode ter Preto e Branco; duplicidade considera espaços e maiúsculas', async () => {
  const { nome, handles } = await produtosNovos();
  const corpo = { nome, cor: 'Preto', quantidade: 30, produtos: handles };
  assert.equal((await loja.chamar('POST', '/api/admin/estoques', { cookie: cliente, corpo })).status, 403);
  assert.equal((await loja.chamar('POST', '/api/admin/estoques', { corpo })).status, 401);
  const preto = await criar(nome, 'Preto', 30, handles);
  const branco = await criar(nome, 'Branco', 7, handles);
  assert.notEqual(preto.id, branco.id);
  assert.equal((await loja.chamar('POST', '/api/admin/estoques', {
    cookie: admin, corpo: { ...corpo, nome: `  ${nome.toUpperCase()}  `, cor: ' preto ' },
  })).status, 409);
  const lista = (await listar()).json.estoques.filter((e) => e.nome === nome);
  assert.equal(lista.length, 2);
  for (const estoque of lista) assert.deepEqual(estoque.produtos.map((p) => p.handle).sort(), handles.slice().sort());
  assert.equal(await saldo(preto.id), 30);
  assert.equal(await saldo(branco.id), 7);
});

test('não vincula produto sem a cor cadastrada nem muda a cor de saldo existente', async () => {
  const { nome, handles } = await produtosNovos(1);
  const antes = (await listar()).json.estoques.length;
  const invalido = await loja.chamar('POST', '/api/admin/estoques', {
    cookie: admin, corpo: { nome, cor: 'Azul', quantidade: 4, produtos: handles },
  });
  assert.equal(invalido.status, 400);
  assert.equal((await listar()).json.estoques.length, antes, 'falha não deixa saldo parcial');
  const preto = await criar(nome, 'Preto', 4, handles);
  const alteracao = await loja.chamar('PUT', `/api/admin/estoques/${preto.id}`, {
    cookie: admin, corpo: { nome, cor: 'Branco', quantidade: 4, produtos: handles },
  });
  assert.equal(alteracao.status, 409);
  assert.equal((await listar()).json.estoques.find((e) => e.id === preto.id).cor, 'Preto');
});

test('limite soma modelos e tamanhos da mesma cor sem consumir a outra cor', async () => {
  const { nome, handles } = await produtosNovos();
  const preto = await criar(nome, 'Preto', 3, handles);
  const branco = await criar(nome, 'Branco', 10, handles);
  const excesso = [item(handles[0], 'Preto', 2), item(handles[1], 'Preto', 1), item(handles[0], 'Preto', 1, 'G')];
  const whats = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: excesso } });
  assert.equal(whats.status, 409);
  assert.match(whats.json.erro, /restam 3/);
  assert.equal((await checkout(excesso)).status, 409, 'checkout Pix tem a mesma conferência');
  await whatsapp([item(handles[0], 'Preto', 2), item(handles[1], 'Preto', 1), item(handles[2], 'Branco', 10)]);
  assert.equal(await saldo(preto.id), 3, 'aguardando confirmação não baixa');
  assert.equal(await saldo(branco.id), 10);
});

test('Pix confirmado baixa só a cor comprada uma vez e cancelamento devolve a baixa', async () => {
  const { nome, handles } = await produtosNovos(2);
  const preto = await criar(nome, 'Preto', 5, handles);
  const branco = await criar(nome, 'Branco', 9, handles);
  const r = await checkout([item(handles[0], 'Preto', 2), item(handles[1], 'Preto', 1, 'G')]);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const pedido = r.json.pedido;
  assert.equal(await saldo(preto.id), 5);
  require('../server/pagamento/simulado').definirStatus(pedido.pagamentoId, 'aprovado');
  const notificar = () => loja.chamar('POST', '/api/webhooks/getnet?token=token-webhook-teste-123', {
    origem: null, corpo: { payment_id: pedido.pagamentoId },
  });
  assert.equal((await notificar()).status, 200);
  assert.equal((await notificar()).status, 200, 'webhook repetido é idempotente');
  assert.equal(await saldo(preto.id), 2);
  assert.equal(await saldo(branco.id), 9);
  await status(pedido.id, 'enviado');
  await status(pedido.id, 'entregue');
  assert.equal(await saldo(preto.id), 2);
  await status(pedido.id, 'cancelado');
  await status(pedido.id, 'cancelado');
  assert.equal(await saldo(preto.id), 5);
  assert.equal(await saldo(branco.id), 9);
  const movimentos = (await loja.chamar('GET', `/api/admin/estoques/${preto.id}/movimentos`, { cookie: admin })).json.movimentos;
  assert.deepEqual(movimentos.map((m) => m.delta), [3, -3, 5]);
});

test('dois pagamentos disputando últimas peças registram falta sem criar saldo na devolução', async () => {
  const { nome, handles } = await produtosNovos(1);
  const preto = await criar(nome, 'Preto', 3, handles);
  const branco = await criar(nome, 'Branco', 11, handles);
  const primeiro = await checkout([item(handles[0], 'Preto', 3)]);
  const segundo = await checkout([item(handles[0], 'Preto', 3)]);
  assert.equal(primeiro.status, 200, JSON.stringify(primeiro.json));
  assert.equal(segundo.status, 200, JSON.stringify(segundo.json));
  assert.notEqual(primeiro.json.pedido.id, segundo.json.pedido.id);
  assert.equal(await saldo(preto.id), 3, 'os dois pedidos aguardando ainda não reservam peças');

  for (const { pedido } of [primeiro.json, segundo.json]) {
    require('../server/pagamento/simulado').definirStatus(pedido.pagamentoId, 'aprovado');
    const r = await loja.chamar('POST', '/api/webhooks/getnet?token=token-webhook-teste-123', {
      origem: null, corpo: { payment_id: pedido.pagamentoId },
    });
    assert.equal(r.status, 200, JSON.stringify(r.json));
    assert.equal(await saldo(preto.id), 0, 'saldo nunca fica negativo');
    assert.equal(await saldo(branco.id), 11, 'a falta não consome outra cor');
  }
  const baixa = (await loja.pg.query(`select delta, motivo from estoque_movimentos
    where estoque_id = $1 and pedido_id = $2 order by id`, [preto.id, segundo.json.pedido.id])).rows;
  assert.equal(baixa.length, 1);
  assert.equal(baixa[0].delta, 0, 'segundo pagamento não baixou peças inexistentes');
  assert.match(baixa[0].motivo, /faltam 3 peças/);
  await status(primeiro.json.pedido.id, 'cancelado');
  assert.equal(await saldo(preto.id), 3, 'primeiro cancelamento devolve as três peças baixadas');
  await status(segundo.json.pedido.id, 'cancelado');
  assert.equal(await saldo(preto.id), 3, 'segundo cancelamento não cria peças que não foram baixadas');
  assert.equal(await saldo(branco.id), 11);
});

test('webhook limpa cache da vitrine e atualiza esgotado da cor comprada', async () => {
  const { nome, handles } = await produtosNovos(1);
  const preto = await criar(nome, 'Preto', 2, handles);
  const branco = await criar(nome, 'Branco', 5, handles);
  const compra = await checkout([item(handles[0], 'Preto', 2)]);
  assert.equal(compra.status, 200, JSON.stringify(compra.json));
  const lerProduto = async () => (await loja.chamar('GET', '/api/loja')).json.produtos.find((p) => p.handle === handles[0]);
  const antes = await lerProduto();
  assert.equal(antes.cores.find((c) => c.nome === 'Preto').esgotado, false);
  assert.equal(antes.cores.find((c) => c.nome === 'Branco').esgotado, false);
  require('../server/pagamento/simulado').definirStatus(compra.json.pedido.pagamentoId, 'aprovado');
  const resposta = await loja.chamar('POST', '/api/webhooks/getnet?token=token-webhook-teste-123', {
    origem: null, corpo: { payment_id: compra.json.pedido.pagamentoId },
  });
  assert.equal(resposta.status, 200, JSON.stringify(resposta.json));
  const depois = await lerProduto();
  assert.equal(await saldo(preto.id), 0);
  assert.equal(await saldo(branco.id), 5);
  assert.equal(depois.cores.find((c) => c.nome === 'Preto').esgotado, true, 'sem aguardar expiração do cache');
  assert.equal(depois.cores.find((c) => c.nome === 'Branco').esgotado, false);
  assert.equal(depois.esgotado, false, 'outra cor continua disponível');
});

test('snapshot da compra ignora estoqueId do cliente e sobrevive à troca de grupo antes de pagar', async () => {
  const { nome, handles } = await produtosNovos(1);
  const original = await criar(nome, 'Preto', 6, handles);
  const outro = await criar(`${nome} novo`, 'Preto', 12, []);
  const pedido = await whatsapp([{ ...item(handles[0], 'Preto', 2), estoqueId: outro.id, preco: 0.01 }]);
  assert.equal(pedido.itens[0].estoqueId, original.id, 'servidor resolve e grava o saldo correto');
  assert.equal(pedido.itens[0].preco, 100);
  assert.equal((await loja.chamar('PUT', `/api/admin/estoques/${outro.id}`, {
    cookie: admin, corpo: { nome: `${nome} novo`, cor: 'Preto', quantidade: 12, produtos: handles },
  })).status, 200);
  await status(pedido.id, 'pago');
  assert.equal(await saldo(original.id), 4);
  assert.equal(await saldo(outro.id), 12);
  await status(pedido.id, 'cancelado');
  assert.equal(await saldo(original.id), 6);
  assert.equal(await saldo(outro.id), 12);
});

test('trocar vínculo depois do pagamento mantém devolução no saldo original', async () => {
  const { nome, handles } = await produtosNovos(1);
  const original = await criar(nome, 'Branco', 7, handles);
  const pedido = await whatsapp([item(handles[0], 'Branco', 3)]);
  await status(pedido.id, 'pago');
  const outro = await criar(`${nome} reposição`, 'Branco', 20, handles);
  await status(pedido.id, 'cancelado');
  assert.equal(await saldo(original.id), 7);
  assert.equal(await saldo(outro.id), 20);
});

test('arquivar saldo preserva pedidos já criados e histórico de devolução', async () => {
  const { nome, handles } = await produtosNovos(1);
  const original = await criar(nome, 'Preto', 8, handles);
  const pedido = await whatsapp([item(handles[0], 'Preto', 3)]);
  assert.equal((await loja.chamar('DELETE', `/api/admin/estoques/${original.id}`, { cookie: admin })).status, 200);
  assert.ok(!(await listar()).json.estoques.some((e) => e.id === original.id));
  assert.equal((await loja.pg.query('select arquivado from estoques where id = $1', [original.id])).rows[0].arquivado, true);
  const novo = await criar(nome, 'Preto', 15, handles);
  await status(pedido.id, 'pago');
  assert.equal(await saldo(original.id), 5, 'snapshot ainda baixa o saldo arquivado');
  assert.equal(await saldo(novo.id), 15);
  await status(pedido.id, 'cancelado');
  assert.equal(await saldo(original.id), 8);
  const movimentos = await loja.chamar('GET', `/api/admin/estoques/${original.id}/movimentos`, { cookie: admin });
  assert.equal(movimentos.status, 200);
  assert.deepEqual(movimentos.json.movimentos.map((m) => m.delta), [3, -3, 8]);
});

test('vitrine informa disponibilidade de cada cor sem expor saldos ou identificadores', async () => {
  const { nome, handles } = await produtosNovos(1);
  const preto = await criar(nome, 'Preto', 0, handles);
  const branco = await criar(nome, 'Branco', 2, handles);
  let p = (await loja.chamar('GET', '/api/loja')).json.produtos.find((v) => v.handle === handles[0]);
  assert.equal(p.esgotado, false, 'Branco ainda está disponível');
  assert.equal(p.cores.find((c) => c.nome === 'Preto').esgotado, true);
  assert.equal(p.cores.find((c) => c.nome === 'Branco').esgotado, false);
  assert.equal(p.estoqueId, undefined);
  assert.doesNotMatch(JSON.stringify(p), new RegExp(`${preto.id}|${branco.id}|quantidade|estoque_id`));
  assert.equal((await loja.chamar('PUT', `/api/admin/estoques/${branco.id}`, {
    cookie: admin, corpo: { nome, cor: 'Branco', quantidade: 0, produtos: handles },
  })).status, 200);
  p = (await loja.chamar('GET', '/api/loja')).json.produtos.find((v) => v.handle === handles[0]);
  assert.equal(p.esgotado, true, 'só fica totalmente esgotado quando todas as cores acabam');
});

test('grupo antigo controla somente cores sem vínculo específico, sem duplicar seu saldo', async () => {
  const { nome, handles } = await produtosNovos(1);
  const antigo = await criar(`${nome} antigo`, null, 4, handles);
  const preto = await criar(nome, 'Preto', 2, handles);
  const pedido = await whatsapp([item(handles[0], 'Preto', 2), item(handles[0], 'Branco', 3)]);
  assert.deepEqual(pedido.itens.map((i) => i.estoqueId), [preto.id, antigo.id]);
  await status(pedido.id, 'pago');
  assert.equal(await saldo(preto.id), 0);
  assert.equal(await saldo(antigo.id), 1);
  const p = (await loja.chamar('GET', '/api/loja')).json.produtos.find((v) => v.handle === handles[0]);
  assert.equal(p.cores.find((c) => c.nome === 'Preto').esgotado, true);
  assert.equal(p.cores.find((c) => c.nome === 'Branco').esgotado, false);
  await status(pedido.id, 'cancelado');
  assert.equal(await saldo(preto.id), 2);
  assert.equal(await saldo(antigo.id), 4);
});

test('migração 005 pode ser reaplicada sem perder vínculos, saldos ou histórico; funções ficam no servidor', async () => {
  const { nome, handles } = await produtosNovos(1);
  const estoque = await criar(nome, 'Preto', 9, handles);
  const pedido = await whatsapp([item(handles[0], 'Preto', 2)]);
  await status(pedido.id, 'pago');
  const antes = (await loja.pg.query('select * from estoque_movimentos where estoque_id = $1 order by id', [estoque.id])).rows;
  await loja.pg.exec(fs.readFileSync(path.join(__dirname, '..', 'supabase/migracoes/005-estoque-por-cor.sql'), 'utf8'));
  assert.equal(await saldo(estoque.id), 7);
  assert.equal((await loja.pg.query('select estoque_id from estoque_produtos_cores where handle = $1', [handles[0]])).rows[0].estoque_id, estoque.id);
  assert.deepEqual((await loja.pg.query('select * from estoque_movimentos where estoque_id = $1 order by id', [estoque.id])).rows, antes);
  const permissao = (await loja.pg.query(`select
    has_table_privilege('anon', 'estoque_produtos_cores', 'select') as anon_ler,
    has_table_privilege('authenticated', 'estoque_produtos_cores', 'insert') as cliente_alterar,
    has_function_privilege('anon', 'salvar_estoque_cor(uuid,text,text,integer,jsonb,uuid)', 'execute') as anon_salvar,
    has_function_privilege('authenticated', 'arquivar_estoque(uuid)', 'execute') as cliente_arquivar,
    has_function_privilege('service_role', 'salvar_estoque_cor(uuid,text,text,integer,jsonb,uuid)', 'execute') as servidor_salvar`)).rows[0];
  assert.deepEqual(permissao, { anon_ler: false, cliente_alterar: false, anon_salvar: false, cliente_arquivar: false, servidor_salvar: true });
  await status(pedido.id, 'cancelado');
  assert.equal(await saldo(estoque.id), 9, 'trigger continua funcionando após reaplicar');
});
