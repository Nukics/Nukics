// Cadastro completo, recuperação por nome/apelido, estoque por grupo e notas fiscais.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, emails, ultimoEmail, codigoDoEmail, contaConfirmada, dadosConta } = require('./ajuda');

let loja;
let admin; // cookie do admin (com duas etapas)
before(async () => {
  loja = await iniciarLoja();
  const cookie = await contaConfirmada(loja, 'dono@exemplo.com', 'Senha-Forte-123', { nome: 'Sergio Dono Loja', apelido: 'dono' });
  await loja.pg.query(`update usuarios set papel = 'admin' where email = 'dono@exemplo.com'`);
  await loja.chamar('POST', '/api/conta/dois-fatores', { cookie, corpo: { ativar: true, senha: 'Senha-Forte-123' } });
  const etapa = await loja.chamar('POST', '/api/conta/entrar', { corpo: { identificador: 'dono', senha: 'Senha-Forte-123' } });
  admin = (await loja.chamar('POST', '/api/conta/codigo', {
    corpo: { desafio: etapa.json.desafio, codigo: codigoDoEmail(ultimoEmail('dono@exemplo.com')) },
  })).cookie;
});
after(() => loja.fechar());

const cadastrar = (dados) => loja.chamar('POST', '/api/conta/cadastro', { corpo: dados });

/* ---------------- cadastro ---------------- */
test('cadastro exige nome completo, apelido e telefone', async () => {
  assert.equal((await cadastrar(dadosConta('a1@exemplo.com', undefined, { nome: 'Ana' }))).status, 400, 'só o primeiro nome');
  assert.equal((await cadastrar(dadosConta('a2@exemplo.com', undefined, { telefone: '' }))).status, 400, 'sem telefone');
  assert.equal((await cadastrar(dadosConta('a3@exemplo.com', undefined, { apelido: 'x' }))).status, 400, 'apelido curto');
  assert.equal((await cadastrar(dadosConta('a4@exemplo.com', undefined, { apelido: 'com espaço' }))).status, 400);
  const ok = await cadastrar(dadosConta('a5@exemplo.com', undefined, { apelido: 'Ana.Costa_5' }));
  assert.equal(ok.status, 200);
  assert.equal(ok.json.usuario.apelido, 'ana.costa_5', 'apelido em minúsculas');
  assert.equal(ok.json.usuario.telefone, '41988887777');
});

test('CPF é opcional, validado e não se repete entre contas', async () => {
  assert.equal((await cadastrar(dadosConta('semcpf@exemplo.com'))).status, 200);
  assert.equal((await cadastrar(dadosConta('cpfinv@exemplo.com', undefined, { cpf: '111.111.111-11' }))).status, 400);
  assert.equal((await cadastrar(dadosConta('cpf1@exemplo.com', undefined, { cpf: '529.982.247-25' }))).status, 200);
  const repetido = await cadastrar(dadosConta('cpf2@exemplo.com', undefined, { cpf: '52998224725' }));
  assert.equal(repetido.status, 409);
  assert.match(repetido.json.erro, /CPF já está cadastrado/);
});

test('apelido não se repete (sem diferenciar maiúsculas) e o e-mail também não', async () => {
  assert.equal((await cadastrar(dadosConta('ap1@exemplo.com', undefined, { apelido: 'repetido' }))).status, 200);
  const r = await cadastrar(dadosConta('ap2@exemplo.com', undefined, { apelido: 'REPETIDO' }));
  assert.equal(r.status, 409);
  assert.match(r.json.erro, /apelido/i);
});

test('perfil: CPF de outra conta é recusado; dados obrigatórios continuam obrigatórios', async () => {
  const cookie = await contaConfirmada(loja, 'perfil@exemplo.com');
  const base = { nome: 'Perfil Teste Silva', apelido: 'perfil', telefone: '41977776666' };
  assert.equal((await loja.chamar('PATCH', '/api/conta', { cookie, corpo: { ...base, cpf: '529.982.247-25' } })).status, 409);
  assert.equal((await loja.chamar('PATCH', '/api/conta', { cookie, corpo: { ...base, telefone: '' } })).status, 400);
  const ok = await loja.chamar('PATCH', '/api/conta', { cookie, corpo: { ...base, cpf: '' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.usuario.cpf, null);
});

test('entrar com o apelido funciona', async () => {
  await contaConfirmada(loja, 'nick@exemplo.com', 'Senha-Forte-123', { apelido: 'meunick' });
  assert.equal((await loja.chamar('POST', '/api/conta/entrar', { corpo: { identificador: 'MeuNick', senha: 'Senha-Forte-123' } })).status, 200);
});

test('troca de senha em rota própria exige a senha atual', async () => {
  const cookie = await contaConfirmada(loja, 'troca@exemplo.com');
  assert.equal((await loja.chamar('POST', '/api/conta/senha', { cookie, corpo: { senhaAtual: 'errada-1', senhaNova: 'Nova-Senha-456' } })).status, 400);
  assert.equal((await loja.chamar('POST', '/api/conta/senha', { cookie, corpo: { senhaAtual: 'Senha-Forte-123', senhaNova: 'Nova-Senha-456' } })).status, 200);
});

/* ---------------- recuperação de senha ---------------- */
const esqueci = (identificador) => loja.chamar('POST', '/api/conta/esqueci-senha', { corpo: { identificador } });
const linksPara = (email) => emails().filter((e) => e.para === email && /Redefinição/.test(e.assunto)).length;

test('recuperação pelo apelido manda o link para o e-mail da conta', async () => {
  await contaConfirmada(loja, 'rec1@exemplo.com', 'Senha-Forte-123', { apelido: 'recapelido' });
  const antes = linksPara('rec1@exemplo.com');
  assert.equal((await esqueci('RecApelido')).status, 200);
  assert.equal(linksPara('rec1@exemplo.com'), antes + 1);
});

test('recuperação pelo nome completo (sem diferenciar maiúsculas) manda para a conta com esse nome', async () => {
  await contaConfirmada(loja, 'rec2@exemplo.com', 'Senha-Forte-123', { nome: 'Joana Maria Prado', apelido: 'joanap' });
  const antes = linksPara('rec2@exemplo.com');
  await esqueci('joana maria   PRADO');
  assert.equal(linksPara('rec2@exemplo.com'), antes + 1);
});

test('recuperação: mesma resposta exista ou não; nome parcial e curinga não pegam ninguém', async () => {
  const total = emails().length;
  const a = await esqueci('Ninguém Com Este Nome');
  const b = await esqueci('rec2@exemplo.com');
  assert.deepEqual(a.json, b.json);
  const depoisB = emails().length;
  assert.equal(depoisB, total + 1, 'só o e-mail existente gerou envio');
  await esqueci('Joana'); // parcial: não é nome completo
  await esqueci('% %');   // tentativa de curinga
  assert.equal(emails().length, depoisB);
});

/* ---------------- estoque por grupo ---------------- */
const ITENS = (qtd) => [{ handle: 'camiseta-teste', cor: 'Preto', tamanho: 'M', qtd }];
const checkout = (cookie, qtd) => loja.chamar('POST', '/api/checkout', {
  cookie,
  corpo: {
    itens: ITENS(qtd), freteServico: '1', pagamento: 'pix', chaveIdempotencia: crypto.randomUUID(),
    cliente: { nome: 'Cliente Teste', cpf: '529.982.247-25', telefone: '41988887777' },
    endereco: { cep: '83320000', rua: 'Rua A', numero: '1', complemento: '', bairro: 'Centro', cidade: 'Pinhais', uf: 'PR' },
  },
});
const quantidade = async () => (await loja.pg.query(`select quantidade from estoques where nome = 'Camisas'`)).rows[0].quantidade;
let estoqueId;

test('admin cria um estoque com produtos; cliente comum não', async () => {
  const comum = await contaConfirmada(loja, 'comum.estoque@exemplo.com');
  const corpo = { nome: 'Camisas', quantidade: 3, produtos: ['camiseta-teste'] };
  assert.equal((await loja.chamar('POST', '/api/admin/estoques', { cookie: comum, corpo })).status, 403);
  const r = await loja.chamar('POST', '/api/admin/estoques', { cookie: admin, corpo });
  assert.equal(r.status, 200);
  estoqueId = r.json.estoque.id;
  const lista = await loja.chamar('GET', '/api/admin/estoques', { cookie: admin });
  assert.deepEqual(lista.json.estoques[0].produtos.map((p) => p.handle), ['camiseta-teste']);
  assert.equal((await loja.chamar('POST', '/api/admin/estoques', { cookie: admin, corpo: { ...corpo, produtos: [] } })).status, 409, 'nome repetido');
});

test('não deixa comprar mais peças do que o grupo tem', async () => {
  const cookie = await contaConfirmada(loja, 'compra.estoque@exemplo.com');
  const r = await checkout(cookie, 4);
  assert.equal(r.status, 409);
  assert.match(r.json.erro, /restam 3/);
  const whats = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: ITENS(4) } });
  assert.equal(whats.status, 409, 'vale também para o pedido pelo WhatsApp');
});

test('venda paga desce o estoque; cancelamento devolve; esgotado aparece na loja', async () => {
  const cookie = await contaConfirmada(loja, 'venda.estoque@exemplo.com');
  const { json } = await checkout(cookie, 3);
  assert.equal(await quantidade(), 3, 'pedido aguardando Pix não baixa');
  require('../server/pagamento/simulado').definirStatus(json.pedido.pagamentoId, 'aprovado');
  await loja.chamar('POST', '/api/webhooks/getnet?token=token-webhook-teste-123', { corpo: { payment_id: json.pedido.pagamentoId }, origem: null });
  assert.equal(await quantidade(), 0, 'Pix aprovado baixou 3');
  const produto = (await loja.chamar('GET', '/api/loja')).json.produtos.find((p) => p.handle === 'camiseta-teste');
  assert.equal(produto.esgotado, true);
  assert.equal(produto.estoqueId, undefined, 'não expõe dados internos');
  assert.equal((await checkout(cookie, 1)).status, 409);

  // admin muda para Enviado (não baixa de novo) e depois Cancelado (devolve)
  await loja.chamar('PATCH', `/api/admin/pedidos/${json.pedido.id}`, { cookie: admin, corpo: { status: 'enviado' } });
  assert.equal(await quantidade(), 0);
  await loja.chamar('PATCH', `/api/admin/pedidos/${json.pedido.id}`, { cookie: admin, corpo: { status: 'cancelado' } });
  assert.equal(await quantidade(), 3);
  const mov = await loja.chamar('GET', `/api/admin/estoques/${estoqueId}/movimentos`, { cookie: admin });
  assert.deepEqual(mov.json.movimentos.map((m) => m.delta), [3, -3, 3]);
});

test('admin ajusta a quantidade (entrada de peças) com registro', async () => {
  await loja.chamar('PUT', `/api/admin/estoques/${estoqueId}`, { cookie: admin, corpo: { nome: 'Camisas', quantidade: 30, produtos: ['camiseta-teste'] } });
  assert.equal(await quantidade(), 30);
  const mov = await loja.chamar('GET', `/api/admin/estoques/${estoqueId}/movimentos`, { cookie: admin });
  assert.equal(mov.json.movimentos[0].motivo, 'Entrada de peças');
  assert.equal(mov.json.movimentos[0].delta, 27);
});

/* ---------------- notas fiscais ---------------- */
async function pedidoPago(email) {
  const cookie = await contaConfirmada(loja, email);
  const { json } = await checkout(cookie, 1);
  require('../server/pagamento/simulado').definirStatus(json.pedido.pagamentoId, 'aprovado');
  await loja.chamar('POST', '/api/webhooks/getnet?token=token-webhook-teste-123', { corpo: { payment_id: json.pedido.pagamentoId }, origem: null });
  return { cookie, pedido: json.pedido };
}

test('nota fiscal: só admin emite, só de pedido pago; vai por e-mail e fica na conta do cliente', async () => {
  const { cookie, pedido } = await pedidoPago('nota@exemplo.com');
  assert.equal((await loja.chamar('POST', `/api/admin/pedidos/${pedido.id}/nota`, { cookie })).status, 403, 'cliente não emite');

  const emitida = await loja.chamar('POST', `/api/admin/pedidos/${pedido.id}/nota`, { cookie: admin });
  assert.equal(emitida.status, 200);
  assert.equal(emitida.json.nota.status, 'processando');
  assert.equal((await loja.chamar('POST', `/api/admin/pedidos/${pedido.id}/nota`, { cookie: admin })).status, 409, 'sem nota duplicada');

  const atualizada = await loja.chamar('POST', `/api/admin/notas/${emitida.json.nota.id}/atualizar`, { cookie: admin });
  assert.equal(atualizada.json.nota.status, 'autorizada');
  assert.ok(atualizada.json.nota.emailEnviadoEm, 'enviada ao cliente');
  const { rows } = await loja.pg.query('select ref from notas_fiscais where id = $1', [emitida.json.nota.id]);
  assert.deepEqual(require('../server/nfe/simulado').emailsEnviados(rows[0].ref), ['nota@exemplo.com']);

  const minha = await loja.chamar('GET', '/api/conta/pedidos', { cookie });
  assert.equal(minha.json.notas.length, 1);
  assert.match(minha.json.notas[0].urlDanfe, /danfe/);
  const doCliente = await loja.chamar('GET', `/api/admin/clientes/${pedido.id.length ? (await loja.pg.query(`select id from usuarios where email = 'nota@exemplo.com'`)).rows[0].id : ''}/notas`, { cookie: admin });
  assert.equal(doCliente.json.notas.length, 1);
  const outro = await contaConfirmada(loja, 'outro.nota@exemplo.com');
  assert.equal((await loja.chamar('GET', '/api/conta/pedidos', { cookie: outro })).json.notas.length, 0, 'cliente não vê nota de outro');
});

test('nota fiscal: pedido aguardando pagamento ou pelo WhatsApp não emite', async () => {
  const cookie = await contaConfirmada(loja, 'naopago@exemplo.com');
  const { json } = await checkout(cookie, 1);
  assert.equal((await loja.chamar('POST', `/api/admin/pedidos/${json.pedido.id}/nota`, { cookie: admin })).status, 409);
  const { rows } = await loja.pg.query(`insert into pedidos (itens, total, status) values ('[]', 50, 'aguardando') returning id`);
  await loja.pg.query(`update pedidos set status = 'pago' where id = $1`, [rows[0].id]);
  const r = await loja.chamar('POST', `/api/admin/pedidos/${rows[0].id}/nota`, { cookie: admin });
  assert.equal(r.status, 409);
  assert.match(r.json.erro, /WhatsApp/);
});

test('lista de pedidos do admin mostra a nota de cada pedido', async () => {
  const r = await loja.chamar('GET', '/api/admin/pedidos', { cookie: admin });
  assert.equal(r.json.notasAtivas, true);
  assert.ok(r.json.pedidos.some((p) => p.nota?.status === 'autorizada'));
});
