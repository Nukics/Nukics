const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { criarBancoTeste } = require('./banco-teste');
const { criarClienteFalso } = require('./supabase-falso');
const { verificar } = require('../scripts/verificar-ambiente');

const envBase = {
  SUPABASE_URL: 'https://projeto-teste-49.supabase.co',
  SUPABASE_SERVICE_ROLE_KEY: 'sb_secret_fixture_sem_credencial_real_123456',
  SESSION_SECRET: 'sessao-somente-fixture-12345678901234567890',
};
let pg;
before(async () => { pg = await criarBancoTeste(); });
after(async () => { await pg.close(); });

function cliente(bucketPublico = true) {
  const c = criarClienteFalso(pg);
  c.storage.getBucket = async () => ({ data: { id: 'produtos', public: bucketPublico }, error: null });
  return c;
}

test('diagnóstico não tenta conectar sem projeto, com chave pública ou com Node incompatível', async () => {
  const proibido = () => { throw new Error('Não deveria conectar.'); };
  const ausente = await verificar({ env: {}, versaoNode: '24.19.0', criarCliente: proibido });
  assert.equal(ausente.filter((c) => c.nivel === 'erro').length, 2);
  const publica = await verificar({ env: { ...envBase, SUPABASE_SERVICE_ROLE_KEY: 'sb_publishable_fixture_123456789' }, criarCliente: proibido });
  assert.ok(publica.some((c) => c.nome === 'SUPABASE_SERVICE_ROLE_KEY' && c.nivel === 'erro'));
  const antigo = await verificar({ env: envBase, versaoNode: '20.19.0', criarCliente: proibido });
  assert.deepEqual(antigo.map((c) => [c.nome, c.nivel]), [['Node.js', 'erro']]);
});

test('esquema instalado passa sem gravar dados nem retornar valores de registros', async () => {
  const lidas = [];
  const acesso = pg.query.bind(pg);
  pg.query = async (sql, ...args) => { lidas.push(sql); return acesso(sql, ...args); };
  let checks;
  try { checks = await verificar({ env: envBase, criarCliente: () => cliente() }); }
  finally { pg.query = acesso; }
  assert.deepEqual(checks.filter((c) => c.nivel === 'erro'), []);
  assert.equal(checks.filter((c) => c.nome.startsWith('Banco:') && c.nivel === 'ok').length, 11);
  assert.equal(lidas.length, 11);
  for (const sql of lidas) assert.match(sql, /^select .* limit 0$/i);
  assert.ok(checks.some((c) => c.nome === 'Fotos' && c.nivel === 'ok'));
  assert.ok(checks.some((c) => /não confirma gatilhos/.test(c.mensagem)));
  assert.equal(JSON.stringify(checks).includes(envBase.SUPABASE_SERVICE_ROLE_KEY), false);
});

test('erro de autenticação não reproduz resposta do provedor nem imprime credenciais', async () => {
  const c = { from: () => ({ select: () => ({ limit: async () => ({ status: 401, error: {
    code: 'PGRST301', message: `Não imprimir ${envBase.SUPABASE_SERVICE_ROLE_KEY}`, details: 'dados privados',
  } }) }) }) };
  const checks = await verificar({ env: envBase, criarCliente: () => c });
  assert.ok(checks.some((v) => v.nivel === 'erro' && /Acesso recusado/.test(v.mensagem)));
  assert.equal(JSON.stringify(checks).includes(envBase.SUPABASE_SERVICE_ROLE_KEY), false);
  assert.equal(JSON.stringify(checks).includes('dados privados'), false);
});

test('produção identifica e-mail/sessão ausentes e pagamento simulado sem autorizar cobrança real', async () => {
  const checks = await verificar({ env: { ...envBase, SESSION_SECRET: '', NODE_ENV: 'production', PAGAMENTO_PROVEDOR: 'simulado' }, criarCliente: () => cliente() });
  for (const nome of ['SESSION_SECRET', 'Endereço público', 'E-mail', 'Pagamento']) {
    assert.ok(checks.some((c) => c.nome === nome && c.nivel === 'erro'), nome);
  }
});

test('configuração parcial da Getnet é identificada por nomes e não por valores secretos', async () => {
  const checks = await verificar({ env: { ...envBase, PAGAMENTO_PROVEDOR: 'getnet-global', GETNET_GLOBAL_CLIENT_ID: 'id-privado-somente-fixture', GETNET_GLOBAL_AMBIENTE: 'producao' }, criarCliente: () => cliente() });
  assert.ok(checks.some((c) => c.nome === 'Getnet Global' && /GETNET_GLOBAL_CLIENT_SECRET/.test(c.mensagem)));
  assert.ok(checks.some((c) => c.nome === 'Ambiente Getnet' && c.nivel === 'erro'));
  assert.equal(JSON.stringify(checks).includes('id-privado-somente-fixture'), false);
});

test('bucket privado é apontado como bloqueio para as fotos da loja', async () => {
  const checks = await verificar({ env: envBase, criarCliente: () => cliente(false) });
  assert.ok(checks.some((c) => c.nome === 'Fotos' && c.nivel === 'erro'));
});

test('tabela de estoque por cor ausente identifica migração 005 sem modificar o banco', async () => {
  await pg.exec('drop table estoque_produtos_cores');
  const checks = await verificar({ env: envBase, criarCliente: () => cliente() });
  assert.ok(checks.some((c) => c.nome === 'Banco: estoque_produtos_cores' && c.nivel === 'erro' && /migração 005/.test(c.mensagem)));
  assert.ok(checks.some((c) => c.nome === 'Banco: produtos' && c.nivel === 'ok'));
});
