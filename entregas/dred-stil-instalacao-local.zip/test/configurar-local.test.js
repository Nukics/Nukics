const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { parseEnv } = require('node:util');
const { spawn } = require('node:child_process');
const { Readable, Writable } = require('node:stream');
const { criarConfiguracao, configurarInterativo } = require('../scripts/configurar-local');

const URL_TESTE = 'https://loja-de-teste-73.supabase.co';
const CHAVE_TESTE = 'sb_secret_somente_fixture_testes_123456789';
const chaveJwt = (role) => [
  Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url'),
  Buffer.from(JSON.stringify({ role, iss: 'somente-fixture' })).toString('base64url'),
  Buffer.from('assinatura-falsa-somente-para-teste').toString('base64url'),
].join('.');

async function pasta(t) {
  const diretorio = await fs.mkdtemp(path.join(os.tmpdir(), 'dredstil-configurar-'));
  t.after(() => fs.rm(diretorio, { recursive: true, force: true }));
  await fs.copyFile(path.join(__dirname, '..', '.env.example'), path.join(diretorio, '.env.example'));
  return diretorio;
}

function coletor() {
  let texto = '';
  return {
    saida: new Writable({ write(chunk, _encoding, callback) { texto += chunk.toString(); callback(); } }),
    ler: () => texto,
  };
}

test('configuração privada é lida pelo parser Node sem alterar o modelo nem inventar credenciais externas', async (t) => {
  const diretorio = await pasta(t);
  const modelo = await fs.readFile(path.join(diretorio, '.env.example'), 'utf8');
  const r = await criarConfiguracao({ diretorio, urlSupabase: `${URL_TESTE}/`, chaveServidor: CHAVE_TESTE });
  assert.equal(r.criado, true);
  const texto = await fs.readFile(r.caminho, 'utf8');
  const env = parseEnv(texto);
  assert.equal(env.SUPABASE_URL, URL_TESTE);
  assert.equal(env.SUPABASE_SERVICE_ROLE_KEY, CHAVE_TESTE);
  assert.equal(env.APP_URL, 'http://localhost:5173');
  assert.equal(env.PAGAMENTO_PROVEDOR, '');
  assert.equal(env.GETNET_GLOBAL_AMBIENTE, 'homologacao');
  for (const nome of ['GETNET_CLIENT_ID', 'GETNET_CLIENT_SECRET', 'GETNET_SELLER_ID',
    'GETNET_GLOBAL_CLIENT_ID', 'GETNET_GLOBAL_CLIENT_SECRET', 'GETNET_GLOBAL_SELLER_ID',
    'RESEND_API_KEY', 'MELHOR_ENVIO_CLIENT_SECRET']) assert.equal(env[nome], '');
  const segredos = ['SESSION_SECRET', 'CRON_SECRET', 'GETNET_WEBHOOK_TOKEN', 'GETNET_GLOBAL_WEBHOOK_PASSWORD'];
  for (const nome of segredos) assert.match(env[nome], /^[a-f0-9]{64}$/);
  assert.equal(new Set(segredos.map((nome) => env[nome])).size, segredos.length);
  assert.match(env.GETNET_GLOBAL_WEBHOOK_USER, /^dredstil_[a-f0-9]{16}$/);
  assert.ok(texto.includes('# Frete (Melhor Envio).'));
  assert.equal(await fs.readFile(path.join(diretorio, '.env.example'), 'utf8'), modelo);
  if (process.platform !== 'win32') assert.equal((await fs.stat(r.caminho)).mode & 0o777, 0o600);
});

test('aceita a chave legada service_role, sem atribuir esse papel a uma chave anon', async (t) => {
  const diretorio = await pasta(t);
  const chave = chaveJwt('service_role');
  const r = await criarConfiguracao({ diretorio, urlSupabase: URL_TESTE, chaveServidor: chave });
  assert.equal(parseEnv(await fs.readFile(r.caminho, 'utf8')).SUPABASE_SERVICE_ROLE_KEY, chave);
});

test('a configuração existente não é sobrescrita, lida nem exposta na execução interativa', async (t) => {
  const diretorio = await pasta(t);
  const caminho = path.join(diretorio, '.env.local');
  const anterior = 'SESSION_SECRET=fixture-segredo-que-deve-ser-preservado\n';
  await fs.writeFile(caminho, anterior);
  const capturado = coletor();
  const r = await configurarInterativo({ diretorio, entrada: Readable.from([`${URL_TESTE}\n${CHAVE_TESTE}\n`]), saida: capturado.saida });
  assert.equal(r.criado, false);
  assert.equal(await fs.readFile(caminho, 'utf8'), anterior);
  assert.match(capturado.ler(), /já existe e foi preservado/);
  assert.match(capturado.ler(), /npm run verificar/);
  assert.equal(capturado.ler().includes('fixture-segredo'), false);
  assert.equal(capturado.ler().includes(CHAVE_TESTE), false);
  assert.equal(capturado.ler().includes(URL_TESTE), false);
  const repetido = await criarConfiguracao({ diretorio });
  assert.equal(repetido.criado, false);
  assert.equal(await fs.readFile(caminho, 'utf8'), anterior);
});

test('valores que poderiam injetar linhas ou usar chaves públicas não criam configuração', async (t) => {
  const casos = [
    { urlSupabase: 'http://loja.supabase.co', chaveServidor: CHAVE_TESTE },
    { urlSupabase: 'https://SEU-PROJETO.supabase.co', chaveServidor: CHAVE_TESTE },
    { urlSupabase: 'https://usuario:senha@loja.supabase.co', chaveServidor: CHAVE_TESTE },
    { urlSupabase: `${URL_TESTE}/rest/v1`, chaveServidor: CHAVE_TESTE },
    { urlSupabase: `${URL_TESTE}?SESSION_SECRET=fraco`, chaveServidor: CHAVE_TESTE },
    { urlSupabase: `${URL_TESTE}\nPAGAMENTO_PROVEDOR=simulado`, chaveServidor: CHAVE_TESTE },
    { urlSupabase: URL_TESTE, chaveServidor: chaveJwt('anon') },
    { urlSupabase: URL_TESTE, chaveServidor: 'sb_publishable_somente_fixture_testes_123456789' },
    { urlSupabase: URL_TESTE, chaveServidor: `${CHAVE_TESTE}\nSESSION_SECRET=fraco` },
    { urlSupabase: URL_TESTE, chaveServidor: `${CHAVE_TESTE}\u0000` },
    { urlSupabase: URL_TESTE, chaveServidor: `'${CHAVE_TESTE}'` },
  ];
  for (const dados of casos) {
    const diretorio = await pasta(t);
    await assert.rejects(criarConfiguracao({ diretorio, ...dados }), (erro) => {
      assert.equal(erro.message.includes(dados.chaveServidor), false);
      return true;
    });
    await assert.rejects(fs.stat(path.join(diretorio, '.env.local')), { code: 'ENOENT' });
  }
});

test('a entrada interativa por linhas não ecoa as credenciais e indica as verificações pendentes', async (t) => {
  const diretorio = await pasta(t);
  const capturado = coletor();
  const r = await configurarInterativo({ diretorio, entrada: Readable.from([`${URL_TESTE}\n${CHAVE_TESTE}\n`]), saida: capturado.saida });
  assert.equal(r.criado, true);
  assert.equal(capturado.ler().includes(CHAVE_TESTE), false);
  assert.equal(capturado.ler().includes(URL_TESTE), false);
  assert.match(capturado.ler(), /npm run verificar/);
  assert.match(capturado.ler(), /npm start/);
  assert.match(capturado.ler(), /banco e as integrações ainda precisam ser conferidos/);
  assert.match(capturado.ler(), /pagamento online permanece desligado/);
  const env = parseEnv(await fs.readFile(r.caminho, 'utf8'));
  assert.equal(env.SUPABASE_SERVICE_ROLE_KEY, CHAVE_TESTE);
  assert.equal(capturado.ler().includes(env.SESSION_SECRET), false);
});

test('cancelar a entrada ou usar Node incompatível deixa a pasta sem .env.local', async (t) => {
  const diretorio = await pasta(t);
  const capturado = coletor();
  await assert.rejects(configurarInterativo({ diretorio, entrada: Readable.from([]), saida: capturado.saida }), /cancelada/);
  await assert.rejects(configurarInterativo({ diretorio, entrada: Readable.from([]), saida: capturado.saida, versaoNode: '20.19.0' }), /Node.js 22/);
  await assert.rejects(fs.stat(path.join(diretorio, '.env.local')), { code: 'ENOENT' });
});

test('CLI relata erro de forma segura sem imprimir a chave informada', async (t) => {
  const diretorio = await pasta(t);
  // Executa o arquivo real em uma cópia isolada: a configuração do projeto não é tocada.
  await fs.mkdir(path.join(diretorio, 'scripts'));
  const script = path.join(diretorio, 'scripts', 'configurar-local.js');
  await fs.copyFile(path.join(__dirname, '..', 'scripts', 'configurar-local.js'), script);
  const filho = spawn(process.execPath, [script], { stdio: ['pipe', 'pipe', 'pipe'] });
  let output = '';
  filho.stdout.on('data', (d) => { output += d.toString(); });
  filho.stderr.on('data', (d) => { output += d.toString(); });
  filho.stdin.end(`${URL_TESTE}\nsb_publishable_somente_fixture_testes_123456789\n`);
  const codigo = await new Promise((resolve, reject) => { filho.once('error', reject); filho.once('close', resolve); });
  assert.equal(codigo, 1);
  assert.match(output, /A chave anon\/publishable não serve/);
  assert.equal(output.includes('sb_publishable_somente_fixture'), false);
  assert.equal(output.includes(URL_TESTE), false);
  await assert.rejects(fs.stat(path.join(diretorio, '.env.local')), { code: 'ENOENT' });
});
