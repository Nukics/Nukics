// Checkout com Pix, frete, webhook de pagamento, isolamento entre clientes e painel admin.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, ultimoEmail, codigoDoEmail, contaConfirmada } = require('./ajuda');

let loja;
before(async () => (loja = await iniciarLoja()));
after(() => loja.fechar());

const TOKEN = 'token-webhook-teste-123';
const ITENS = [{ handle: 'camiseta-teste', cor: 'Preto', tamanho: 'M', qtd: 2 }];
const dados = (extra = {}) => ({
  itens: ITENS,
  freteServico: '1',
  cliente: { nome: 'Cliente Teste', cpf: '529.982.247-25', telefone: '(41) 98888-7777' },
  endereco: { cep: '83320-000', rua: 'Rua Teste', numero: '10', complemento: '', bairro: 'Centro', cidade: 'Pinhais', uf: 'PR' },
  pagamento: 'pix',
  chaveIdempotencia: crypto.randomUUID(),
  ...extra,
});
const comprar = (cookie, corpo = dados(), opcoes = {}) => loja.chamar('POST', '/api/checkout', { cookie, corpo, ...opcoes });
const notificar = (pagamentoId, token = TOKEN) =>
  loja.chamar('POST', `/api/webhooks/getnet?token=${token}`, { corpo: { payment_id: pagamentoId }, origem: null });
const situacao = async (id) => (await loja.pg.query('select status from pedidos where id = $1', [id])).rows[0]?.status;
const simulado = () => require('../server/pagamento/simulado');

test('a loja informa que o checkout online está ligado', async () => {
  const r = await loja.chamar('GET', '/api/loja');
  assert.equal(r.json.config.checkout, true);
});

test('checkout exige login', async () => {
  assert.equal((await comprar(undefined)).status, 401);
});

test('preço e frete vêm do servidor; valores do navegador são ignorados', async () => {
  const cookie = await contaConfirmada(loja, 'preco@exemplo.com');
  const corpo = { ...dados(), total: 1, itens: [{ ...ITENS[0], preco: 0.01 }] };
  const r = await comprar(cookie, corpo);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.pedido.subtotal, 300);
  assert.ok(r.json.pedido.frete > 0);
  assert.equal(r.json.pedido.total, 300 + r.json.pedido.frete);
  assert.match(r.json.pedido.pagamentoDados.copiaECola, /SIMULADO/);
});

test('frete inventado é recusado; produto sob consulta não vai para o Pix', async () => {
  const cookie = await contaConfirmada(loja, 'frete@exemplo.com');
  assert.equal((await comprar(cookie, dados({ freteServico: '999' }))).status, 409);
  const consulta = await comprar(cookie, dados({ itens: [{ handle: 'sob-consulta', cor: 'Preto', tamanho: 'M', qtd: 1 }] }));
  assert.equal(consulta.status, 409);
});

test('retirada na loja não exige endereço e não cobra frete', async () => {
  const cookie = await contaConfirmada(loja, 'retirada@exemplo.com');
  const r = await comprar(cookie, dados({
    tipoEntrega: 'retirada-loja',
    freteServico: 'retirada-loja',
    endereco: undefined,
  }));
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.pedido.frete, 0);
  assert.match(r.json.pedido.freteNome, /Retirada na loja/);
});

test('validação: CPF, HTML no endereço, quantidade e corpo gigante', async () => {
  const cookie = await contaConfirmada(loja, 'valida@exemplo.com');
  assert.equal((await comprar(cookie, dados({ cliente: { nome: 'Ana', cpf: '111.111.111-11', telefone: '41988887777' } }))).status, 400);
  const end = { ...dados().endereco, rua: '<img src=x onerror=alert(1)>' };
  assert.equal((await comprar(cookie, dados({ endereco: end }))).status, 400);
  assert.equal((await comprar(cookie, dados({ itens: [{ ...ITENS[0], qtd: -2 }] }))).status, 400);
  assert.equal((await comprar(cookie, { ...dados(), lixo: 'x'.repeat(200_000) })).status, 413);
});

test('CSRF: escrita vinda de outro site é recusada', async () => {
  const cookie = await contaConfirmada(loja, 'csrf@exemplo.com');
  assert.equal((await comprar(cookie, dados(), { origem: 'https://site-malicioso.com' })).status, 403);
});

test('clique duplo / requisições simultâneas: um pedido e uma cobrança só', async () => {
  const cookie = await contaConfirmada(loja, 'duplo@exemplo.com');
  const corpo = dados();
  const [a, b] = await Promise.all([comprar(cookie, corpo), comprar(cookie, corpo)]);
  assert.equal(a.status, 200);
  assert.equal(b.status, 200);
  assert.equal(a.json.pedido.id, b.json.pedido.id);
  const { rows } = await loja.pg.query(`select count(*)::int n, count(distinct pagamento_id)::int pix from pedidos p join usuarios u on u.id = p.usuario_id where u.email = 'duplo@exemplo.com'`);
  assert.deepEqual(rows[0], { n: 1, pix: 1 });
});

test('limite de 3 pedidos aguardando Pix por cliente', async () => {
  const cookie = await contaConfirmada(loja, 'abertos@exemplo.com');
  for (let i = 0; i < 3; i++) assert.equal((await comprar(cookie)).status, 200);
  assert.equal((await comprar(cookie)).status, 429);
});

test('um cliente não vê o pedido de outro', async () => {
  const ana = await contaConfirmada(loja, 'dona@exemplo.com');
  const beto = await contaConfirmada(loja, 'curioso@exemplo.com');
  const { json } = await comprar(ana);
  const id = json.pedido.id;
  assert.equal((await loja.chamar('GET', `/api/pedidos/${id}`, { cookie: ana })).status, 200);
  assert.equal((await loja.chamar('GET', `/api/pedidos/${id}`, { cookie: beto })).status, 404);
  const lista = await loja.chamar('GET', '/api/conta/pedidos', { cookie: beto });
  assert.equal(lista.json.pedidos.length, 0);
});

async function pedidoPendente(email) {
  const cookie = await contaConfirmada(loja, email);
  const { json } = await comprar(cookie);
  return { id: json.pedido.id, pagamentoId: json.pedido.pagamentoId, total: json.pedido.total };
}

test('webhook sem segredo ou com segredo errado: 401 e nada muda', async () => {
  const p = await pedidoPendente('wh1@exemplo.com');
  simulado().definirStatus(p.pagamentoId, 'aprovado');
  assert.equal((await notificar(p.pagamentoId, 'errado')).status, 401);
  assert.equal((await loja.chamar('POST', '/api/webhooks/getnet', { corpo: { payment_id: p.pagamentoId }, origem: null })).status, 401);
  assert.equal(await situacao(p.id), 'aguardando');
});

test('notificação dizendo "pago" não aprova: o status vem do provedor', async () => {
  const p = await pedidoPendente('wh2@exemplo.com');
  const r = await loja.chamar('POST', `/api/webhooks/getnet?token=${TOKEN}`, { corpo: { payment_id: p.pagamentoId, status: 'APPROVED' }, origem: null });
  assert.equal(r.status, 200);
  assert.equal(await situacao(p.id), 'aguardando');
});

test('pagamento aprovado marca pago; repetição é ignorada; "negado" depois não desfaz', async () => {
  const p = await pedidoPendente('wh3@exemplo.com');
  simulado().definirStatus(p.pagamentoId, 'aprovado');
  assert.equal((await notificar(p.pagamentoId)).json.resultado, 'atualizado');
  assert.equal(await situacao(p.id), 'pago');
  assert.equal((await notificar(p.pagamentoId)).json.resultado, 'ignorado');
  simulado().definirStatus(p.pagamentoId, 'negado');
  await notificar(p.pagamentoId);
  assert.equal(await situacao(p.id), 'pago');
  const { rows } = await loja.pg.query('select count(*)::int n from pagamento_eventos where pedido_id = $1', [p.id]);
  assert.equal(rows[0].n, 2);
});

test('valor pago diferente do total vai para revisão', async () => {
  const p = await pedidoPendente('wh4@exemplo.com');
  simulado().definirStatus(p.pagamentoId, 'aprovado', 100);
  await notificar(p.pagamentoId);
  assert.equal(await situacao(p.id), 'revisar');
});

test('cron: exige segredo; expira Pix vencido; pago depois de expirar vai para revisão', async () => {
  const p = await pedidoPendente('cron@exemplo.com');
  await loja.pg.query(`update pedidos set expira_em = now() - interval '1 minute' where id = $1`, [p.id]);
  assert.equal((await loja.chamar('GET', '/api/cron/expirar-pedidos')).status, 401);
  const r = await loja.chamar('GET', '/api/cron/expirar-pedidos', { headers: { authorization: 'Bearer cron-teste' } });
  assert.ok(r.json.expirados >= 1);
  assert.equal(await situacao(p.id), 'expirado');
  simulado().definirStatus(p.pagamentoId, 'aprovado');
  await notificar(p.pagamentoId);
  assert.equal(await situacao(p.id), 'revisar');
});

test('pedidos antigos do WhatsApp (sem prazo) não são expirados pelo cron', async () => {
  const { rows } = await loja.pg.query(`insert into pedidos (itens, total) values ('[]', 50) returning id`);
  await loja.chamar('GET', '/api/cron/expirar-pedidos', { headers: { authorization: 'Bearer cron-teste' } });
  assert.equal(await situacao(rows[0].id), 'aguardando');
});

test('admin: cliente comum é barrado; admin sem duas etapas também', async () => {
  const comum = await contaConfirmada(loja, 'comum@exemplo.com');
  assert.equal((await loja.chamar('GET', '/api/admin/pedidos', { cookie: comum })).status, 403);
  const adm = await contaConfirmada(loja, 'admin@exemplo.com');
  await loja.pg.query(`update usuarios set papel = 'admin' where email = 'admin@exemplo.com'`);
  const r = await loja.chamar('GET', '/api/admin/pedidos', { cookie: adm });
  assert.equal(r.status, 403);
  assert.match(r.json.erro, /duas etapas/);
  const pagina = await loja.chamar('GET', '/admin', { cookie: adm });
  assert.equal(pagina.status, 303, 'página /admin redireciona');
});

test('admin com duas etapas usa o painel e não consegue desligar a verificação', async () => {
  const cookie = await contaConfirmada(loja, 'chefe@exemplo.com');
  await loja.pg.query(`delete from usuarios where papel = 'admin'`);
  await loja.pg.query(`update usuarios set papel = 'admin' where email = 'chefe@exemplo.com'`);
  const ativar = await loja.chamar('POST', '/api/conta/dois-fatores', { cookie, corpo: { ativar: true, senha: 'Senha-Forte-123' } });
  assert.equal(ativar.status, 200);
  assert.equal((await loja.chamar('GET', '/api/admin/pedidos', { cookie: ativar.cookie })).status, 200);
  const desligar = await loja.chamar('POST', '/api/conta/dois-fatores', { cookie: ativar.cookie, corpo: { ativar: false, senha: 'Senha-Forte-123' } });
  assert.equal(desligar.status, 403);
  // novo login exige código
  const login = await loja.chamar('POST', '/api/conta/entrar', { corpo: { email: 'chefe@exemplo.com', senha: 'Senha-Forte-123' } });
  assert.equal(login.json.etapa, 'codigo');
  const codigo = codigoDoEmail(ultimoEmail('chefe@exemplo.com'));
  const ok = await loja.chamar('POST', '/api/conta/codigo', { corpo: { desafio: login.json.desafio, codigo } });
  assert.equal((await loja.chamar('GET', '/api/admin/vendas', { cookie: ok.cookie })).status, 200);
});

test('admin envia link de nova senha (sem ver a senha) e a senha temporária fica desligada', async () => {
  const { rows } = await loja.pg.query(`select id from usuarios where email = 'comum@exemplo.com'`);
  const login = await loja.chamar('POST', '/api/conta/entrar', { corpo: { email: 'chefe@exemplo.com', senha: 'Senha-Forte-123' } });
  const adm = (await loja.chamar('POST', '/api/conta/codigo', {
    corpo: { desafio: login.json.desafio, codigo: codigoDoEmail(ultimoEmail('chefe@exemplo.com')) },
  })).cookie;
  const r = await loja.chamar('POST', `/api/admin/clientes/${rows[0].id}/redefinir`, { cookie: adm });
  assert.equal(r.status, 200);
  assert.ok(!JSON.stringify(r.json).match(/senha"\s*:/), 'resposta não traz senha');
  assert.match(ultimoEmail('comum@exemplo.com').assunto, /Redefinição de senha/);
  assert.equal((await loja.chamar('POST', `/api/admin/clientes/${rows[0].id}/senha`, { cookie: adm })).status, 410);
});

test('funções do banco não podem ser chamadas pela chave pública (anon)', async () => {
  const { rows } = await loja.pg.query(`
    select p.proname, has_function_privilege('anon', p.oid, 'execute') as anon
      from pg_proc p where p.proname in ('consumir_limite','consumir_token_conta','tentar_desafio_2fa','criar_pedido_checkout','processar_pagamento')`);
  assert.equal(rows.length, 5);
  assert.ok(rows.every((r) => r.anon === false), JSON.stringify(rows));
});

test('rota de pagamento de teste não existe em produção', async () => {
  const ambiente = require('../server/ambiente');
  assert.equal(ambiente.EM_PRODUCAO, false);
  // em produção o provedor simulado nunca é escolhido
  const antes = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  delete require.cache[require.resolve('../server/ambiente')];
  const prod = require('../server/ambiente');
  assert.equal(prod.provedorPagamento(), null);
  assert.equal(prod.provedorFrete(), null);
  assert.equal(prod.checkoutAtivo(), false);
  process.env.NODE_ENV = antes;
  delete require.cache[require.resolve('../server/ambiente')];
});
