// Testes de contrato local. O stub representa a Getnet; não é homologação real.
const { test, before, beforeEach, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, contaConfirmada } = require('./ajuda');
const globalApi = require('../server/pagamento/getnet-global');

let loja;
let cookie;
let outraConta;
const fetchReal = global.fetch;
const intents = new Map();
const requests = [];
let oauthCount = 0;
let createCount = 0;
let falharCriacao = false;
let falharConsulta = false;
const seller = '11111111-1111-4111-8111-111111111111';
const basic = `Basic ${Buffer.from('usuario-webhook-teste:senha-webhook-apenas-teste').toString('base64')}`;
const jsonResponse = (j, status = 200) => new Response(JSON.stringify(j), { status, headers: { 'content-type': 'application/json' } });

before(async () => {
  loja = await iniciarLoja();
  Object.assign(process.env, {
    PAGAMENTO_PROVEDOR: 'getnet-global', GETNET_GLOBAL_AMBIENTE: 'homologacao',
    GETNET_GLOBAL_CLIENT_ID: 'client-id-apenas-teste', GETNET_GLOBAL_CLIENT_SECRET: 'client-secret-apenas-teste',
    GETNET_GLOBAL_SELLER_ID: seller, GETNET_GLOBAL_WEBHOOK_USER: 'usuario-webhook-teste',
    GETNET_GLOBAL_WEBHOOK_PASSWORD: 'senha-webhook-apenas-teste',
  });
  require('../server/publico').limpar();
  global.fetch = async (url, opts = {}) => {
    if (!String(url).startsWith('https://api.pre.globalgetnet.com/')) return fetchReal(url, opts);
    const path = new URL(url).pathname;
    requests.push({ path, opts });
    if (path === '/authentication/oauth2/access_token') {
      oauthCount++;
      assert.equal(opts.method, 'POST');
      assert.equal(opts.body, 'grant_type=client_credentials');
      assert.equal(opts.headers.Authorization, `Basic ${Buffer.from('client-id-apenas-teste:client-secret-apenas-teste').toString('base64')}`);
      return jsonResponse({ access_token: 'token-falso-local', token_type: 'Bearer', expires_in: 3599 });
    }
    assert.equal(opts.headers.Authorization, 'Bearer token-falso-local');
    if (path.endsWith('/technical-configurations')) {
      if (opts.method === 'PATCH') {
        const body = JSON.parse(opts.body);
        assert.equal(body.notification.authentication_type, 'user_credentials');
        assert.equal(body.notification.url, 'https://loja.exemplo.com/api/webhooks/getnet-global');
        assert.equal(body.success_url, 'https://loja.exemplo.com/checkout');
        assert.equal(body.layout_customization, undefined); // não altera layout remoto existente
      }
      return jsonResponse({ notification: { authentication_type: 'user_credentials', url: 'https://loja.exemplo.com/api/webhooks/getnet-global' } });
    }
    if (path.endsWith('/sellers')) return jsonResponse({ seller_id: seller });
    if (path.endsWith('/business-configurations')) return jsonResponse({ credit: { enable: true }, instant_payment: { enable: true } });
    if (path === '/dpy/web-checkout/v1/payment-intent' && opts.method === 'POST') {
      createCount++;
      if (falharCriacao) throw new Error('Timeout simulado');
      const dados = JSON.parse(opts.body);
      assert.equal(dados.expires_at, '30m');
      assert.equal(dados.customer.customer_id, '52998224725');
      assert.equal(dados.payment.currency, 'BRL');
      assert.equal(dados.payment.amount, dados.product.reduce((s, p) => s + p.value * p.quantity, 0));
      assert.equal(dados.shipping?.shipping_amount, undefined);
      assert.equal(dados.payment.method, undefined); // método é escolhido no iframe
      assert.equal(dados.customer.billing_address.country, 'BR');
      const id = crypto.randomUUID();
      intents.set(id, { status: 'pending', payment_intent_id: id, seller_id: seller, country: 'BR', order_id: dados.order_id,
        payment: dados.payment, records: [] });
      return jsonResponse({ payment_intent_id: id, trade_name: 'Loja de teste', redirect_url: 'https://www.pre.globalgetnet.com/hosted-web-checkout/exemplo' }, 201);
    }
    const id = path.split('/').at(-1);
    if (falharConsulta && (!opts.method || opts.method === 'GET')) return jsonResponse({}, 503);
    const intent = intents.get(id);
    if (!intent) return jsonResponse({}, 404);
    if (opts.method === 'PATCH') {
      assert.deepEqual(JSON.parse(opts.body), { status: 'cancelled' });
      intent.status = 'cancelled';
      return new Response(null, { status: 204 });
    }
    return jsonResponse(intent);
  };
  cookie = await contaConfirmada(loja, 'global@exemplo.com');
  outraConta = await contaConfirmada(loja, 'global-outro@exemplo.com');
});
after(async () => { global.fetch = fetchReal; await loja.fechar(); });
beforeEach(async () => {
  cookie = await contaConfirmada(loja, `g${crypto.randomUUID().replaceAll('-', '')}@exemplo.com`);
});

const dados = (extra = {}) => ({
  itens: [{ handle: 'camiseta-teste', cor: 'Preto', tamanho: 'M', qtd: 1 }],
  tipoEntrega: 'melhor-envio', freteServico: '1', pagamento: 'getnet-checkout',
  cliente: { nome: 'Cliente Teste', cpf: '52998224725', telefone: '41988887777' },
  endereco: { cep: '83320000', rua: 'Rua Teste', numero: '10', bairro: 'Centro', cidade: 'Pinhais', uf: 'PR' },
  chaveIdempotencia: crypto.randomUUID(), ...extra,
});
const comprar = (corpo = dados()) => loja.chamar('POST', '/api/checkout', { cookie, corpo });
const lerPedido = async (id) => (await loja.chamar('GET', `/api/pedidos/${id}`, { cookie })).json.pedido;
const notificar = (pedido, extra = {}, auth = basic) => loja.chamar('POST', '/api/webhooks/getnet-global', {
  origem: null, headers: { authorization: auth },
  corpo: { payment_intent_id: pedido.pagamentoId, order_id: pedido.id, seller: { id: seller }, ...extra },
});
async function novoPedido() {
  // O limite de pedidos abertos continua sendo exercitado pela suíte original.
  await loja.pg.exec("update pedidos set expira_em = now() - interval '1 minute' where status = 'aguardando'");
  const r = await comprar();
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r.json.pedido;
}

test('OAuth concorrente usa uma renovação e não expõe o token', async () => {
  assert.deepEqual(await Promise.all([globalApi.accessToken(), globalApi.accessToken()]), ['token-falso-local', 'token-falso-local']);
  assert.equal(oauthCount, 1);
  const r = await loja.chamar('GET', '/api/loja');
  assert.equal(r.json.config.checkoutIntegrado, true);
  assert.doesNotMatch(JSON.stringify(r.json), /client-secret|token-falso|usuario-webhook|senha-webhook/);
});

test('checkout calcula total no servidor e expõe apenas o identificador público', async () => {
  const r = await comprar(dados({ total: 1 }));
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.ok(r.json.pedido.total >= 150);
  assert.deepEqual(r.json.pedido.pagamentoDados, { tipo: 'getnet-global', ambiente: 'homologacao', paymentIntentId: r.json.pedido.pagamentoId });
  assert.doesNotMatch(JSON.stringify(r.json), /token-falso|client-secret|redirect_url/);
});

test('criação concorrente e repetição não criam duas intenções', async () => {
  const body = dados();
  const antes = createCount;
  const rs = await Promise.all([comprar(body), comprar(body)]);
  assert.ok(rs.some((r) => r.status === 200));
  assert.ok(rs.every((r) => [200, 409].includes(r.status)));
  assert.equal(createCount, antes + 1);
  const r = await comprar(body);
  assert.equal(r.status, 200);
  assert.equal(createCount, antes + 1);
});

test('retirada pede endereço de cobrança sem cadastrar uma entrega fictícia', async () => {
  await loja.pg.exec("update pedidos set expira_em = now() - interval '1 minute' where status = 'aguardando'");
  const r = await comprar(dados({ tipoEntrega: 'retirada-loja', freteServico: 'retirada-loja' }));
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.pedido.frete, 0);
  assert.equal(r.json.pedido.entrega, null);
  const body = JSON.parse(requests.filter((r) => r.opts.method === 'POST' && r.path.endsWith('/payment-intent')).at(-1).opts.body);
  assert.equal(body.pickup_store, true);
  assert.equal(body.shipping, undefined);
  assert.equal(body.customer.billing_address.postal_code, '83320000');
  assert.equal((await comprar(dados({ tipoEntrega: 'retirada-loja', freteServico: 'retirada-loja', endereco: undefined }))).status, 400);
});

test('webhook sem autenticação ou com referência trocada não altera pedido', async () => {
  const p = await novoPedido();
  assert.equal((await notificar(p, {}, 'Basic invalido')).status, 401);
  assert.equal((await notificar(p, { order_id: crypto.randomUUID() })).status, 400);
  assert.equal((await notificar(p, { seller: { id: crypto.randomUUID() } })).status, 400);
  assert.equal((await lerPedido(p.id)).status, 'aguardando');
});

test('status forjado no webhook é ignorado; aprovação real consultada é idempotente', async () => {
  const p = await novoPedido();
  await notificar(p, { status: 'paid', payment: { amount: 1, result: { status: 'Authorized' } } });
  assert.equal((await lerPedido(p.id)).status, 'aguardando');
  intents.get(p.pagamentoId).status = 'paid';
  assert.equal((await notificar(p)).status, 200);
  assert.equal((await lerPedido(p.id)).status, 'pago');
  assert.equal((await notificar(p)).json.resultado, 'ignorado');
  intents.get(p.pagamentoId).status = 'denied';
  await notificar(p);
  assert.equal((await lerPedido(p.id)).status, 'pago');
});

test('recusa permite nova tentativa na mesma intenção; aprovação posterior marca pago', async () => {
  const p = await novoPedido();
  intents.get(p.pagamentoId).status = 'denied';
  await notificar(p);
  const negado = await lerPedido(p.id);
  assert.equal(negado.status, 'aguardando');
  assert.equal(negado.pagamentoStatus, 'negado');
  intents.get(p.pagamentoId).status = 'paid';
  await notificar(p);
  assert.equal((await lerPedido(p.id)).status, 'pago');
});

test('valor divergente vai para revisão; valor ausente e moeda divergente não aprovam', async () => {
  const p = await novoPedido();
  const remote = intents.get(p.pagamentoId);
  remote.status = 'paid';
  remote.payment.amount = 1;
  await notificar(p);
  assert.equal((await lerPedido(p.id)).status, 'revisar');
  const q = await novoPedido();
  const outro = intents.get(q.pagamentoId);
  outro.status = 'paid';
  outro.payment.currency = 'USD';
  assert.equal((await notificar(q)).status, 502);
  assert.equal((await lerPedido(q.id)).status, 'aguardando');
  outro.payment.currency = 'BRL';
  delete outro.payment.amount;
  assert.equal((await notificar(q)).status, 502);
});

test('consulta exige dono e confirmação da conta/país/referência pela API', async () => {
  const p = await novoPedido();
  const url = `/api/pedidos/${p.id}/consultar-pagamento`;
  assert.equal((await loja.chamar('POST', url, { cookie: outraConta, corpo: {} })).status, 404);
  const remote = intents.get(p.pagamentoId);
  remote.seller_id = crypto.randomUUID();
  assert.equal((await loja.chamar('POST', url, { cookie, corpo: {} })).status, 502);
  remote.seller_id = seller;
  remote.order_id = crypto.randomUUID();
  assert.equal((await notificar(p)).status, 502);
  remote.order_id = p.id;
  remote.status = 'paid';
  assert.equal((await loja.chamar('POST', url, { cookie, corpo: {} })).json.pedido.status, 'pago');
});

test('cancelamento e aprovação tardia são tratados sem liberar pedido indevidamente', async () => {
  const p = await novoPedido();
  intents.get(p.pagamentoId).status = 'cancelled';
  await notificar(p);
  assert.equal((await lerPedido(p.id)).status, 'cancelado');
  intents.get(p.pagamentoId).status = 'paid';
  await notificar(p);
  assert.equal((await lerPedido(p.id)).status, 'revisar');
});

test('falha de comunicação bloqueia recriação automática da intenção', async () => {
  await loja.pg.exec("update pedidos set expira_em = now() - interval '1 minute' where status = 'aguardando'");
  falharCriacao = true;
  const antes = createCount;
  const body = dados();
  try {
    assert.equal((await comprar(body)).status, 502);
    assert.equal((await comprar(body)).status, 409);
    assert.equal(createCount, antes + 1);
    const { rows } = await loja.pg.query('select pagamento_status from pedidos where chave_idempotencia = $1', [body.chaveIdempotencia]);
    assert.equal(rows[0].pagamento_status, 'reconciliar');
  } finally { falharCriacao = false; }
});

test('CSP do checkout permite só hosts Getnet esperados; produção exige liberação explícita', async () => {
  const r = await fetchReal(`${loja.base}/checkout`);
  const csp = r.headers.get('content-security-policy');
  assert.match(csp, /script-src 'self' https:\/\/www\.pre\.globalgetnet\.com;/);
  assert.doesNotMatch(csp, /unsafe-eval|script-src[^;]*unsafe-inline/);
  process.env.GETNET_GLOBAL_AMBIENTE = 'producao';
  try { assert.equal(globalApi.configurado(), false); assert.throws(() => globalApi.configuracao(), /homologação/); }
  finally { process.env.GETNET_GLOBAL_AMBIENTE = 'homologacao'; }
});

test('função de conciliação não é executável pelos papéis públicos', async () => {
  const { rows } = await loja.pg.query("select has_function_privilege('anon', 'processar_pagamento_global(text,text,numeric)', 'EXECUTE') as anon, has_function_privilege('authenticated', 'processar_pagamento_global(text,text,numeric)', 'EXECUTE') as authenticated");
  assert.deepEqual(rows[0], { anon: false, authenticated: false });
});

test('configuração remota usa PATCH oficial de homologação e preserva opções comerciais', async () => {
  await assert.rejects(() => globalApi.configurarNotificacao('http://loja.exemplo.com'), /HTTPS/);
  await globalApi.configurarNotificacao('https://loja.exemplo.com');
  const r = await globalApi.verificarConfiguracao();
  assert.equal(r.comercial.instant_payment.enable, true);
  assert.equal(r.tecnica.notification.authentication_type, 'user_credentials');
});

test('expiração cancela primeiro a intenção remota e não expira após falha de consulta', async () => {
  const p = await novoPedido();
  await loja.pg.exec("update pedidos set expira_em = now() + interval '1 day' where status = 'aguardando'");
  await loja.pg.query("update pedidos set expira_em = now() - interval '1 minute' where id = $1", [p.id]);
  const pedidos = require('../server/pedidos');
  falharConsulta = true;
  try {
    assert.equal(await pedidos.expirarVencidos(), 0);
    assert.equal((await lerPedido(p.id)).status, 'aguardando');
  } finally { falharConsulta = false; }
  assert.equal(await pedidos.expirarVencidos(), 1);
  assert.equal(intents.get(p.pagamentoId).status, 'cancelled');
  assert.equal((await lerPedido(p.id)).status, 'cancelado');
});
