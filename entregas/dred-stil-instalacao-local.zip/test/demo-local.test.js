// Exercita o processo da demonstração com integrações herdadas do terminal.
// Tudo é copiado para uma pasta temporária; nenhuma chave ou serviço real é usado.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const net = require('node:net');
const { spawn } = require('node:child_process');
const { once } = require('node:events');

const RAIZ = path.join(__dirname, '..');

async function portaLivre() {
  const servidor = net.createServer();
  await new Promise((resolve, reject) => {
    servidor.once('error', reject);
    servidor.listen(0, '127.0.0.1', resolve);
  });
  const porta = servidor.address().port;
  await new Promise((resolve, reject) => servidor.close((erro) => erro ? reject(erro) : resolve()));
  return porta;
}

test('demo ignora credenciais herdadas e .env.local, usando banco e frete simulados sem sair à rede', { timeout: 20_000 }, async (t) => {
  const diretorio = await fs.mkdtemp(path.join(os.tmpdir(), 'dredstil-demo-isolada-'));
  let filho;
  t.after(async () => {
    if (filho && filho.exitCode === null && filho.signalCode === null) {
      const saiu = once(filho, 'exit');
      filho.kill();
      const timer = setTimeout(() => filho.kill('SIGKILL'), 1000);
      timer.unref();
      try { await saiu; } finally { clearTimeout(timer); }
    }
    await fs.rm(diretorio, { recursive: true, force: true });
  });
  await fs.mkdir(path.join(diretorio, 'scripts'));
  await fs.mkdir(path.join(diretorio, 'test'));
  await Promise.all([
    fs.copyFile(path.join(RAIZ, 'scripts', 'demo-local.js'), path.join(diretorio, 'scripts', 'demo-local.js')),
    ...['banco-teste.js', 'supabase-falso.js'].map((nome) => fs.copyFile(path.join(RAIZ, 'test', nome), path.join(diretorio, 'test', nome))),
    ...['server', 'views', 'supabase'].map((nome) => fs.cp(path.join(RAIZ, nome), path.join(diretorio, nome), { recursive: true })),
    fs.symlink(path.join(RAIZ, 'node_modules'), path.join(diretorio, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir'),
  ]);
  const marcador = 'fixture-credencial-herdada-nao-utilizar';
  await fs.writeFile(path.join(diretorio, '.env.local'), `SUPABASE_URL=https://fixture-producao.supabase.co\nRESEND_API_KEY=${marcador}\nPAGAMENTO_PROVEDOR=getnet-global\n`);

  // O bloqueio existe apenas neste subprocesso de teste. Qualquer saída de rede
  // deixa uma marca sem URL, tokens ou dados da requisição e faz o teste falhar.
  const guarda = path.join(diretorio, 'guarda-rede-teste.cjs');
  await fs.writeFile(guarda, `
    const fs = require('node:fs');
    const path = require('node:path');
    function bloquear() {
      fs.writeFileSync(path.join(__dirname, 'tentativa-rede.txt'), 'Uma conexão de saída foi bloqueada.');
      throw new Error('Saída de rede bloqueada pelo teste da demonstração.');
    }
    global.fetch = async () => bloquear();
    for (const nome of ['node:http', 'node:https']) {
      const modulo = require(nome);
      modulo.request = bloquear;
      modulo.get = bloquear;
    }
    const net = require('node:net');
    net.connect = bloquear;
    net.createConnection = bloquear;
    net.Socket.prototype.connect = bloquear;
    const http = require('node:http');
    const criarServidor = http.createServer;
    http.createServer = function (...args) {
      const ambiente = require(path.join(__dirname, 'server', 'ambiente'));
      fs.writeFileSync(path.join(__dirname, 'estado-demo.json'), JSON.stringify({
        pagamento: ambiente.provedorPagamento(), frete: ambiente.provedorFrete(), nfe: ambiente.provedorNfe(),
        emailReal: Boolean(process.env.RESEND_API_KEY), producao: ambiente.EM_PRODUCAO,
        marcadorHerdadoPresente: Object.values(process.env).some((v) => v.includes('${marcador}')),
        bancoDemo: process.env.SUPABASE_URL === 'https://demo.supabase.co',
      }));
      return criarServidor.apply(this, args);
    };
  `);

  const porta = await portaLivre();
  const herdado = {
    NODE_ENV: 'production', VERCEL: '1', PAGAMENTO_PROVEDOR: 'getnet-global',
    SUPABASE_URL: 'https://fixture-producao.supabase.co', SUPABASE_SERVICE_ROLE_KEY: marcador,
    MELHOR_ENVIO_AMBIENTE: 'producao', MELHOR_ENVIO_CLIENT_ID: marcador, MELHOR_ENVIO_CLIENT_SECRET: marcador,
    MELHOR_ENVIO_TOKEN: marcador, MELHOR_ENVIO_CEP_ORIGEM: '83331000',
    GETNET_CLIENT_ID: marcador, GETNET_CLIENT_SECRET: marcador, GETNET_SELLER_ID: marcador,
    GETNET_GLOBAL_CLIENT_ID: marcador, GETNET_GLOBAL_CLIENT_SECRET: marcador, GETNET_GLOBAL_SELLER_ID: marcador,
    GETNET_GLOBAL_AMBIENTE: 'producao', GETNET_GLOBAL_PRODUCAO_LIBERADA: 'sim',
    FOCUS_NFE_TOKEN: marcador, NFE_CNPJ_EMITENTE: '12345678000199', NFE_UF_EMITENTE: 'PR',
    RESEND_API_KEY: marcador, EMAIL_FROM: 'Fixture <fixture@sem-envio.invalid>',
  };
  filho = spawn(process.execPath, ['--require', guarda, path.join(diretorio, 'scripts', 'demo-local.js')], {
    cwd: diretorio, env: { ...process.env, ...herdado, PORT: String(porta) }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  let saida = '';
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('A demonstração isolada não iniciou no prazo.')), 17_000);
    const receber = (dados) => {
      saida += dados.toString();
      if (saida.includes(`http://localhost:${porta}`)) { clearTimeout(timer); resolve(); }
    };
    filho.stdout.on('data', receber);
    filho.stderr.on('data', receber);
    filho.once('error', (erro) => { clearTimeout(timer); reject(erro); });
    filho.once('exit', (codigo) => {
      clearTimeout(timer);
      reject(new Error(`A demonstração isolada encerrou antes de iniciar (código ${codigo}). ${saida}`));
    });
  });

  const base = `http://127.0.0.1:${porta}`;
  const loja = await fetch(`${base}/api/loja`, { signal: AbortSignal.timeout(3000) });
  assert.equal(loja.status, 200);
  const dadosLoja = await loja.json();
  assert.equal(dadosLoja.config.checkout, true);
  assert.ok(dadosLoja.produtos.some((p) => p.handle === 'camiseta-oversized-dred-stil'));
  const frete = await fetch(`${base}/api/frete`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Origin: base }, signal: AbortSignal.timeout(3000),
    body: JSON.stringify({ cep: '83331000', itens: [{ handle: 'camiseta-oversized-dred-stil', cor: 'Preto', tamanho: 'M', qtd: 1 }] }),
  });
  assert.equal(frete.status, 200);
  const cotacao = await frete.json();
  assert.equal(cotacao.opcoes.length, 2);
  assert.ok(cotacao.opcoes.every((o) => o.nome.includes('(simulado)') && o.preco > 0 && o.prazoDias > 0));

  const estado = JSON.parse(await fs.readFile(path.join(diretorio, 'estado-demo.json'), 'utf8'));
  assert.deepEqual(estado, {
    pagamento: 'simulado', frete: 'simulado', nfe: 'simulado', emailReal: false,
    producao: false, marcadorHerdadoPresente: false, bancoDemo: true,
  });
  await assert.rejects(fs.stat(path.join(diretorio, 'tentativa-rede.txt')), { code: 'ENOENT' });
  assert.equal(saida.includes(marcador), false);
  assert.ok((await fs.stat(path.join(diretorio, '.dev-emails', 'admin-demo.txt'))).isFile());
});
