// Emulador mínimo do cliente @supabase/supabase-js sobre PGlite, só para testes.
// Cobre o subconjunto usado em server/db.js: from().select/insert/update/delete/upsert com
// eq/in/lt/gt/is/not/or/order/range/limit/single/maybeSingle, contagem, rpc() e storage.
// Assim os testes exercitam o db.js real e as funções SQL reais da migração.

// Relacionamentos usados nos selects aninhados de db.js.
const RELACOES = {
  'usuarios.curtidas': (cols) =>
    `(select coalesce(json_agg(json_build_object(${cols.map((c) => `'${c}', r.${c}`).join(', ')})), '[]'::json) from curtidas r where r.usuario_id = t.id) as curtidas`,
  'pedidos.usuarios': (cols) =>
    `(select row_to_json(x) from (select ${cols.join(', ')} from usuarios r where r.id = t.usuario_id) x) as usuarios`,
};

const ident = (n) => {
  if (!/^[a-z_][a-z0-9_]*$/i.test(n)) throw new Error(`identificador inválido no teste: ${n}`);
  return `"${n}"`;
};

function normalizar(valor) {
  if (valor instanceof Date) return valor.toISOString();
  if (typeof valor === 'bigint') return Number(valor);
  if (Array.isArray(valor)) return valor.map(normalizar);
  if (valor && typeof valor === 'object') return Object.fromEntries(Object.entries(valor).map(([k, v]) => [k, normalizar(v)]));
  return valor;
}

const param = (v) => (v !== null && typeof v === 'object' && !(v instanceof Date) ? JSON.stringify(v) : v);

class Consulta {
  constructor(pg, tabela) {
    Object.assign(this, { pg, tabela, op: 'select', colunas: '*', filtros: [], ordem: [], retorno: null });
  }
  select(colunas = '*', opcoes = {}) {
    if (this.op === 'select') this.colunas = colunas;
    else this.retorno = colunas;
    if (opcoes.count) this.contar = true;
    if (opcoes.head) this.cabeca = true;
    return this;
  }
  insert(linhas) { return Object.assign(this, { op: 'insert', linhas: [].concat(linhas) }); }
  upsert(linhas) { return Object.assign(this, { op: 'upsert', linhas: [].concat(linhas) }); }
  update(valores) { return Object.assign(this, { op: 'update', valores }); }
  delete() { return Object.assign(this, { op: 'delete' }); }
  eq(c, v) { this.filtros.push((p) => `t.${ident(c)} = ${p(v)}`); return this; }
  lt(c, v) { this.filtros.push((p) => `t.${ident(c)} < ${p(v)}`); return this; }
  gt(c, v) { this.filtros.push((p) => `t.${ident(c)} > ${p(v)}`); return this; }
  in(c, vs) { this.filtros.push((p) => (vs.length ? `t.${ident(c)} in (${vs.map((v) => p(v)).join(', ')})` : 'false')); return this; }
  ilike(c, v) { this.filtros.push((p) => `t.${ident(c)} ilike ${p(v)}`); return this; }
  is(c, v) { this.filtros.push(() => `t.${ident(c)} is ${v === null ? 'null' : v ? 'true' : 'false'}`); return this; }
  not(c, op, v) {
    if (op !== 'is' || v !== null) throw new Error('not() não suportado no teste');
    this.filtros.push(() => `t.${ident(c)} is not null`);
    return this;
  }
  or(expr) {
    // 'nome.ilike.%x%,email.ilike.%x%'
    this.filtros.push((p) => '(' + expr.split(',').map((parte) => {
      const [c, op, ...resto] = parte.split('.');
      if (op !== 'ilike') throw new Error('or() só com ilike no teste');
      return `t.${ident(c)} ilike ${p(resto.join('.'))}`;
    }).join(' or ') + ')');
    return this;
  }
  order(c, { ascending = true } = {}) { this.ordem.push(`t.${ident(c)} ${ascending ? 'asc' : 'desc'}`); return this; }
  range(de, ate) { Object.assign(this, { offset: de, lim: ate - de + 1 }); return this; }
  limit(n) { this.lim = n; return this; }
  single() { this.umaLinha = 'single'; return this; }
  maybeSingle() { this.umaLinha = 'maybe'; return this; }

  colunasSql(texto) {
    if (!texto || texto === '*') return 't.*';
    const partes = [];
    for (const m of texto.matchAll(/(\w+)\(([^)]*)\)|([\w*]+)/g)) {
      if (m[1]) {
        const rel = RELACOES[`${this.tabela}.${m[1]}`];
        if (!rel) throw new Error(`relação não suportada no teste: ${this.tabela}.${m[1]}`);
        partes.push(rel(m[2].split(',').map((s) => s.trim())));
      } else partes.push(m[3] === '*' ? 't.*' : `t.${ident(m[3])}`);
    }
    return partes.join(', ');
  }
  where(p) {
    const f = this.filtros.map((fn) => fn(p));
    return f.length ? ` where ${f.join(' and ')}` : '';
  }
  async executar() {
    const T = `${ident(this.tabela)} t`;
    const params = [];
    const p = (v) => { params.push(param(v)); return '$' + params.length; };
    let sql;
    if (this.op === 'select') {
      sql = `select ${this.colunasSql(this.colunas)} from ${T}${this.where(p)}` +
        (this.ordem.length ? ` order by ${this.ordem.join(', ')}` : '') +
        (this.lim != null ? ` limit ${Number(this.lim)}` : '') + (this.offset ? ` offset ${Number(this.offset)}` : '');
    } else if (this.op === 'insert' || this.op === 'upsert') {
      const cols = [...new Set(this.linhas.flatMap(Object.keys))];
      const valores = this.linhas.map((l) => `(${cols.map((c) => (l[c] === undefined ? 'default' : p(l[c]))).join(', ')})`).join(', ');
      const pk = this.tabela === 'conteudo' ? 'chave' : null;
      const conflito = this.op === 'upsert' && pk
        ? ` on conflict (${pk}) do update set ${cols.filter((c) => c !== pk).map((c) => `${ident(c)} = excluded.${ident(c)}`).join(', ')}`
        : '';
      sql = `insert into ${ident(this.tabela)} as t (${cols.map(ident).join(', ')}) values ${valores}${conflito}`;
    } else if (this.op === 'update') {
      const sets = Object.entries(this.valores).map(([c, v]) => `${ident(c)} = ${p(v)}`).join(', ');
      sql = `update ${T} set ${sets}${this.where(p)}`;
    } else {
      sql = `delete from ${T}${this.where(p)}`;
    }
    if (this.op !== 'select') sql += this.retorno ? ` returning ${this.colunasSql(this.retorno)}` : '';
    try {
      const r = await this.pg.query(sql, params);
      let data = normalizar(r.rows);
      let count = null;
      if (this.contar) {
        const ps = [];
        const where = this.where((v) => { ps.push(param(v)); return '$' + ps.length; });
        const c = await this.pg.query(`select count(*)::int as n from ${T}${where}`, ps);
        count = c.rows[0].n;
      }
      if (this.op !== 'select' && !this.retorno) data = null;
      if (this.umaLinha) {
        if (data.length > 1 || (this.umaLinha === 'single' && data.length === 0)) {
          return { data: null, error: { code: 'PGRST116', message: 'linhas encontradas diferente de 1' } };
        }
        data = data[0] ?? null;
      }
      if (this.cabeca) data = null;
      return { data, error: null, count };
    } catch (e) {
      return { data: null, error: { code: e.code, message: e.message }, count: null };
    }
  }
  then(ok, falha) { return this.executar().then(ok, falha); }
}

function criarClienteFalso(pg) {
  return {
    from: (tabela) => new Consulta(pg, tabela),
    async rpc(nome, args = {}) {
      const nomes = Object.keys(args);
      const sql = `select * from ${ident(nome)}(${nomes.map((n, i) => `${ident(n)} => $${i + 1}`).join(', ')})`;
      try {
        const r = await pg.query(sql, nomes.map((n) => param(args[n])));
        const campos = r.fields.map((f) => f.name);
        const escalar = campos.length === 1 && campos[0] === nome;
        return { data: escalar ? normalizar(r.rows[0]?.[nome] ?? null) : normalizar(r.rows), error: null };
      } catch (e) {
        return { data: null, error: { code: e.code, message: e.message } };
      }
    },
    storage: {
      from: () => ({
        upload: async () => ({ data: {}, error: null }),
        getPublicUrl: (nome) => ({ data: { publicUrl: `https://teste.supabase.co/storage/v1/object/public/produtos/${nome}` } }),
      }),
    },
  };
}

module.exports = { criarClienteFalso };
