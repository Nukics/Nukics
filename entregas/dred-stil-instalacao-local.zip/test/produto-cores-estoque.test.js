// Uma edição do produto não pode soltar seu estoque por cor silenciosamente.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, contaConfirmada } = require('./ajuda');

let loja;
let admin;
let sequencia = 0;
const foto = '/img/produtos/preto-frente.webp';
const cor = (nome) => ({ nome, hex: '#000000', imagens: [foto] });
const mudar = (produto, campos) => loja.chamar('PUT', `/api/admin/produtos/${produto.handle}`, { cookie: admin, corpo: { ...produto, ...campos } });

before(async () => {
  loja = await iniciarLoja();
  const cookie = await contaConfirmada(loja, 'dono.edicao.cores@exemplo.com');
  await loja.pg.query("update usuarios set papel='admin' where email='dono.edicao.cores@exemplo.com'");
  const r = await loja.chamar('POST', '/api/conta/dois-fatores', { cookie, corpo: { ativar: true, senha: 'Senha-Forte-123' } });
  assert.equal(r.status, 200);
  admin = r.cookie;
});
after(() => loja.fechar());

async function preparar() {
  const handle = `produto-cores-${++sequencia}`;
  const produto = {
    handle, nome: `Camisa cores ${sequencia}`, categoria: 'camisetas', preco: 100, precoDe: 0,
    descricao: 'Produto para conferir o estoque por cor.', tamanhos: ['M', 'G'], cores: [cor('Preto'), cor('Branco')],
    ativo: true, pesoKg: 0.3, larguraCm: 20, alturaCm: 4, comprimentoCm: 28, codigoNcm: '61091000',
  };
  const criado = await loja.chamar('POST', '/api/admin/produtos', { cookie: admin, corpo: produto });
  assert.equal(criado.status, 200, JSON.stringify(criado.json));
  const estoque = await loja.chamar('POST', '/api/admin/estoques', { cookie: admin, corpo: {
    nome: `Camisas cores ${sequencia}`, cor: 'Preto', quantidade: 3, produtos: [handle],
  } });
  assert.equal(estoque.status, 200, JSON.stringify(estoque.json));
  return { produto, estoque: estoque.json.estoque };
}

const linhaProduto = async (handle) => (await loja.pg.query('select * from produtos where handle=$1', [handle])).rows[0];
const vinculos = async (handle) => (await loja.pg.query('select cor, estoque_id from estoque_produtos_cores where handle=$1', [handle])).rows;

test('renomear cor vinculada é recusado antes de salvar preço ou outros campos', async () => {
  const { produto, estoque } = await preparar();
  const antes = await linhaProduto(produto.handle);
  const r = await mudar(produto, { preco: 120, cores: [cor('Azul'), cor('Branco')] });
  assert.equal(r.status, 409, JSON.stringify(r.json));
  assert.match(r.json.erro, /desvincul.*estoque/i);
  assert.deepEqual(await linhaProduto(produto.handle), antes);
  assert.deepEqual(await vinculos(produto.handle), [{ cor: 'preto', estoque_id: estoque.id }]);
});

test('remover cor vinculada é recusado e preserva seu saldo', async () => {
  const { produto, estoque } = await preparar();
  const r = await mudar(produto, { cores: [cor('Branco')] });
  assert.equal(r.status, 409, JSON.stringify(r.json));
  assert.deepEqual((await linhaProduto(produto.handle)).cores, produto.cores);
  assert.equal((await loja.pg.query('select quantidade from estoques where id=$1', [estoque.id])).rows[0].quantidade, 3);
});

test('alterar maiúsculas e espaços da mesma cor mantém limite de estoque', async () => {
  const { produto, estoque } = await preparar();
  const r = await mudar(produto, { cores: [cor('  PRETO  '), cor('Branco')] });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.deepEqual(await vinculos(produto.handle), [{ cor: 'preto', estoque_id: estoque.id }]);
  const excesso = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: [{ handle: produto.handle, cor: 'PRETO', tamanho: 'M', qtd: 4 }] } });
  assert.equal(excesso.status, 409, JSON.stringify(excesso.json));
  assert.match(excesso.json.erro, /restam 3/);
});

test('editar fotos, preço ou cor sem vínculo preserva o estoque existente', async () => {
  const { produto, estoque } = await preparar();
  const r = await mudar(produto, { preco: 119.90, cores: [{ ...cor('Preto'), imagens: ['/img/produtos/preto-costas.webp'] }, cor('Azul')] });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.deepEqual(await vinculos(produto.handle), [{ cor: 'preto', estoque_id: estoque.id }]);
  assert.equal(Number((await linhaProduto(produto.handle)).preco), 119.90);
});

test('alterar endereço do produto preserva vínculos por cor e conferência de quantidade', async () => {
  const { produto, estoque } = await preparar();
  const novo = `${produto.handle}-novo`;
  const r = await mudar(produto, { handle: novo });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.deepEqual(await vinculos(produto.handle), []);
  assert.deepEqual(await vinculos(novo), [{ cor: 'preto', estoque_id: estoque.id }]);
  const excesso = await loja.chamar('POST', '/api/pedidos', { corpo: { itens: [{ handle: novo, cor: 'Preto', tamanho: 'M', qtd: 4 }] } });
  assert.equal(excesso.status, 409);
});

test('após desvincular explicitamente no estoque, a cor pode ser renomeada', async () => {
  const { produto, estoque } = await preparar();
  const soltar = await loja.chamar('PUT', `/api/admin/estoques/${estoque.id}`, { cookie: admin, corpo: {
    nome: estoque.nome, cor: estoque.cor, quantidade: estoque.quantidade, produtos: [],
  } });
  assert.equal(soltar.status, 200, JSON.stringify(soltar.json));
  assert.deepEqual(await vinculos(produto.handle), []);
  const r = await mudar(produto, { cores: [cor('Azul'), cor('Branco')] });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.deepEqual((await linhaProduto(produto.handle)).cores.map((c) => c.nome), ['Azul', 'Branco']);
  assert.equal((await loja.pg.query('select quantidade from estoques where id=$1', [estoque.id])).rows[0].quantidade, 3);
});
