const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { gerarInstalacao, semTransacaoExterna } = require('../scripts/gerar-instalacao-sql');

const SQL = fs.readFileSync(path.join(__dirname, '..', 'supabase', 'instalar-loja-nova.sql'), 'utf8');

async function bancoNovo() {
  const { PGlite } = await import('@electric-sql/pglite');
  const pg = new PGlite();
  // No Supabase, a chave secreta do servidor usa service_role com BYPASSRLS.
  await pg.exec(`
    create role anon; create role authenticated; create role service_role bypassrls;
    create schema storage;
    create table storage.buckets (id text primary key, name text, public boolean, file_size_limit int, allowed_mime_types text[]);
  `);
  return pg;
}

test('SQL único acompanha as fontes e preserva os blocos das funções', () => {
  assert.equal(SQL, gerarInstalacao());
  assert.equal(SQL.match(/^begin;$/gm)?.length, 1);
  assert.equal(SQL.match(/^commit;$/gm)?.length, 1);
  assert.match(SQL, /Fonte: supabase\/migracoes\/005-estoque-por-cor\.sql/);
  assert.match(SQL, /Fonte: supabase\/migracoes\/006-categorias-mover\.sql/);
  assert.match(SQL, /notify pgrst, 'reload schema'/);
  const fonte = '-- migração\nbegin;\ncreate function f() returns void language plpgsql as $$\nbegin\n  perform 1;\nend;\n$$;\ncommit;\n';
  assert.equal(semTransacaoExterna(fonte), '-- migração\ncreate function f() returns void language plpgsql as $$\nbegin\n  perform 1;\nend;\n$$;');
});

test('instalação nova cria estrutura completa, dados e permissões de servidor sem expor chaves públicas', async () => {
  const pg = await bancoNovo();
  try {
    await pg.exec(SQL);
    const quantidade = async (tabela) => (await pg.query(`select count(*)::int as n from ${tabela}`)).rows[0].n;
    assert.equal(await quantidade('produtos'), 1);
    assert.equal(await quantidade('categorias'), 1);
    assert.ok(await quantidade('conteudo') >= 5);
    assert.equal(await quantidade('usuarios'), 0, 'a instalação não inventa conta admin');
    assert.equal(await quantidade('estoques'), 0, 'a instalação não inventa contagens de peças');
    assert.equal((await pg.query("select count(*)::int n from storage.buckets where id = 'produtos'")).rows[0].n, 1);
    assert.equal((await pg.query("select count(*)::int n from information_schema.columns where table_schema='public' and table_name='estoques' and column_name in ('cor','arquivado')")).rows[0].n, 2);
    assert.equal((await pg.query("select count(*)::int n from pg_trigger where tgname = 'categorias_validar_arvore'")).rows[0].n, 1);

    for (const tabela of ['categorias', 'produtos', 'usuarios', 'curtidas', 'pedidos', 'conteudo', 'estoques', 'estoque_produtos_cores']) {
      assert.equal((await pg.query('select relrowsecurity as rls from pg_class where oid = $1::regclass', [tabela])).rows[0].rls, true);
      for (const papel of ['anon', 'authenticated']) {
        for (const operacao of ['SELECT', 'INSERT', 'UPDATE', 'DELETE']) {
          assert.equal((await pg.query('select has_table_privilege($1, $2, $3) as permitido', [papel, tabela, operacao])).rows[0].permitido, false, `${papel} sem ${operacao} em ${tabela}`);
        }
      }
      for (const operacao of ['SELECT', 'INSERT', 'UPDATE', 'DELETE']) {
        assert.equal((await pg.query("select has_table_privilege('service_role', $1, $2) as permitido", [tabela, operacao])).rows[0].permitido, true, `service_role com ${operacao} em ${tabela}`);
      }
    }
    assert.equal((await pg.query("select has_sequence_privilege('service_role', 'pedidos_numero_seq', 'USAGE') as permitido")).rows[0].permitido, true);
    await pg.exec('set role service_role');
    assert.equal(await quantidade('produtos'), 1, 'service_role lê os produtos reais do banco de teste com RLS ligado');
    for (const view of ['curtidas_por_produto', 'compras_por_usuario', 'vendas_resumo', 'vendas_por_dia']) await pg.query(`select * from ${view}`);
    const pedido = await pg.query("insert into pedidos (itens, total) values ('[]', 0) returning numero");
    assert.equal(Number(pedido.rows[0].numero), 1);
    await pg.exec('reset role');
    for (const papel of ['anon', 'authenticated']) {
      await pg.exec(`set role ${papel}`);
      await assert.rejects(pg.query('select * from produtos'), /permission denied/);
      await assert.rejects(pg.query('select * from vendas_resumo'), /permission denied/);
      await pg.exec('reset role');
    }

    await pg.query("update produtos set nome = 'Produto preservado'");
    await assert.rejects(pg.exec(SQL), /Instalação recusada/);
    await pg.exec('rollback');
    assert.equal((await pg.query('select nome from produtos')).rows[0].nome, 'Produto preservado');
    assert.equal(await quantidade('pedidos'), 1, 'uma segunda execução não apaga os pedidos');
  } finally {
    await pg.close();
  }
});

test('instalação recusa esquema existente mesmo com tabela vazia', async () => {
  const pg = await bancoNovo();
  try {
    await pg.exec('create table public.usuarios (id integer primary key)');
    await assert.rejects(pg.exec(SQL), /Instalação recusada/);
    await pg.exec('rollback');
    assert.equal((await pg.query("select to_regclass('public.produtos') as tabela")).rows[0].tabela, null);
    assert.equal((await pg.query('select count(*)::int n from public.usuarios')).rows[0].n, 0);
  } finally {
    await pg.close();
  }
});

test('erro durante a instalação permite desfazer toda a estrutura e os dados na mesma transação', async () => {
  const pg = await bancoNovo();
  try {
    const quebrado = SQL.replace("notify pgrst, 'reload schema';", 'select * from tabela_que_nao_existe;');
    await assert.rejects(pg.exec(quebrado), /tabela_que_nao_existe/);
    await pg.exec('rollback');
    assert.equal((await pg.query("select to_regclass('public.categorias') as tabela")).rows[0].tabela, null);
    assert.equal((await pg.query('select count(*)::int n from storage.buckets')).rows[0].n, 0);
  } finally {
    await pg.close();
  }
});
