// Páginas prontas no servidor (SEO e velocidade), cache público só onde é seguro e dados estruturados.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, contaConfirmada } = require('./ajuda');

let loja;
before(async () => (loja = await iniciarLoja()));
after(() => loja.fechar());

const pagina = async (caminho, cookie) => {
  const r = await fetch(loja.base + caminho, { headers: cookie ? { cookie } : {}, redirect: 'manual' });
  return { status: r.status, html: await r.text(), cache: r.headers.get('cache-control'), cookie: r.headers.get('set-cookie') };
};

test('página inicial já vem com os produtos no HTML e os dados embutidos', async () => {
  const { html, cache } = await pagina('/');
  assert.match(html, /<article class="cartao" data-handle="camiseta-teste">/);
  assert.match(html, /<script type="application\/json" id="dados-loja">/);
  assert.match(html, /"@type":"ClothingStore"/);
  assert.match(cache, /s-maxage=60/, 'CDN guarda a página pública');
});

test('página de produto: conteúdo, canonical, Open Graph e dados de produto para o Google', async () => {
  const { html, cache } = await pagina('/produto/camiseta-teste?cor=Preto');
  assert.match(html, /<h1 class="produto__nome">Camiseta Teste<\/h1>/);
  assert.match(html, /<link rel="canonical" href="http:\/\/loja\.teste\/produto\/camiseta-teste">/, 'canonical sem ?cor');
  assert.match(html, /<meta property="og:type" content="product">/);
  const ld = JSON.parse(html.match(/<script type="application\/ld\+json">(.*?)<\/script>/)[1]);
  assert.equal(ld['@type'], 'Product');
  assert.equal(ld.offers.price, '150.00');
  assert.equal(ld.offers.availability, 'https://schema.org/InStock');
  assert.match(cache, /s-maxage=60/);
});

test('catálogo vem pronto (lista e total) e produto sob consulta não ganha preço no Google', async () => {
  const { html } = await pagina('/catalogo');
  assert.match(html, /data-total>2 produtos</);
  const consulta = await pagina('/produto/sob-consulta');
  const ld = JSON.parse(consulta.html.match(/<script type="application\/ld\+json">(.*?)<\/script>/)[1]);
  assert.equal(ld.offers, undefined);
});

test('HTML público é igual para todos: nada de quem está logado (nem link Admin) e sem cookie', async () => {
  const cookie = await contaConfirmada(loja, 'seo@exemplo.com');
  await loja.pg.query(`update usuarios set papel = 'admin' where email = 'seo@exemplo.com'`);
  const anonimo = await pagina('/');
  const logado = await pagina('/', cookie);
  assert.equal(logado.html.replace(/data-versao="[^"]*"/, ''), anonimo.html.replace(/data-versao="[^"]*"/, ''));
  assert.doesNotMatch(logado.html, /href="\/admin"/);
  assert.doesNotMatch(logado.html, /seo@exemplo\.com/);
  assert.equal(logado.cookie, null);
  await loja.pg.query(`update usuarios set papel = 'cliente' where email = 'seo@exemplo.com'`);
});

test('páginas da conta, checkout e admin nunca vão para o cache e não são indexadas', async () => {
  for (const caminho of ['/conta', '/checkout', '/favoritos']) {
    const r = await pagina(caminho);
    assert.equal(r.cache, 'no-store', caminho);
    assert.match(r.html, /<meta name="robots" content="noindex, nofollow">/, caminho);
  }
  const notFound = await pagina('/nao-existe');
  assert.equal(notFound.status, 404);
  assert.equal(notFound.cache, 'no-store');
});

test('texto de produto com </script> não quebra os dados embutidos (XSS)', async () => {
  await loja.pg.query(`update produtos set descricao = '</script><script>alert(1)</script>' where handle = 'camiseta-teste'`);
  require('../server/publico').limpar();
  const { html } = await pagina('/');
  const embutido = html.match(/<script type="application\/json" id="dados-loja">([\s\S]*?)<\/script>/)[1];
  assert.doesNotMatch(embutido, /<\/script/i);
  assert.equal(JSON.parse(embutido).produtos.find((p) => p.handle === 'camiseta-teste').descricao, '</script><script>alert(1)</script>');
  assert.doesNotMatch(html, /<script>alert\(1\)<\/script>/, 'nem na descrição visível nem no JSON-LD');
  await loja.pg.query(`update produtos set descricao = '' where handle = 'camiseta-teste'`);
  require('../server/publico').limpar();
});

test('sitemap lista as páginas e os produtos; /api/loja fica na CDN', async () => {
  const r = await fetch(loja.base + '/sitemap.xml');
  const xml = await r.text();
  assert.match(xml, /<loc>http:\/\/loja\.teste\/produto\/camiseta-teste<\/loc>/);
  assert.match(xml, /<loc>http:\/\/loja\.teste\/catalogo<\/loc>/);
  const api = await fetch(loja.base + '/api/loja');
  assert.match(api.headers.get('cache-control'), /s-maxage=60/);
  const eu = await fetch(loja.base + '/api/eu');
  assert.equal(eu.headers.get('cache-control'), 'no-store', 'dados de sessão nunca em cache');
});

test('alteração no admin aparece na vitrine sem esperar o cache', async () => {
  const antes = (await (await fetch(loja.base + '/api/loja')).json()).produtos.length;
  await loja.pg.query(`update produtos set ativo = false where handle = 'sob-consulta'`);
  require('../server/publico').limpar(); // o mesmo que acontece após qualquer alteração pelo admin
  const depois = (await (await fetch(loja.base + '/api/loja')).json()).produtos.length;
  assert.equal(depois, antes - 1);
  await loja.pg.query(`update produtos set ativo = true where handle = 'sob-consulta'`);
  require('../server/publico').limpar();
});
