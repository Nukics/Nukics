// Mudança de hierarquia pela API real, com autenticação de admin e banco Postgres em memória.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { iniciarLoja, contaConfirmada, ultimoEmail, codigoDoEmail } = require('./ajuda');

let loja;
let admin;
let acessoSemDuasEtapas;
let cliente;
before(async () => {
  loja = await iniciarLoja();
  cliente = await contaConfirmada(loja, 'categorias-cliente@exemplo.com');
  const semDuasEtapas = await contaConfirmada(loja, 'categorias-admin@exemplo.com');
  await loja.pg.query(`update usuarios set papel = 'admin' where email = 'categorias-admin@exemplo.com'`);
  acessoSemDuasEtapas = await loja.chamar('PATCH', '/api/admin/categorias/camisetas', {
    cookie: semDuasEtapas, corpo: { pai: 'roupas' },
  });
  const ativar = await loja.chamar('POST', '/api/conta/dois-fatores', {
    cookie: semDuasEtapas, corpo: { ativar: true, senha: 'Senha-Forte-123' },
  });
  assert.equal(ativar.status, 200);
  const entrar = await loja.chamar('POST', '/api/conta/entrar', {
    corpo: { email: 'categorias-admin@exemplo.com', senha: 'Senha-Forte-123' },
  });
  const confirmar = await loja.chamar('POST', '/api/conta/codigo', {
    corpo: { desafio: entrar.json.desafio, codigo: codigoDoEmail(ultimoEmail('categorias-admin@exemplo.com')) },
  });
  assert.equal(confirmar.status, 200);
  admin = confirmar.cookie;
  await loja.pg.exec(`
    insert into categorias (slug, nome, ordem) values
      ('roupas', 'Roupas', 6), ('acessorios', 'Acessórios', 1), ('com-filhas', 'Com filhas', 2);
    insert into categorias (slug, nome, pai, ordem, no_menu) values
      ('roupas-casacos', 'Casacos', 'roupas', 8, true),
      ('filha-conservada', 'Filha conservada', 'com-filhas', 0, false);
    insert into produtos (handle, nome, categoria, preco, tamanhos, cores) values
      ('produto-filha', 'Produto da filha', 'filha-conservada', 50, '["M"]',
       '[{"nome":"Preto","hex":"#000000","imagens":["/img/produtos/preto.webp"]}]');
    insert into conteudo (chave, valor) values
      ('menu', '[{"id":"catalogo","tipo":"catalogo","rotulo":"Catálogo","visivel":true}]');
  `);
  require('../server/publico').limpar();
});
after(() => loja.fechar());

const mover = (slug, pai, extra = {}) => loja.chamar('PATCH', `/api/admin/categorias/${slug}`, {
  cookie: admin, corpo: { pai, ...extra },
});
const registro = async (slug) => (await loja.pg.query('select * from categorias where slug = $1', [slug])).rows[0];

test('mover categoria exige sessão de admin com verificação em duas etapas', async () => {
  const caminho = '/api/admin/categorias/camisetas';
  assert.equal((await loja.chamar('PATCH', caminho, { corpo: { pai: 'roupas' } })).status, 401);
  assert.equal((await loja.chamar('PATCH', caminho, { cookie: cliente, corpo: { pai: 'roupas' } })).status, 403);
  assert.equal(acessoSemDuasEtapas.status, 403);
  assert.match(acessoSemDuasEtapas.json.erro, /duas etapas/);
  assert.equal((await registro('camisetas')).pai, null);
});

test('categoria existente vira subcategoria e preserva endereço, produtos e opção do menu', async () => {
  const antes = await registro('camisetas');
  const produtosAntes = (await loja.pg.query("select handle, categoria from produtos where categoria = 'camisetas' order by handle")).rows;
  const r = await mover('camisetas', 'roupas');
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const depois = await registro('camisetas');
  assert.deepEqual(depois, { ...antes, pai: 'roupas', ordem: 9 });
  assert.deepEqual((await loja.pg.query("select handle, categoria from produtos where categoria = 'camisetas' order by handle")).rows, produtosAntes);
  const lista = await loja.chamar('GET', '/api/admin/categorias', { cookie: admin });
  assert.equal(lista.json.categorias.find((c) => c.slug === 'camisetas').produtos, 2);
  const publica = await loja.chamar('GET', '/api/loja');
  assert.equal(publica.json.categorias.find((c) => c.slug === 'camisetas').pai, 'roupas');
  const html = await (await fetch(loja.base + '/catalogo?categoria=camisetas')).text();
  assert.match(html, /href="\/catalogo\?categoria=camisetas"/);
  assert.match(html, /submenu__sub/);
  assert.match(html, /Camiseta Teste/);
});

test('subcategoria muda para outra principal e pode voltar à raiz sem perder vínculos', async () => {
  assert.equal((await mover('camisetas', 'acessorios')).status, 200);
  assert.equal((await registro('camisetas')).pai, 'acessorios');
  assert.equal((await mover('camisetas', null)).status, 200);
  const principal = await registro('camisetas');
  assert.equal(principal.pai, null);
  assert.equal(principal.ordem, 7);
  assert.equal(principal.no_menu, true);
  assert.equal((await loja.pg.query("select count(*)::int as total from produtos where categoria = 'camisetas'")).rows[0].total, 2);
  // O formulário também envia string vazia ao escolher "Nenhuma".
  assert.equal((await mover('camisetas', '')).status, 200);
  assert.equal((await registro('camisetas')).pai, null);
});

test('categoria com filhas não é movida nem renomeada parcialmente numa operação incompatível', async () => {
  const antes = await registro('com-filhas');
  const filha = await registro('filha-conservada');
  const r = await mover('com-filhas', 'roupas', { nome: 'Não deve alterar', noMenu: false });
  assert.equal(r.status, 409);
  assert.match(r.json.erro, /tem subcategorias/);
  assert.deepEqual(await registro('com-filhas'), antes);
  assert.deepEqual(await registro('filha-conservada'), filha);
  assert.equal((await loja.pg.query("select categoria from produtos where handle = 'produto-filha'")).rows[0].categoria, filha.slug);
});

test('API rejeita autorreferência, ciclo, terceiro nível e categoria principal inexistente', async () => {
  const propria = await mover('camisetas', 'camisetas');
  assert.equal(propria.status, 400);
  assert.match(propria.json.erro, /dela mesma/);
  const ciclo = await mover('com-filhas', 'filha-conservada');
  assert.equal(ciclo.status, 400);
  assert.match(ciclo.json.erro, /categoria principal/);
  assert.equal((await mover('camisetas', 'roupas-casacos')).status, 400);
  assert.equal((await mover('camisetas', 'nao-existe')).status, 400);
  assert.equal((await mover('nao-existe', 'roupas')).status, 404);
  assert.equal((await registro('camisetas')).pai, null);
});

test('validação recusa pai malformado e alterações sem pai continuam funcionando', async () => {
  for (const pai of [false, 42, [], {}, '!!!', 'a'.repeat(81)]) {
    assert.equal((await mover('camisetas', pai)).status, 400, JSON.stringify(pai));
  }
  const r = await loja.chamar('PATCH', '/api/admin/categorias/filha-conservada', {
    cookie: admin, corpo: { nome: 'Filha Renomeada' },
  });
  assert.equal(r.status, 200);
  const filha = await registro('filha-conservada');
  assert.equal(filha.nome, 'Filha Renomeada');
  assert.equal(filha.pai, 'com-filhas');
  assert.equal(filha.no_menu, false);
});

test('banco protege a árvore inclusive quando a API é contornada', async () => {
  await assert.rejects(loja.pg.query("update categorias set pai = slug where slug = 'camisetas'"), /dela mesma/);
  await assert.rejects(loja.pg.query("update categorias set pai = 'filha-conservada' where slug = 'com-filhas'"), /categoria principal/);
  await assert.rejects(loja.pg.query("update categorias set pai = 'roupas' where slug = 'com-filhas'"), /tem subcategorias/);
  await assert.rejects(loja.pg.query("insert into categorias (slug, nome, pai) values ('terceiro-nivel', 'Inválida', 'roupas-casacos')"), /categoria principal/);
  assert.equal((await registro('com-filhas')).pai, null);
  assert.equal((await registro('filha-conservada')).pai, 'com-filhas');
});

test('mover as filhas primeiro permite transformar a antiga principal em subcategoria', async () => {
  assert.equal((await mover('filha-conservada', null)).status, 200);
  assert.equal((await mover('com-filhas', 'roupas')).status, 200);
  assert.equal((await registro('filha-conservada')).pai, null);
  assert.equal((await registro('filha-conservada')).no_menu, false);
  assert.equal((await registro('com-filhas')).pai, 'roupas');
  assert.equal((await loja.pg.query("select categoria from produtos where handle = 'produto-filha'")).rows[0].categoria, 'filha-conservada');
});
