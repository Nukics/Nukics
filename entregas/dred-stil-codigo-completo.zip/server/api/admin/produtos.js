// Admin > Produtos e envio de fotos.
const crypto = require('crypto');
const db = require('../../db');
const validar = require('../../validar');
const { ErroHttp, lerJson } = require('../../http');

const TAMANHO_MAXIMO_FOTO = 3 * 1024 * 1024; // a Vercel aceita no máximo 4,5 MB por requisição

// Tipo real do arquivo pelos primeiros bytes (não confia na extensão enviada).
function tipoDaImagem(buf) {
  if (buf.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]))) return ['jpg', 'image/jpeg'];
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return ['png', 'image/png'];
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return ['webp', 'image/webp'];
  return null;
}

async function produtoValidado(req) {
  const produto = validar.produto(await lerJson(req));
  const categorias = await db.categorias.listar();
  if (!categorias.some((c) => c.slug === produto.categoria)) throw new ErroHttp(400, 'Categoria não encontrada. Crie a categoria antes.');
  return produto;
}

// Mantém as abas de Destaques coerentes quando um produto muda de endereço ou é excluído.
async function ajustarDestaques(handleAntigo, handleNovo) {
  const abas = await db.destaques.ler();
  const ajustadas = abas.map((aba) => ({
    ...aba,
    produtos: aba.produtos.flatMap((h) => (h !== handleAntigo ? [h] : handleNovo ? [handleNovo] : [])),
  }));
  if (JSON.stringify(ajustadas) !== JSON.stringify(abas)) await db.destaques.gravar(ajustadas);
}

module.exports = [
  {
    metodo: 'GET',
    caminho: '/api/admin/produtos',
    acesso: 'admin',
    acao: async () => ({ produtos: await db.produtos.comCurtidas(await db.produtos.listar({ incluirInativos: true })) }),
  },
  {
    metodo: 'POST',
    caminho: '/api/admin/produtos',
    acesso: 'admin',
    acao: async ({ req }) => {
      const produto = await produtoValidado(req);
      if (!(await db.produtos.criar(produto))) throw new ErroHttp(409, 'Já existe um produto com este endereço.');
      return { produto };
    },
  },
  {
    metodo: 'PUT',
    caminho: '/api/admin/produtos/:handle',
    acesso: 'admin',
    acao: async ({ req, params }) => {
      if (!(await db.produtos.buscar(params.handle))) throw new ErroHttp(404, 'Produto não encontrado.');
      const produto = await produtoValidado(req);
      if (!(await db.produtos.atualizar(params.handle, produto))) throw new ErroHttp(409, 'Já existe um produto com este endereço.');
      if (produto.handle !== params.handle) await ajustarDestaques(params.handle, produto.handle);
      return { produto };
    },
  },
  {
    metodo: 'DELETE',
    caminho: '/api/admin/produtos/:handle',
    acesso: 'admin',
    acao: async ({ params }) => {
      if (!(await db.produtos.remover(params.handle))) throw new ErroHttp(404, 'Produto não encontrado.');
      await ajustarDestaques(params.handle, null);
    },
  },
  {
    metodo: 'POST',
    caminho: '/api/admin/imagens',
    acesso: 'admin',
    acao: async ({ req }) => {
      const { dados } = await lerJson(req, 4 * 1024 * 1024);
      const base64 = /^data:image\/[\w+]+;base64,([A-Za-z0-9+/=]+)$/.exec(String(dados || ''))?.[1];
      const buf = base64 && Buffer.from(base64, 'base64');
      const tipo = buf && tipoDaImagem(buf);
      if (!tipo) throw new ErroHttp(400, 'Envie uma foto JPG, PNG ou WEBP.');
      if (buf.length > TAMANHO_MAXIMO_FOTO) throw new ErroHttp(413, 'A foto pode ter no máximo 3 MB.');
      const [extensao, mime] = tipo;
      return { caminho: await db.fotos.salvar(`${crypto.randomUUID()}.${extensao}`, buf, mime) };
    },
  },
];
