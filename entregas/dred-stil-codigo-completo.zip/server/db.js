// Acesso aos dados no Supabase (Postgres + Storage). Estrutura em supabase/estrutura.sql.
// Usa a chave service_role, que só existe no servidor: nunca mande para o navegador.
// Todo acesso a dados passa por este módulo, sempre no formato usado pelo resto do código.
const { createClient } = require('@supabase/supabase-js');
const { ErroHttp } = require('./http');

const URL_SUPABASE = process.env.SUPABASE_URL;
const CHAVE = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!URL_SUPABASE || !CHAVE) throw new Error('Defina SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY (veja o README).');

const supabase = createClient(URL_SUPABASE, CHAVE, { auth: { persistSession: false, autoRefreshToken: false } });
const BUCKET = 'produtos';
const VIOLA_UNICO = '23505';
const VIOLA_REFERENCIA = '23503';
const STATUS_VENDA = ['pago', 'enviado', 'entregue']; // pedidos que contam como venda

// Devolve os dados ou lança o erro do Supabase.
function dados({ data, error }) {
  if (error) throw new Error(`Supabase: ${error.message}`);
  return data;
}

/* ---------------- categorias ---------------- */
const paraCategoria = (r) => ({ slug: r.slug, nome: r.nome, pai: r.pai, ordem: r.ordem, noMenu: r.no_menu });

const categorias = {
  async listar() {
    return dados(await supabase.from('categorias').select('*').order('ordem').order('nome')).map(paraCategoria);
  },
  // false se o endereço (slug) já existir
  async criar({ slug, nome, pai, ordem }) {
    const { error } = await supabase.from('categorias').insert({ slug, nome, pai, ordem });
    if (error?.code === VIOLA_UNICO) return false;
    dados({ error });
    return true;
  },
  async atualizar(slug, { nome, noMenu, ordem, pai }) {
    const linha = Object.fromEntries(Object.entries({ nome, no_menu: noMenu, ordem, pai }).filter(([, v]) => v !== undefined));
    if (!Object.keys(linha).length) return dados(await supabase.from('categorias').select('slug').eq('slug', slug)).length > 0;
    const resultado = await supabase.from('categorias').update(linha).eq('slug', slug).select('slug');
    if (resultado.error?.code === '23514' && pai !== undefined) {
      throw new ErroHttp(409, 'Não foi possível mover a categoria: ela ou a categoria principal mudou. Atualize a lista e mantenha apenas um nível de subcategorias.');
    }
    if (resultado.error?.code === VIOLA_REFERENCIA && pai !== undefined) throw new ErroHttp(400, 'Categoria principal não encontrada.');
    return dados(resultado).length > 0;
  },
  // 'em-uso' se houver produtos ou subcategorias ligados a ela
  async remover(slug) {
    const { data, error } = await supabase.from('categorias').delete().eq('slug', slug).select('slug');
    if (error?.code === VIOLA_REFERENCIA) return 'em-uso';
    return dados({ data, error }).length > 0;
  },
};

/* ---------------- produtos ---------------- */
const paraProduto = (r) => ({
  handle: r.handle,
  nome: r.nome,
  categoria: r.categoria,
  preco: Number(r.preco),
  precoDe: Number(r.preco_de),
  descricao: r.descricao,
  tamanhos: r.tamanhos,
  cores: r.cores,
  ativo: r.ativo,
  criadoEm: r.criado_em,
  // embalagem (usada no cálculo do frete)
  pesoKg: Number(r.peso_kg ?? 0.3),
  larguraCm: r.largura_cm ?? 20,
  alturaCm: r.altura_cm ?? 4,
  comprimentoCm: r.comprimento_cm ?? 28,
  codigoNcm: r.codigo_ncm || '61091000',
  estoqueId: r.estoque_id || null,
});

const paraLinhaProduto = (p) => ({
  handle: p.handle,
  nome: p.nome,
  categoria: p.categoria,
  preco: p.preco,
  preco_de: p.precoDe,
  descricao: p.descricao,
  tamanhos: p.tamanhos,
  cores: p.cores,
  ativo: p.ativo,
  peso_kg: p.pesoKg,
  largura_cm: p.larguraCm,
  altura_cm: p.alturaCm,
  comprimento_cm: p.comprimentoCm,
  codigo_ncm: p.codigoNcm,
});

const produtos = {
  async listar({ incluirInativos = false } = {}) {
    let consulta = supabase.from('produtos').select('*').order('criado_em');
    if (!incluirInativos) consulta = consulta.eq('ativo', true);
    return dados(await consulta).map(paraProduto);
  },
  async buscar(handle) {
    const linha = dados(await supabase.from('produtos').select('*').eq('handle', handle).maybeSingle());
    return linha && paraProduto(linha);
  },
  async buscarVarios(handles) {
    return dados(await supabase.from('produtos').select('*').in('handle', handles)).map(paraProduto);
  },
  // false se o handle já estiver em uso
  async criar(produto) {
    const { error } = await supabase.from('produtos').insert(paraLinhaProduto(produto));
    if (error?.code === VIOLA_UNICO) return false;
    dados({ error });
    return true;
  },
  // false se o novo handle já estiver em uso; as curtidas acompanham a troca de handle
  async atualizar(handleAnterior, produto) {
    const { error } = await supabase.from('produtos').update(paraLinhaProduto(produto)).eq('handle', handleAnterior);
    if (error?.code === VIOLA_UNICO) return false;
    dados({ error });
    return true;
  },
  async remover(handle) {
    return dados(await supabase.from('produtos').delete().eq('handle', handle).select('handle')).length > 0;
  },
  // Produto como o site mostra: com o total de curtidas.
  async comCurtidas(lista) {
    const totais = await curtidas.totais();
    return lista.map((p) => ({ ...p, curtidas: totais[p.handle] || 0 }));
  },
};

/* ---------------- usuários ---------------- */
const CAMPOS_USUARIO =
  'id, nome, apelido, email, senha, telefone, cpf, papel, versao_sessao, criado_em, email_verificado_em, dois_fatores, curtidas(handle)';
const COLUNAS_USUARIO = {
  nome: 'nome',
  apelido: 'apelido',
  cpf: 'cpf',
  senha: 'senha',
  telefone: 'telefone',
  versaoSessao: 'versao_sessao',
  emailVerificadoEm: 'email_verificado_em',
  doisFatores: 'dois_fatores',
};

// Qual dado único já está em uso, pelo nome da restrição que o banco recusou.
function conflitoUsuario(error) {
  const texto = `${error.message} ${error.details || ''}`;
  if (/apelido/.test(texto)) return 'apelido';
  if (/cpf/.test(texto)) return 'cpf';
  return 'email';
}
const MENSAGEM_CONFLITO = {
  email: 'Já existe uma conta com este e-mail.',
  apelido: 'Este apelido já está em uso. Escolha outro.',
  cpf: 'Este CPF já está cadastrado em outra conta.',
};

const paraUsuario = (r) => ({
  id: r.id,
  nome: r.nome,
  apelido: r.apelido || null,
  email: r.email,
  senha: r.senha,
  telefone: r.telefone,
  cpf: r.cpf || null,
  papel: r.papel,
  versaoSessao: r.versao_sessao,
  criadoEm: r.criado_em,
  emailVerificadoEm: r.email_verificado_em || null,
  doisFatores: r.dois_fatores === true,
  curtidas: (r.curtidas || []).map((c) => c.handle),
});

async function usuarioPor(coluna, valor) {
  const linha = dados(await supabase.from('usuarios').select(CAMPOS_USUARIO).eq(coluna, valor).maybeSingle());
  return linha && paraUsuario(linha);
}

const usuarios = {
  porId: (id) => usuarioPor('id', id),
  porEmail: (email) => usuarioPor('email', email),
  porApelido: (apelido) => usuarioPor('apelido', apelido),
  // Contas com exatamente este nome completo (sem diferenciar maiúsculas). Usado na recuperação de senha.
  async porNome(nome, limite = 3) {
    const termo = nome.replace(/[%_\\]/g, ''); // sem curingas
    return dados(await supabase.from('usuarios').select(CAMPOS_USUARIO).ilike('nome', termo).limit(limite)).map(paraUsuario);
  },
  // A loja tem um único admin (garantido por índice no banco).
  admin: () => usuarioPor('papel', 'admin'),
  // { usuario } ou { conflito: 'email' | 'apelido' | 'cpf', mensagem }
  async criar({ nome, apelido = null, email, telefone = '', cpf = null, senha, papel = 'cliente' }) {
    const { data, error } = await supabase.from('usuarios')
      .insert({ nome, apelido, email, telefone, cpf, senha, papel }).select(CAMPOS_USUARIO).single();
    if (error?.code === VIOLA_UNICO) {
      const conflito = conflitoUsuario(error);
      return { conflito, mensagem: MENSAGEM_CONFLITO[conflito] };
    }
    return { usuario: paraUsuario(dados({ data, error })) };
  },
  // campos no formato do código (ex.: versaoSessao). O papel (cliente/admin) não pode ser alterado.
  // Apelido ou CPF já usados por outra conta: ErroHttp 409.
  async atualizar(id, campos) {
    const linha = Object.fromEntries(
      Object.entries(campos).map(([k, v]) => {
        if (!COLUNAS_USUARIO[k]) throw new Error(`Campo não pode ser alterado: ${k}`);
        return [COLUNAS_USUARIO[k], v];
      })
    );
    const { data, error } = await supabase.from('usuarios').update(linha).eq('id', id).select(CAMPOS_USUARIO).maybeSingle();
    if (error?.code === VIOLA_UNICO) throw new ErroHttp(409, MENSAGEM_CONFLITO[conflitoUsuario(error)]);
    const atualizado = dados({ data, error });
    return atualizado && paraUsuario(atualizado);
  },
  async contar() {
    const { count, error } = await supabase.from('usuarios').select('id', { count: 'exact', head: true });
    dados({ error });
    return count;
  },
  // Lista paginada, mais recentes primeiro, com busca por nome ou e-mail.
  async listarPagina({ busca = '', pagina = 1, porPagina = 20 }) {
    let consulta = supabase
      .from('usuarios')
      .select(CAMPOS_USUARIO, { count: 'exact' })
      .order('criado_em', { ascending: false })
      .range((pagina - 1) * porPagina, pagina * porPagina - 1);
    const termo = busca.replace(/[^\p{L}\p{N}@.\-_ ]/gu, '').trim(); // tira caracteres especiais do filtro
    if (termo) consulta = consulta.or(`nome.ilike.%${termo}%,email.ilike.%${termo}%`);
    const { data, count, error } = await consulta;
    dados({ error });
    return { clientes: data.map(paraUsuario), total: count };
  },
};

/* ---------------- curtidas ---------------- */
const curtidas = {
  // Curte ou descurte; devolve se ficou curtido.
  async alternar(usuarioId, handle) {
    const removidas = dados(await supabase.from('curtidas').delete().eq('usuario_id', usuarioId).eq('handle', handle).select('handle'));
    if (removidas.length) return false;
    const { error } = await supabase.from('curtidas').insert({ usuario_id: usuarioId, handle });
    if (error?.code !== VIOLA_UNICO) dados({ error }); // clique duplo: já estava curtido
    return true;
  },
  // { handle: número de curtidas }
  async totais() {
    const linhas = dados(await supabase.from('curtidas_por_produto').select('handle, total'));
    return Object.fromEntries(linhas.map((l) => [l.handle, l.total]));
  },
};

/* ---------------- pedidos e vendas ---------------- */
const paraPedido = (r) => ({
  id: r.id,
  numero: r.numero,
  usuarioId: r.usuario_id,
  cliente: r.usuarios ? { nome: r.usuarios.nome, email: r.usuarios.email, telefone: r.usuarios.telefone } : null,
  itens: r.itens,
  subtotal: r.subtotal == null ? null : Number(r.subtotal),
  frete: Number(r.frete || 0),
  freteNome: r.frete_nome || null,
  fretePrazoDias: r.frete_prazo_dias ?? null,
  total: Number(r.total),
  status: r.status,
  pagamentoMetodo: r.pagamento_metodo || null,
  pagamentoId: r.pagamento_id || null,
  pagamentoStatus: r.pagamento_status || null,
  pagamentoDados: r.pagamento_dados || null,
  rastreio: r.rastreio || null,
  // dados de entrega só para o dono e o admin (nunca em listas públicas)
  entrega: r.endereco ? { cliente: r.cliente, endereco: r.endereco } : null,
  expiraEm: r.expira_em || null,
  criadoEm: r.criado_em,
  atualizadoEm: r.atualizado_em,
});

const pedidos = {
  STATUS_VENDA,
  async criar({ usuarioId, itens, total }) {
    return paraPedido(dados(await supabase.from('pedidos').insert({ usuario_id: usuarioId, itens, total }).select('*').single()));
  },
  // Checkout com idempotência (mesma chave = mesmo pedido). Lança 'limite_pedidos_abertos'.
  async criarCheckout(p) {
    const { data, error } = await supabase.rpc('criar_pedido_checkout', {
      p_usuario: p.usuarioId,
      p_chave: p.chave,
      p_itens: p.itens,
      p_subtotal: p.subtotal,
      p_frete: p.frete,
      p_frete_servico: p.freteServico,
      p_frete_nome: p.freteNome,
      p_frete_prazo: p.fretePrazoDias,
      p_cliente: p.cliente,
      p_endereco: p.endereco,
      p_metodo: p.metodo,
      p_validade_min: p.validadeMin,
    });
    if (error && /limite_pedidos_abertos/.test(error.message)) return { limite: true };
    return { pedido: paraPedido(dados({ data, error })[0]) };
  },
  async definirPagamento(id, { pagamentoId, dadosPagamento }) {
    dados(await supabase.from('pedidos')
      .update({ pagamento_id: pagamentoId, pagamento_status: 'pendente', pagamento_dados: dadosPagamento, atualizado_em: new Date().toISOString() })
      .eq('id', id));
  },
  // Uma única instância pode criar a intenção. Não liberar automaticamente após timeout:
  // a API pode ter criado a intenção mesmo sem devolver a resposta.
  async reservarPagamentoGlobal(id) {
    return dados(await supabase.from('pedidos').update({ pagamento_status: 'criando' })
      .eq('id', id).eq('status', 'aguardando').is('pagamento_id', null).is('pagamento_status', null).select('id')).length === 1;
  },
  async falhaPagamentoGlobal(id) {
    dados(await supabase.from('pedidos').update({ pagamento_status: 'reconciliar' }).eq('id', id).is('pagamento_id', null));
  },
  async porPagamentoId(id) {
    const r = dados(await supabase.from('pedidos').select('*').eq('pagamento_id', id).maybeSingle());
    return r && paraPedido(r);
  },
  // Falha ao gerar a cobrança: o pedido não fica aberto.
  async cancelarSemPagamento(id) {
    dados(await supabase.from('pedidos').update({ status: 'cancelado', atualizado_em: new Date().toISOString() }).eq('id', id).eq('status', 'aguardando'));
  },
  // Pedido de um cliente (isolamento: sempre filtra pelo dono).
  async porId(id) {
    const linha = dados(await supabase.from('pedidos').select('*, usuarios(nome, email, telefone)').eq('id', id).maybeSingle());
    return linha && paraPedido(linha);
  },
  async doUsuarioPorId(usuarioId, id) {
    const linha = dados(await supabase.from('pedidos').select('*').eq('id', id).eq('usuario_id', usuarioId).maybeSingle());
    return linha && paraPedido(linha);
  },
  async processarPagamento(provedor, pagamentoId, status, valor) {
    return dados(await supabase.rpc('processar_pagamento', { p_provedor: provedor, p_pagamento_id: pagamentoId, p_status: status, p_valor: valor }));
  },
  async processarPagamentoGlobal(pagamentoId, status, valor) {
    return dados(await supabase.rpc('processar_pagamento_global', { p_pagamento_id: pagamentoId, p_status: status, p_valor: valor }));
  },
  // Pix vencidos (só pedidos do checkout têm prazo; os antigos do WhatsApp ficam de fora).
  async vencidos(limite = 100) {
    return dados(await supabase.from('pedidos').select('id, pagamento_id, pagamento_metodo').eq('status', 'aguardando').not('expira_em', 'is', null)
      .lt('expira_em', new Date().toISOString()).limit(limite));
  },
  async expirar(id) {
    return dados(await supabase.from('pedidos').update({ status: 'expirado', atualizado_em: new Date().toISOString() })
      .eq('id', id).eq('status', 'aguardando').select('id')).length > 0;
  },
  async definirRastreio(id, rastreio) {
    const linha = dados(await supabase.from('pedidos').update({ rastreio, atualizado_em: new Date().toISOString() }).eq('id', id).select('*').maybeSingle());
    return linha && paraPedido(linha);
  },
  async listarPagina({ status = '', pagina = 1, porPagina = 20 }) {
    let consulta = supabase
      .from('pedidos')
      .select('*, usuarios(nome, email, telefone)', { count: 'exact' })
      .order('criado_em', { ascending: false })
      .range((pagina - 1) * porPagina, pagina * porPagina - 1);
    if (status) consulta = consulta.eq('status', status);
    const { data, count, error } = await consulta;
    dados({ error });
    return { pedidos: data.map(paraPedido), total: count };
  },
  async doUsuario(usuarioId) {
    return dados(await supabase.from('pedidos').select('*').eq('usuario_id', usuarioId).order('criado_em', { ascending: false }).limit(50)).map(paraPedido);
  },
  async mudarStatus(id, status) {
    const linha = dados(await supabase.from('pedidos').update({ status, atualizado_em: new Date().toISOString() }).eq('id', id).select('*').maybeSingle());
    return linha && paraPedido(linha);
  },
  // { usuarioId: número de compras } para os usuários pedidos
  async comprasPorUsuario(ids) {
    if (!ids.length) return {};
    const linhas = dados(await supabase.from('compras_por_usuario').select('usuario_id, compras').in('usuario_id', ids));
    return Object.fromEntries(linhas.map((l) => [l.usuario_id, l.compras]));
  },
  async resumo() {
    const r = dados(await supabase.from('vendas_resumo').select('*').single());
    const numero = (v) => Number(v);
    return {
      hoje: { vendas: r.vendas_hoje, faturamento: numero(r.faturamento_hoje) },
      seteDias: { vendas: r.vendas_7_dias, faturamento: numero(r.faturamento_7_dias) },
      mes: { vendas: r.vendas_mes, faturamento: numero(r.faturamento_mes) },
      total: { vendas: r.vendas_total, faturamento: numero(r.faturamento_total) },
      aguardando: r.pedidos_aguardando,
    };
  },
  async porDia() {
    return dados(await supabase.from('vendas_por_dia').select('*')).map((d) => ({ dia: d.dia, vendas: d.vendas, faturamento: Number(d.faturamento) }));
  },
};

/* ---------------- conteúdo editável ---------------- */
async function lerConteudo(chave, padrao) {
  const linha = dados(await supabase.from('conteudo').select('valor').eq('chave', chave).maybeSingle());
  return linha ? linha.valor : padrao;
}

async function gravarConteudo(chave, valor) {
  dados(await supabase.from('conteudo').upsert({ chave, valor }));
}

// faq, config, menu, destaques e paginas: cada um com ler() e gravar(valor)
const conteudo = (chave, padrao) => ({ ler: () => lerConteudo(chave, padrao), gravar: (valor) => gravarConteudo(chave, valor) });
const faq = conteudo('faq', []);
const config = conteudo('config', {});
const menu = conteudo('menu', []);
const destaques = conteudo('destaques', []);
const paginas = conteudo('paginas', {});
// Uso exclusivo do servidor: nunca é retornado pelas rotas de conteúdo do painel.
const integracoes = conteudo('integracoes', {});

/* ---------------- fotos ---------------- */
const fotos = {
  // Endereço público das fotos enviadas (usado na validação dos caminhos de imagem).
  PREFIXO: `${URL_SUPABASE}/storage/v1/object/public/${BUCKET}/`,
  async salvar(nome, arquivo, tipo) {
    dados(await supabase.storage.from(BUCKET).upload(nome, arquivo, { contentType: tipo }));
    return supabase.storage.from(BUCKET).getPublicUrl(nome).data.publicUrl;
  },
};

/* ---------------- estoque por grupo e cor ---------------- */
const paraEstoque = (r) => ({ id: r.id, nome: r.nome, cor: r.cor || null, quantidade: r.quantidade, atualizadoEm: r.atualizado_em });
const normalizarCor = (cor) => String(cor || '').trim().toLowerCase();

const estoques = {
  async listar() {
    const [grupos, prods, vinculos] = await Promise.all([
      dados(await supabase.from('estoques').select('*').eq('arquivado', false).order('nome').order('cor')),
      dados(await supabase.from('produtos').select('handle, nome, estoque_id')),
      dados(await supabase.from('estoque_produtos_cores').select('*')),
    ]);
    return grupos.map((g) => ({
      ...paraEstoque(g),
      produtos: prods.filter((p) => g.cor
        ? vinculos.some((v) => v.estoque_id === g.id && v.handle === p.handle)
        : p.estoque_id === g.id).map((p) => ({ handle: p.handle, nome: p.nome })),
    }));
  },
  async quantidades() {
    const linhas = dados(await supabase.from('estoques').select('id, quantidade'));
    return Object.fromEntries(linhas.map((l) => [l.id, l.quantidade]));
  },
  async disponibilidade() {
    const [quantidades, vinculos] = await Promise.all([
      this.quantidades(),
      dados(await supabase.from('estoque_produtos_cores').select('handle, cor, estoque_id')),
    ]);
    return { quantidades, porCor: Object.fromEntries(vinculos.map((v) => [JSON.stringify([v.handle, v.cor]), v.estoque_id])) };
  },
  idDaCor(produto, cor, disponibilidade) {
    return disponibilidade.porCor[JSON.stringify([produto.handle, normalizarCor(cor)])] || produto.estoqueId || null;
  },
  async porId(id) {
    const linha = dados(await supabase.from('estoques').select('*').eq('id', id).eq('arquivado', false).maybeSingle());
    return linha && paraEstoque(linha);
  },
  async salvar(id, { nome, cor, quantidade, produtos: handles }, usuarioId) {
    const resultado = await supabase.rpc('salvar_estoque_cor', {
      p_id: id || null, p_nome: nome, p_cor: cor, p_quantidade: quantidade, p_produtos: handles, p_usuario: usuarioId,
    });
    if (resultado.error?.code === VIOLA_UNICO) throw new ErroHttp(409, 'Já existe um estoque com esse nome e essa cor.');
    if (resultado.error?.code === '23514') throw new ErroHttp(409, /cor_estoque_imutavel/.test(resultado.error.message)
      ? 'A cor de um saldo existente não pode ser alterada. Crie um novo saldo por cor.'
      : 'Algum produto não possui essa cor. Atualize a lista de produtos.');
    const linha = dados(resultado);
    return linha && paraEstoque(linha);
  },
  async remover(id) {
    return dados(await supabase.rpc('arquivar_estoque', { p_id: id }));
  },
  async movimentos(id, limite = 20) {
    return dados(await supabase.from('estoque_movimentos').select('delta, quantidade_final, motivo, criado_em')
      .eq('estoque_id', id).order('criado_em', { ascending: false }).order('id', { ascending: false }).limit(limite))
      .map((m) => ({ delta: m.delta, quantidadeFinal: m.quantidade_final, motivo: m.motivo, criadoEm: m.criado_em }));
  },
};

/* ---------------- notas fiscais ---------------- */
const paraNota = (r) => ({
  id: r.id,
  pedidoId: r.pedido_id,
  usuarioId: r.usuario_id,
  ref: r.ref,
  provedor: r.provedor,
  status: r.status,
  numero: r.numero,
  serie: r.serie,
  chave: r.chave,
  urlDanfe: r.url_danfe,
  urlXml: r.url_xml,
  mensagem: r.mensagem,
  emailEnviadoEm: r.email_enviado_em,
  criadoEm: r.criado_em,
});
const COLUNAS_NOTA = { status: 'status', numero: 'numero', serie: 'serie', chave: 'chave', urlDanfe: 'url_danfe', urlXml: 'url_xml', mensagem: 'mensagem', emailEnviadoEm: 'email_enviado_em' };

const notas = {
  // null se o pedido já tiver nota em andamento ou autorizada
  async criar({ pedidoId, usuarioId, ref, provedor }) {
    const { data, error } = await supabase.from('notas_fiscais')
      .insert({ pedido_id: pedidoId, usuario_id: usuarioId, ref, provedor, status: 'processando' }).select('*').single();
    if (error?.code === VIOLA_UNICO) return null;
    return paraNota(dados({ data, error }));
  },
  async atualizar(id, campos) {
    const linha = Object.fromEntries(Object.entries(campos).map(([k, v]) => [COLUNAS_NOTA[k] || falhaCampo(k), v]));
    linha.atualizado_em = new Date().toISOString();
    return paraNota(dados(await supabase.from('notas_fiscais').update(linha).eq('id', id).select('*').single()));
  },
  async porId(id) {
    const linha = dados(await supabase.from('notas_fiscais').select('*').eq('id', id).maybeSingle());
    return linha && paraNota(linha);
  },
  async doPedido(pedidoId) {
    return dados(await supabase.from('notas_fiscais').select('*').eq('pedido_id', pedidoId).order('criado_em', { ascending: false })).map(paraNota);
  },
  async doUsuario(usuarioId) {
    return dados(await supabase.from('notas_fiscais').select('*').eq('usuario_id', usuarioId).order('criado_em', { ascending: false }).limit(100)).map(paraNota);
  },
  async dosPedidos(ids) {
    if (!ids.length) return [];
    return dados(await supabase.from('notas_fiscais').select('*').in('pedido_id', ids).order('criado_em', { ascending: false })).map(paraNota);
  },
  async processando(limite = 50) {
    return dados(await supabase.from('notas_fiscais').select('*').eq('status', 'processando').limit(limite)).map(paraNota);
  },
};
function falhaCampo(k) {
  throw new Error(`Campo de nota inválido: ${k}`);
}

/* ---------------- segurança: limites, tokens, códigos e auditoria ---------------- */
const seguranca = {
  // { permitido, esperaS } — conta a tentativa (atômico no banco, vale para todas as instâncias)
  async consumirLimite(chave, max, janelaS) {
    const [r] = dados(await supabase.rpc('consumir_limite', { p_chave: chave, p_max: max, p_janela_s: janelaS }));
    return { permitido: r.permitido, esperaS: r.espera_s };
  },
  async zerarLimite(chave) {
    dados(await supabase.from('limites').delete().eq('chave', chave));
  },
  // Um token ativo por tipo: criar um novo invalida o anterior.
  async criarToken(usuarioId, tipo, tokenHash, validadeS) {
    dados(await supabase.from('tokens_conta').delete().eq('usuario_id', usuarioId).eq('tipo', tipo));
    dados(await supabase.from('tokens_conta').insert({
      token_hash: tokenHash, usuario_id: usuarioId, tipo, expira_em: new Date(Date.now() + validadeS * 1000).toISOString(),
    }));
  },
  // Devolve o id do dono, ou null se inválido/expirado/já usado (uso único e atômico).
  async consumirToken(tokenHash, tipo) {
    return dados(await supabase.rpc('consumir_token_conta', { p_hash: tokenHash, p_tipo: tipo })) || null;
  },
  async apagarTokens(usuarioId, tipo) {
    dados(await supabase.from('tokens_conta').delete().eq('usuario_id', usuarioId).eq('tipo', tipo));
  },
  async criarDesafio(usuarioId, idHash, codigoHash, validadeS) {
    dados(await supabase.from('desafios_2fa').delete().eq('usuario_id', usuarioId));
    dados(await supabase.from('desafios_2fa').insert({
      id_hash: idHash, usuario_id: usuarioId, codigo_hash: codigoHash, expira_em: new Date(Date.now() + validadeS * 1000).toISOString(),
    }));
  },
  // Conta a tentativa antes da comparação; null se expirado ou com 5 tentativas.
  async tentarDesafio(idHash) {
    const [r] = dados(await supabase.rpc('tentar_desafio_2fa', { p_id_hash: idHash }));
    return r ? { usuarioId: r.usuario_id, codigoHash: r.codigo_hash } : null;
  },
  // true só para quem conseguiu apagar (o código vale uma vez).
  async consumirDesafio(idHash) {
    return dados(await supabase.from('desafios_2fa').delete().eq('id_hash', idHash).select('id_hash')).length > 0;
  },
  async apagarDesafios(usuarioId) {
    dados(await supabase.from('desafios_2fa').delete().eq('usuario_id', usuarioId));
  },
  async auditar(acao, { usuarioId = null, ip = null, detalhe = {} } = {}) {
    const { error } = await supabase.from('auditoria').insert({ usuario_id: usuarioId, acao, ip, detalhe });
    if (error) console.error(`auditoria: ${error.message}`); // não derruba a operação principal
  },
};

module.exports = { categorias, produtos, usuarios, curtidas, pedidos, faq, config, menu, destaques, paginas, integracoes, fotos, seguranca, estoques, notas };
