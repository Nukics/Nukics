# Dred Stil — Loja

Loja em Node.js com dados no Supabase (Postgres + Storage), publicada na Vercel.

## 1. Banco de dados (Supabase) — uma vez só

1. Crie um projeto em https://supabase.com.
2. Em **SQL Editor**, num banco novo, rode `supabase/estrutura.sql`, depois `supabase/dados-iniciais.sql` e as migrações nesta ordem: `002-contas-pagamentos-seguranca.sql`, `003-cadastro-estoque-notas.sql`, `004-getnet-global.sql`, `005-estoque-por-cor.sql` e `006-categorias-mover.sql`. Os arquivos `*-reverter.sql` são reversões e não fazem parte da instalação. Em banco existente, aplique somente as migrações que faltam; não carregue os dados iniciais novamente.
3. Em **Project Settings > API**, copie a *Project URL* e a chave *service_role*.

## 2. Rodar localmente

```bash
npm install
```

Copie `.env.example` para `.env.local` e preencha `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` e `SESSION_SECRET`.

```bash
node serve.js
```

Abra http://localhost:5173. **Atenção:** com o `.env.local` apontando para o Supabase de produção, o site local usa o banco de verdade.

Para testar sem tocar no banco de verdade (banco descartável em memória, Pix e frete simulados, e-mails em `.dev-emails/`):

```bash
node scripts/demo-local.js
```

Testes automáticos (também rodam num banco descartável):

```bash
npm test
```

## 3. Conta admin

```bash
node scripts/criar-admin.js email@dredstil.com.br "Nome" "senha-com-8-ou-mais"
```

Para dar admin a quem já tem conta: `node scripts/criar-admin.js email@cliente.com`.
Depois disso, outros admins podem ser nomeados pelo painel (`/admin` > Clientes).

A loja tem **um único admin** (o banco recusa um segundo).

No painel admin (`/admin`) dá para:
- **Vendas:** faturamento de hoje, 7 dias, mês e total, ticket médio e gráfico dos últimos 30 dias, com botão para esconder os valores.
- **Pedidos:** pedidos pagos por Pix mudam para Pago sozinhos; os combinados pelo WhatsApp o admin atualiza. Mostra endereço de entrega e campo de código de rastreio. "Em análise" = pagamento com valor diferente ou pago depois do Pix expirar.
- **Produtos** (com envio de fotos) e **Categorias** (com subcategorias e opção de aparecer no menu).
- **Destaques:** abas da página inicial e os produtos de cada uma.
- **Menu:** itens do menu do site (Catálogo com as categorias, categorias, páginas, links), ordem e visibilidade.
- **Clientes:** número de compras, selo "Bom cliente" a partir de 5 compras e botão que envia ao cliente um link de nova senha por e-mail (o admin nunca vê a senha).
- **Páginas:** textos de Quem somos, Trocas e devoluções, Onde estamos, Segurança, Privacidade e Termos.
- **Perguntas frequentes** e **Configurações** (WhatsApp, parcelas, faixa promocional, redes sociais e banners).

## 4. Publicar na Vercel

Cadastre as três variáveis de `.env.example` em **Vercel > Project > Settings > Environment Variables**
(ou `vercel env add NOME production`) e publique com `vercel --prod`.

Na Vercel, os arquivos de `public/` são entregues direto pela CDN e todo o resto
(páginas e `/api`) passa pela função `api/index.js`.

## Estrutura

```
api/index.js       função da Vercel (usa server/)
server/            servidor
  index.js         cabeçalhos de segurança, arquivos estáticos (local) e roteamento
  paginas.js       rotas das páginas (HTML)
  render.js        layout único (cabeçalho, rodapé, barra mobile) + views
  api/             API JSON: loja.js (público, curtidas e pedidos), conta.js
  api/admin/       rotas do admin por assunto (vendas, produtos, categorias, clientes, conteúdo)
  db.js            acesso aos dados no Supabase
  auth.js          senhas (scrypt) e sessão em cookie assinado
  validar.js       validação de tudo que chega do navegador
  vitrine.js       regras de exibição: menu, categorias, páginas de texto, selo de bom cliente
  texto.js         formatação segura dos textos das páginas editados no admin
views/             HTML das páginas (layout.html envolve todas)
public/            CSS, JS do navegador, fontes e imagens
  js/main.js       entrada; carrega js/paginas/<página>.js
  js/admin/        seções do painel admin
supabase/          SQL da estrutura e dos dados iniciais
scripts/           utilitários de linha de comando
```

## Pagamento e frete

- **Checkout com Pix (Getnet)** e **frete por produto (Melhor Envio)** ligam sozinhos quando as variáveis de `.env.example` estão preenchidas. Enquanto não estiverem, a compra continua pelo WhatsApp.
- Preço e frete são sempre calculados no servidor. Cada tentativa de checkout tem chave de idempotência (clique duplo não cria dois pedidos).
- A notificação da Getnet (`/api/webhooks/getnet?token=...`) só serve de aviso: o status é consultado na própria Getnet.
- Pix não pago expira em 30 minutos (tarefa diária em `vercel.json`; no plano Pro dá para rodar a cada 15 minutos).
- Peso e medidas da embalagem ficam no cadastro de cada produto (Admin > Produtos) e entram no cálculo do frete.

## Segurança

Veja [SEGURANCA.md](SEGURANCA.md). Resumo:
- Senhas com scrypt (senhas comuns recusadas); sessão em cookie `HttpOnly`, `SameSite=Lax` e `Secure` em produção.
- Esqueci a senha por e-mail (link de uso único, 30 min, derruba todas as sessões) e confirmação de e-mail.
- Verificação em duas etapas por e-mail (código de 6 dígitos, máximo 5 tentativas), obrigatória para o admin quando o e-mail estiver configurado.
- Limites de tentativas no banco (valem para todas as instâncias da Vercel), por IP e por conta.
- A chave `service_role` só existe no servidor. Tabelas com RLS ligado e sem políticas; funções do banco sem permissão para as chaves públicas.
- Mutações só em JSON e com checagem de origem (CSRF); HSTS e CSP.

## Global API Getnet: cartão, parcelamento e Pix no site

O provedor adicional `getnet-global` usa o Web Checkout oficial incorporado por iframe, com OAuth no servidor e webhook autenticado. O Pix legado e o WhatsApp foram preservados. Veja [configuração, fontes oficiais e homologação](docs/GETNET.md). É necessário aplicar a migração `004-getnet-global.sql` e obter as credenciais/habilitações próprias antes de usar pagamentos reais.

## Banners, identidade visual e Atacado

O admin permite ajustar posição e zoom dos banners separadamente para desktop e celular. A página `/atacado` apresenta tabela, simulador e produtos elegíveis, com o mesmo desconto aplicado pelo servidor. Consulte [as mudanças do site e como configurar](docs/ALTERACOES-SITE.md).


## Destaques, estoque por cor e categorias

Os Destaques rolam na horizontal em celular e computador. Em **Admin > Estoque**, um tipo de peça reúne saldos por cor e vários produtos podem compartilhar cada saldo. Em **Categorias**, o seletor **Dentro de** move categorias existentes preservando produtos e endereço. Para atualizar uma loja existente, consulte [o guia das migrações 005 e 006](docs/ESTOQUE-CORES-CATEGORIAS.md).
