// Inicia a loja localmente: node serve.js  (porta padrão 5173; mude com PORT=...)
// As chaves ficam em .env.local (copie de .env.example).
try {
  process.loadEnvFile(require('path').join(__dirname, '.env.local'));
} catch {
  console.warn('Arquivo .env.local não encontrado: usando só as variáveis de ambiente do sistema.');
}
require('./server').iniciar();
