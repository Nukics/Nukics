# Getnet Global API e checkout incorporado

Esta integração usa OAuth da Global API e o Web Checkout oficial em **iframe**. Cartão, Pix e parcelamento são oferecidos pelo componente conforme o contrato e a configuração comercial da conta. O navegador da loja recebe somente o identificador da intenção. Não há campos de cartão na loja, tokenização de PAN/CVV no seu backend, nem redirecionamento de pagamento implementado pela aplicação.

O código está implementado e validado localmente com respostas simuladas. **A homologação real ainda não foi executada**, pois faltam as credenciais próprias da conta. Não usar dados de cartões reais em testes.

## Documentação consultada

- [Swagger Global API, versão 1.0.4](https://docs.globalgetnet.com/pt/products/online-payments/regional-api/swagger#tag/authentication). Apesar do slug `regional-api`, o título oficial é Global API.
- [Visão geral e formatos do Web Checkout](https://docs.globalgetnet.com/en/products/online-payments/web-checkout?doc=integration-options-wbc).
- [Integração backend e loader oficial](https://docs.globalgetnet.com/en/products/online-payments/web-checkout?doc=quickstart-create-a-payment-wbc).
- [Swagger do Web Checkout](https://docs.globalgetnet.com/en/products/online-payments/web-checkout/swagger).
- [Configuração técnica e comercial](https://docs.globalgetnet.com/en/products/online-payments/web-checkout?doc=configuration-by-api-wbc).
- [Notificações autenticadas](https://docs.globalgetnet.com/en/products/online-payments/web-checkout?doc=receive-webhook-payment-data-wbc).

As especificações foram obtidas do portal oficial em 17/10/2026. O Basic enviado na conversa coincide com o exemplo público do Swagger: não é prova de uma credencial própria e não foi usado para autenticar. A verificação sem credenciais recebeu `invalid_client`, como esperado; somente a conectividade foi verificada.

## Preparar homologação

1. Use Node.js >=20.12 e execute `npm ci`.
2. Em um Supabase **de homologação**, aplique a estrutura e as migrações existentes em ordem: `estrutura.sql`, `002-contas-pagamentos-seguranca.sql`, `003-cadastro-estoque-notas.sql` e `004-getnet-global.sql`. Se o banco já usa as três primeiras, aplique somente a 004. A nova função permite recusa seguida de aprovação na mesma intenção sem alterar o Pix legado.
3. Configure as variáveis em `.env.local` (ignorado pelo Git) ou no gerenciador seguro do ambiente/Vercel. Nunca coloque valores em JavaScript público, prints, commits ou chat.

| Variável | Uso |
| --- | --- |
| `PAGAMENTO_PROVEDOR=getnet-global` | Seleciona o checkout incorporado. `getnet` mantém o Pix brasileiro anterior; `simulado` é somente local. |
| `GETNET_GLOBAL_AMBIENTE=homologacao` | Usa `https://api.pre.globalgetnet.com`. |
| `GETNET_GLOBAL_CLIENT_ID` | Identificador próprio de homologação. |
| `GETNET_GLOBAL_CLIENT_SECRET` | Segredo próprio, usado somente no servidor. |
| `GETNET_GLOBAL_SELLER_ID` | UUID do estabelecimento brasileiro, conferido na consulta de pagamento. |
| `GETNET_GLOBAL_WEBHOOK_USER` | Usuário exclusivo para autenticação das notificações. |
| `GETNET_GLOBAL_WEBHOOK_PASSWORD` | Senha exclusiva com pelo menos 16 caracteres, igual à cadastrada na Getnet. |
| `APP_URL` | Origem HTTPS pública do site, sem caminhos ou credenciais. |

As configurações existentes de Supabase, sessão, e-mail, frete e cron continuam necessárias para os respectivos recursos. Em produção, o checkout existente exige frete configurado; a retirada gratuita continua disponível no fluxo.

4. Solicite à Getnet a habilitação do **Web Checkout incorporado para Brasil/BRL**, cartão de crédito, bandeiras, Pix, cofre/tokenização, 3DS, antifraude e planos de parcelamento com/sem juros conforme o contrato. Configure somente os métodos que deseja oferecer. Não presuma que a quantidade de parcelas do painel da loja altera o contrato Getnet.
5. Consulte a configuração da conta com `node scripts/getnet-verificar.js`. O comando sem argumentos faz apenas OAuth e leituras; imprime capacidades, sem tokens, segredos ou dados cadastrais.
6. Configure o webhook na configuração técnica da Getnet com a URL `https://SEU-DOMINIO/api/webhooks/getnet-global`, autenticação `user_credentials` e o usuário/senha escolhidos. Não usar segredo na query string para este provedor.
7. O utilitário `node scripts/getnet-verificar.js --registrar-webhook-homologacao` registra esse webhook e define sucesso/erro para `/checkout` por PATCH, somente na homologação. **Ele altera a configuração técnica da conta**; execute quando o domínio e as variáveis estiverem corretos. Não altera o layout remoto nem as opções comerciais. Não foi executado contra uma conta real nesta entrega.
8. Use `node serve.js` para o site ligado ao seu Supabase de homologação. O webhook precisa de um domínio público HTTPS; localhost não é alcançável pela Getnet.

A documentação permite personalizar cor, destaque e fonte do componente na configuração técnica. Preserve os demais campos ao editar. As regras de 3DS e eventuais interações do emissor precisam ser verificadas em homologação; a loja não implementa redirecionamento externo, mas isso não garante o comportamento de toda autenticação bancária nem constitui atestado PCI DSS.

## Endpoints implementados, conforme documentação

No backend Getnet:

- `POST /authentication/oauth2/access_token`: Basic de `client_id:client_secret`, formulário `grant_type=client_credentials`, cache em memória e renovação antes de expirar.
- `POST /dpy/web-checkout/v1/payment-intent`: intenção criada com preços e frete do servidor, BRL e expiração de 30 minutos.
- `GET /dpy/web-checkout/v1/payment-intent/{payment_intent_id}`: consulta autenticada para confirmar conta, país, referência, status, moeda e valor.
- `PATCH /dpy/web-checkout/v1/payment-intent/{payment_intent_id}`: cancela intenção pendente antes de encerrar um pedido vencido.
- `GET /dpy/web-checkout/v1/sellers`, `/technical-configurations`, `/business-configurations`: verificação de conta/habilitações.
- `PATCH /dpy/web-checkout/v1/technical-configurations`: configuração técnica opcional de homologação.

No navegador: `${host}/digital-checkout/loader.js`, com host `https://www.pre.globalgetnet.com` na homologação e `https://www.globalgetnet.com` na produção. O SDK recebe `paymentIntentId` e `checkoutType: 'iframe'`. A CSP permite somente os hosts necessários à página de checkout; as outras páginas mantêm a política anterior.

Na loja: `POST /api/webhooks/getnet-global` recebe avisos autenticados e consulta a API; `POST /api/pedidos/:id/consultar-pagamento` permite ao dono conferir seu pedido. Dados do aviso e mensagens do navegador não aprovam pedidos. A consulta no navegador complementa o webhook, inclusive se uma notificação atrasar.

## Estados e falhas

- `paid`: aprova somente com referência, conta, moeda e valor conferidos. Valor divergente vai para revisão; valor ausente não aprova.
- `pending`/`registered`: aguarda. `error` permanece em conciliação, pois falha de processamento não comprova recusa.
- `denied`: sinaliza recusa e permite tentar outra opção na mesma intenção.
- `cancelled`/`expired`: cancela o pedido que ainda aguardava pagamento.
- Avisos repetidos são idempotentes. Avisos atrasados não regridem pedidos pagos/enviados/entregues. Pagamento confirmado após cancelamento local vai para revisão.

O frete compõe o valor total como linha de serviço; não é somado novamente por `shipping_amount`. Se um plano com juros fizer a API retornar um valor maior que o pedido, ele irá para revisão: valide essa representação com a sua conta antes de liberar tais planos.

A criação usa uma reserva atômica no banco para impedir duas intenções em requisições simultâneas. O Swagger não garante idempotência da criação de `payment-intent`: após timeout ou perda de resposta, a aplicação **não cria outra intenção automaticamente**. O pedido fica com pagamento `reconciliar`. A loja deve conferir o `order_id` (UUID do pedido) no suporte/painel Getnet, cancelar qualquer intenção pendente e resolver a tentativa antes de gerar outra. Não limpar a reserva ou marcar pago apenas com base no erro de rede.

O cron já existente consulta/cancela intenções vencidas. Após falha de consulta/cancelamento, mantém o pedido pendente para evitar expiração local incorreta. A frequência diária configurada em `vercel.json` foi preservada; para acompanhamento sem clientes conectados, configure uma frequência de conciliação compatível com o plano de hospedagem. Intenções com criação incerta exigem conferência manual. Estornos/chargebacks posteriores a uma venda paga continuam sendo operações separadas de pós-venda.

## Validação e liberação

`npm test` usa banco PGlite descartável e APIs simuladas. A nova suíte verifica OAuth, concorrência, valores, autenticação do webhook, recusa seguida de aprovação, duplicidade, timeout, consulta pelo dono e permissões da função SQL. O teste de navegador percorre carrinho, formulário de retirada com endereço de cobrança e confirmação; usa o loader oficial com conteúdo/API simulados para conferir iframe, ausência de navegação externa da loja e layout em 390/1440 pixels; não valida uma transação real.

Antes de produção, validar na conta própria: cartão aprovado/recusado, parcelas contratadas, 3DS, Pix emitido e pago, pendência/expiração/cancelamento, webhook real e suas retentativas, perda de resposta e revisão de valor. Confirmar que os dados de cartão não passam pelas requisições da loja e confirmar o escopo PCI com a Getnet/adquirente.

Somente após a homologação aprovada: configure credenciais de produção separadas, `GETNET_GLOBAL_AMBIENTE=producao` e `GETNET_GLOBAL_PRODUCAO_LIBERADA=sim`, além de repetir a configuração técnica/comercial e os domínios públicos de produção. Não altere o provedor Pix legado simplesmente trocando sua URL-base.

Foi corrigido também um erro preexistente no resumo do carrinho: o acumulador de totais descartava o resumo de atacado quando havia produtos, causando erro JavaScript. A correção preserva os valores e mantém o resumo durante a soma.
