// Modo demonstração: sobe a loja com um banco descartável em memória (PGlite) e
// pagamento/frete simulados. NÃO usa o .env.local nem toca no Supabase de verdade.
// Uso: node scripts/demo-local.js   (porta 5174; e-mails ficam em .dev-emails/)
const http = require('http');
const fs = require('fs');
const path = require('path');
const { criarBancoTeste } = require('../test/banco-teste');
const { criarClienteFalso } = require('../test/supabase-falso');

process.chdir(path.join(__dirname, '..'));
Object.assign(process.env, {
  NODE_ENV: 'development',
  SUPABASE_URL: 'https://demo.supabase.co',
  SUPABASE_SERVICE_ROLE_KEY: 'demo',
  SESSION_SECRET: 'segredo-somente-da-demonstracao-local',
  PAGAMENTO_PROVEDOR: 'simulado',
  GETNET_WEBHOOK_TOKEN: 'demo',
  CRON_SECRET: 'demo',
  NFE_PROVEDOR: 'simulado',
  APP_URL: `http://localhost:${process.env.PORT || 5174}`,
});
for (const k of ['RESEND_API_KEY', 'MELHOR_ENVIO_TOKEN', 'VERCEL']) delete process.env[k];

(async () => {
  const pg = await criarBancoTeste();
  await pg.exec(fs.readFileSync(path.join('supabase', 'dados-iniciais.sql'), 'utf8'));
  const caminho = require.resolve('@supabase/supabase-js', { paths: [path.join(__dirname, '..', 'server')] });
  require.cache[caminho] = { id: caminho, filename: caminho, loaded: true, exports: { createClient: () => criarClienteFalso(pg) } };
  const { tratarRequisicao } = require('../server');

  // Conta admin só da demonstração (banco em memória). Senha aleatória em .dev-emails/ (fora do git).
  const { hashSenha } = require('../server/auth');
  const senha = `Demo-${require('crypto').randomBytes(6).toString('base64url')}`;
  await pg.query(
    `insert into usuarios (nome, apelido, email, telefone, senha, papel, email_verificado_em, dois_fatores)
     values ('Admin Demonstracao', 'admin', 'admin@demo.local', '41999999999', $1, 'admin', now(), true)`,
    [hashSenha(senha)],
  );
  fs.mkdirSync('.dev-emails', { recursive: true });
  fs.writeFileSync(path.join('.dev-emails', 'admin-demo.txt'), `apelido: admin\nsenha: ${senha}\n(código de acesso: e-mails em .dev-emails/)\n`);

  const porta = Number(process.env.PORT) || 5174;
  http.createServer(tratarRequisicao).listen(porta, () =>
    console.log(`Demonstração local (banco descartável) em http://localhost:${porta}`));
})();
